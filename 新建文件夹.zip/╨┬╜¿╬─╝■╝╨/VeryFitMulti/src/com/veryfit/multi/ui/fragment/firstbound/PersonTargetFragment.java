package com.veryfit.multi.ui.fragment.firstbound;

import java.util.Calendar;
import java.util.List;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.project.library.database.DaoSession;
import com.project.library.database.Goal;
import com.project.library.database.GoalDao;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;
import com.veryfit.multi.R;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.activity.FirstStartActivity;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.util.TempUtil;
import com.veryfit.multi.view.RulerView;
import com.veryfit.multi.view.RulerView.OnDataSelectedListener;

import de.greenrobot.dao.query.QueryBuilder;

public class PersonTargetFragment extends PersonBaseFragment implements View.OnClickListener {
	public PersonTargetFragment(OnPagerChangedListener listener) {
		super(listener);
	}

	private View mRootView = null;
	private boolean isPrepared = false;

	private Button next, previous;
	private RulerView ruler_sport, ruler_sleep;
	private int data_sport = -1, data_sleep = -1;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_person_target, container, false);
			initView();
			initEvent();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	public void initView() {
		next = (Button) mRootView.findViewById(R.id.person_target_finished);
		previous = (Button) mRootView.findViewById(R.id.person_target_previous);
		ruler_sleep = (RulerView) mRootView.findViewById(R.id.person_inof_sleep);
		ruler_sport = (RulerView) mRootView.findViewById(R.id.person_inof_sport);

		ruler_sleep.initData("min", "h", 1440, 300, 60, 3);
		ruler_sport.initData(getResources().getString(R.string.unit_step), "", 30000, 1000, 1000, 5);

		// ruler_sport.setData(10000);
		//
		// ruler_sleep.setData(8*60);
	}

	public void initEvent() {
		next.setOnClickListener(this);
		previous.setOnClickListener(this);
		ruler_sleep.setListener(new OnDataSelectedListener() {

			@Override
			public void OnDataSelected(int data) {
				// TODO Auto-generated method stub
				data_sleep = data;
			}
		});
		ruler_sport.setListener(new OnDataSelectedListener() {

			@Override
			public void OnDataSelected(int data) {
				data_sport = data;
			}
		});
	}

	@Override
	public void onThemeChanged() {

	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}
		if (data_sleep == -1) {
			long time = LongDateUtil.Calendar2LongDate(Calendar.getInstance());
			int[] goal = TempUtil.getGoal(time);
			data_sleep = goal[1];
			data_sport = goal[0];
			// data_sleep = AppSharedPreferences.getInstance().getGoalSleep();
			// data_sport = AppSharedPreferences.getInstance().getGoalSport();
		}
		ruler_sleep.setData(data_sleep);
		ruler_sport.setData(data_sport);
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.person_target_previous) {
			setPagerIndex(3);
		}
		data_sport = ruler_sport.getCenterData();
		data_sleep = ruler_sleep.getCenterData();
		// AppSharedPreferences.getInstance().setGoalSleep(data_sleep);
		// AppSharedPreferences.getInstance().setGoalSport(data_sport);

		if (v.getId() == R.id.person_target_finished) {
			TempUtil.saveGoal(new Goal(data_sport, Goal.TYPE_SPORT), new Goal(data_sleep, Goal.TYPE_SLEEP));

			String content = " 睡眠目标:" + (ruler_sleep.getCenterData() / 60) + ":" + ruler_sleep.getCenterData() % 60 + "运动目标:" + ruler_sport.getCenterData() + "步";
			Toast.makeText(getActivity(), content, Toast.LENGTH_LONG).show();

			DebugLog.e(" 睡眠目标:" + (ruler_sleep.getCenterData() / 60) + ":" + ruler_sleep.getCenterData() % 60 + "运动目标:" + ruler_sport.getCenterData() + "步");
			((FirstStartActivity) getActivity()).jumpToNext();
		}
	}

}
