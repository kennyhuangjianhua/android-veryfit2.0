package com.veryfit.multi.ui.activity.device;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.database.AlarmNotify;
import com.project.library.database.AlarmNotifyDao;
import com.project.library.database.DaoSession;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.ui.activity.BaseNotifyBleActivity;
import com.veryfit.multi.view.group.ItemAlarmSet;

public class AlarmSetActivity extends BaseNotifyBleActivity {
	private AlarmNotify alarm;

	private ItemAlarmSet remind, repeat, time, name;

	protected CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	@Override
	protected void onThemeChanged() {

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_alarm_set);
		alarm = getIntent().getParcelableExtra("alarm");
		initView();

	}

	protected void initView() {
		remind = (ItemAlarmSet) findViewById(R.id.alarm_remind);
		repeat = (ItemAlarmSet) findViewById(R.id.alarm_repeat);
		time = (ItemAlarmSet) findViewById(R.id.alarm_time);
		name = (ItemAlarmSet) findViewById(R.id.alarm_name);
	}

	@Override
	protected void onResume() {
		super.onResume();
		remind.setStubType(ItemAlarmSet.TYPE_ALARM_REMIND, alarm.getAlarmType());
		repeat.setStubType(ItemAlarmSet.TYPE_ALARM_REPEAT, alarm.getAlarmRepetitions());
		time.setStubType(ItemAlarmSet.TYPE_ALARM_TIME, alarm.getAlarmHour(), alarm.getAlarmMinute());
		name.setStubType(ItemAlarmSet.TYPE_ALARM_NAME, getResources().getStringArray(R.array.alarmType)[alarm.getAlarmType()]);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.tittle_left:
			finish();
			break;
		case R.id.tittle_right:
			saveData();
			Intent intent = new Intent();
			intent.putExtra("alarm", alarm);
			setResult(1, intent);
			finish();
			break;

		default:
			break;
		}
	}

	private void saveData() {
		alarm.setAlarmType((Integer) remind.getValue()[0]);
		alarm.setAlarmRepetitions((Integer) repeat.getValue()[0]);
		alarm.setAlarmHour((Integer) time.getValue()[0]);
		alarm.setAlarmMinute((Integer) time.getValue()[1]);
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		AlarmNotifyDao alarmNotifyDao = daoSession.getAlarmNotifyDao();
		alarmNotifyDao.update(alarm);
		// 发送到手环
		mCore.write(SettingsCmd.getInstance().getAlarmClockSettingsCmd(alarm));
		DebugLog.d(alarm.toString());
	}

	protected APPCoreServiceListener mAppListener = new APPCoreServiceListener() {

		@Override
		public void onSettingsSuccess(byte cmdKey, boolean success) {
		}

		@Override
		public void onDataSendTimeOut(byte[] data) {
			// 发送超时的在这里判断

		}
	};

	@Override
	protected void onSettingsSuccess() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void onDataSendFailed() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void saveDate() {
		// TODO Auto-generated method stub
		
	}

}
