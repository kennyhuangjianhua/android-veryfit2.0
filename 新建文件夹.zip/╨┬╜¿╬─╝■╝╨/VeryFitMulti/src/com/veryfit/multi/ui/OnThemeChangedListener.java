package com.veryfit.multi.ui;

/** 主题切换监听 */
public interface OnThemeChangedListener {

	/** 主题切换 */
	void onThemeChanged();
}
