package com.veryfit.multi.ui.fragment.inter;

import android.view.View;

public interface NotifyParentFragment {
	void onClickGoToTheDay(int dateOffset);

	void onDateScrolling(int offset);

	public abstract void onRootViewCreate(View rootView);

	/**
	 * 在从fragment1切换到frag2时，主fragment会记录上一个fragment1的linePointView状态，
	 * 需要还原为frag2的linePointview状态
	 * 并且，如果frag2的linePointView如果不可见，那frag2（即currentFrag）就有可能重新加载所选中日期的数据
	 * 
	 * @param dateOffset
	 *            dateView需要显示的日期偏移量
	 * @param isShow
	 *            pointView是否正在显示，若显示，则dateView为选中状态
	 */
	void notifyParentReloadMyDate(int dateOffset, boolean isShow);

	/** 健康数据变化 */
	void onHealthDataChanged();
}
