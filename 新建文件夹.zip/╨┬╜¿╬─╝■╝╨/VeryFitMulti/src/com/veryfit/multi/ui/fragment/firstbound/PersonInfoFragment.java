package com.veryfit.multi.ui.fragment.firstbound;

import android.os.Bundle;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.BleStatus;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.ui.adapter.PersonInfoPagerAdapter;
import com.veryfit.multi.view.CirclePageIndicator;
import com.veryfit.multi.view.NoScrollViewPager;

public class PersonInfoFragment extends BaseFragment implements OnPagerChangedListener {
	private CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	private View mRootView = null;
	private boolean isPrepared = false;
	private NoScrollViewPager viewPager;
	private PersonInfoPagerAdapter pagerAdapter;
	private CirclePageIndicator pagerIndicator;
	private TextView title;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.activity_person_info, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	public void initView() {
		title = (TextView) mRootView.findViewById(R.id.title_text);
		viewPager = (NoScrollViewPager) mRootView.findViewById(R.id.pager_person_info);
		pagerIndicator = (CirclePageIndicator) mRootView.findViewById(R.id.pagerIndicator);
		pagerAdapter = new PersonInfoPagerAdapter(getActivity().getSupportFragmentManager(), this);
		viewPager.setNoScroll(true);
		viewPager.setAdapter(pagerAdapter);
		pagerIndicator.setViewPager(viewPager);
		pagerIndicator.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				Log.d("viewPager", "--onPageSelected  arg0：" + arg0);
				if (arg0 == 4) {
					title.setText(R.string.titlebar_target_sport);
				} else {
					title.setText(R.string.person_info);
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				Log.d("viewPager", "--onPageScrolled  arg0：" + arg0 + "  arg2:" + arg2);

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});

	}

	@Override
	public void onThemeChanged() {

	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared) {
			return;
		}

		mCore.addListener(mAppListener);
	}

	public void close() {
		mCore.removeListener(mAppListener);
	}

	@Override
	public void setPagerIndex(int index) {
		if (viewPager != null) {
			viewPager.setCurrentItem(index);
		}
	}

	private APPCoreServiceListener mAppListener = new APPCoreServiceListener() {

		@Override
		public void onBlueToothError(int error) {
			if (error == BleStatus.STATE_ON) {
				// 蓝牙已开启。什么都不用做，搜索有搜索按钮
			}
		}

		@Override
		public void onBLEConnected() {

		}

		@Override
		public void onBLEConnecting() {

		}

		@Override
		public void onBLEDisConnected(String address) {

		}

		@Override
		public void onSettingsSuccess(byte cmdKey, boolean success) {
			if (success) {
				switch (cmdKey) {
				case SettingsCmd.KEY_UNIT_SETTINGS:
					// 单位设置成功。
					break;

				default:
					break;
				}
			}
		}
	};
}
