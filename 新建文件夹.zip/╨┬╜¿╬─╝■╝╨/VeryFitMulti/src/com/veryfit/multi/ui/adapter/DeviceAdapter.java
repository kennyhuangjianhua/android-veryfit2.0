package com.veryfit.multi.ui.adapter;

import java.util.ArrayList;

import com.project.library.entity.BleDevice;
import com.veryfit.multi.BuildConfig;
import com.veryfit.multi.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class DeviceAdapter extends BaseAdapter {

	ArrayList<BleDevice> mDeviceList;
	LayoutInflater inflater;
	public BleDevice checkDevice;
	public boolean binding;

	public DeviceAdapter(ArrayList<BleDevice> mDeviceList, Context context) {
		super();
		this.mDeviceList = mDeviceList;
		inflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		return mDeviceList.size();
	}

	@Override
	public Object getItem(int position) {
		return mDeviceList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vh;
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.item_device, null);
			vh = new ViewHolder();
			vh.icon = (ImageView) convertView.findViewById(R.id.device_icon);
			vh.check = (ImageView) convertView.findViewById(R.id.scan_fail);
			vh.address = (TextView) convertView.findViewById(R.id.device_mac);
			vh.name = (TextView) convertView.findViewById(R.id.device_name);
			vh.progress = (ProgressBar) convertView.findViewById(R.id.scan_progress);
			convertView.setTag(vh);
		} else {
			vh = (ViewHolder) convertView.getTag();
		}
		BleDevice device = mDeviceList.get(position);
		vh.name.setText(device.mDeviceName);
		vh.address.setText(device.mDeviceAddress+ (BuildConfig.DEBUG ? "***" + device.mRssi : ""));// 方便测试，将rssi写到页面上了，发布时不要
		vh.progress.setVisibility(View.GONE);
		vh.check.setVisibility(View.GONE);
		if (device.equals(checkDevice)) {
			if (binding) {
				vh.progress.setVisibility(View.VISIBLE);
			} else {
				vh.check.setVisibility(View.VISIBLE);
			}
		}
		return convertView;
	}

	class ViewHolder {
		ImageView icon, check;
		TextView name, address;
		ProgressBar progress;
	}

}
