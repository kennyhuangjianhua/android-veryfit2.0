package com.veryfit.multi.ui.activity.device;

import android.app.Dialog;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.project.library.device.cmd.settings.Sedentariness;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.activity.BaseNotifyBleActivity;
import com.veryfit.multi.util.Util;
import com.veryfit.multi.view.group.ItemLableValue;
import com.veryfit.multi.view.group.ItemToggleLayout;
import com.veryfit.multi.view.group.WeekDayCheck;
import com.veryfit.multi.view.wheel.NumericWheelAdapter;
import com.veryfit.multi.view.wheel.WheelView;

public class RemindSportSetActivity extends BaseNotifyBleActivity {

	private static final int MIN_INTERVAL = 15, MAX_INTERVAL = 180;

	private WeekDayCheck dayCheck;

	private Sedentariness sedentariness = new Sedentariness();

	// private int repetitions , startHour , endHour , startMin , endMin ,
	// interval;

	private ItemToggleLayout toggle;

	private ItemLableValue startView, endView;

	private SeekBar intervalView;

	private TextView intervalValueView;

	private AppSharedPreferences share;

	@Override
	protected void onThemeChanged() {

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_remind_sport_set);
		super.onCreate(savedInstanceState);
		loadData();
		initview();

	}

	private void loadData() {
		share = AppSharedPreferences.getInstance();
		sedentariness.repetitions = share.getDeviceRemindSportRepetitions();
		sedentariness.startHour = share.getDeviceRemindSportStartHour();
		sedentariness.startMinute = share.getDeviceRemindSportStartMin();
		sedentariness.endHour = share.getDeviceRemindSportEndHour();
		sedentariness.endMinute = share.getDeviceRemindSportEndMin();
		sedentariness.interval = share.getDeviceRemindSportInterval();
	}

	private void initview() {
		dayCheck = (WeekDayCheck) findViewById(R.id.week_day);
		dayCheck.initAndSetDefault(sedentariness.repetitions);

		toggle = (ItemToggleLayout) findViewById(R.id.remind_sport_switch);
		toggle.setOpen((sedentariness.repetitions & 1) == 1);

		startView = (ItemLableValue) findViewById(R.id.remind_sport_start);
		startView.setValue(Util.formatTime(sedentariness.startHour, sedentariness.startMinute));

		endView = (ItemLableValue) findViewById(R.id.remind_sport_end);
		endView.setValue(Util.formatTime(sedentariness.endHour, sedentariness.endMinute));

		intervalView = (SeekBar) findViewById(R.id.remind_sport_interval);
		intervalView.setMax(MAX_INTERVAL - MIN_INTERVAL);
		intervalView.setProgress(sedentariness.interval - MIN_INTERVAL);
		intervalView.setOnSeekBarChangeListener(seeklistener);

		intervalValueView = (TextView) findViewById(R.id.seekbarValue);
		setIntervalValue();
	}

	private OnSeekBarChangeListener seeklistener = new OnSeekBarChangeListener() {
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
			sedentariness.interval = progress + MIN_INTERVAL;
			setIntervalValue();
		}

		public void onStartTrackingTouch(SeekBar seekBar) {
		}

		public void onStopTrackingTouch(SeekBar seekBar) {
		}
	};

	private void setIntervalValue() {
		String format = getResources().getString(R.string.remind_sport_alert, sedentariness.interval);
		SpannableString span = new SpannableString(format);
		int start = format.indexOf(sedentariness.interval + "");
		int end = start + (sedentariness.interval + "").length();
		span.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.theme_tittle_bg)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		span.setSpan(new RelativeSizeSpan(2f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		intervalValueView.setText(span);
	}

	public void onClick(View v) {
		DebugLog.d("OnClick");
		super.onClick(v);
		switch (v.getId()) {
		case R.id.remind_sport_start:
			createDialog(true);
			break;
		case R.id.remind_sport_end:
			createDialog(false);
			break;

		default:
			break;
		}
	}

	@Override
	protected void onSettingsSuccess() {
		mCore.removeListener(mAppListener);
		sendingData = false;
		finish();
		// toggle.cancelProgressBar();
	}

	@Override
	protected void onDataSendFailed() {
		showSureBtn();
		mCore.removeListener(mAppListener);
	}

	@Override
	protected void saveDate() {
		if (dataHasChange()) {
			showProgress();
			mCore.addListener(mAppListener);
			sendingData = writeData(SettingsCmd.getInstance().getSedentarinessSettingsCmd(sedentariness));
			 if(!sendingData){
				 Toast.makeText(this, R.string.settingDataFail, Toast.LENGTH_SHORT).show();
				 mCore.removeListener(mAppListener);
				 showSureBtn();
//				 finish();
			 }
		} else {
			finish();
		}
	}

	private boolean dataHasChange() {
		boolean hasChange = false;
		sedentariness.repetitions = dayCheck.getRepetition();
		if (toggle.isOpen()) {
			sedentariness.repetitions |= 1;
		} else {
			sedentariness.repetitions &= ~1;
		}
		if (share.getDeviceRemindSportRepetitions() != sedentariness.repetitions) {
			share.setDeviceRemindSportRepetitions(sedentariness.repetitions);
			hasChange = true;
		}
		if (share.getDeviceRemindSportStartHour() != sedentariness.startHour) {
			share.setDeviceRemindSportStartHour(sedentariness.startHour);
			hasChange = true;
		}
		if (share.getDeviceRemindSportStartMin() != sedentariness.startMinute) {
			share.setDeviceRemindSportStartMin(sedentariness.startMinute);
			hasChange = true;
		}
		if (share.getDeviceRemindSportEndHour() != sedentariness.endHour) {
			share.setDeviceRemindSportEndHour(sedentariness.endHour);
			hasChange = true;
		}
		if (share.getDeviceRemindSportEndMin() != sedentariness.endMinute) {
			share.setDeviceRemindSportEndMin(sedentariness.endMinute);
			hasChange = true;
		}
		if (share.getDeviceRemindSportInterval() != sedentariness.interval) {
			share.setDeviceRemindSportInterval(sedentariness.interval);
			hasChange = true;
		}
		if (hasChange) {
			share.setFlagDeviceRemindSportChange(hasChange);
		}
		return hasChange;
	}

	private void createDialog(final boolean isStart) {
		final Dialog dialog = new Dialog(this, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_time);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.getWindow().getAttributes().width = getWindowManager().getDefaultDisplay().getWidth();
		final WheelView hourView = (WheelView) dialog.findViewById(R.id.hour);
		hourView.setAdapter(new NumericWheelAdapter(0, 23));
		hourView.setVisibleItems(3);
		hourView.setCurrentItem(isStart ? sedentariness.startHour : sedentariness.endHour);

		final WheelView minView = (WheelView) dialog.findViewById(R.id.min);
		minView.setAdapter(new NumericWheelAdapter(0, 59));
		minView.setVisibleItems(3);
		minView.setCurrentItem(isStart ? sedentariness.startMinute : sedentariness.endMinute);

		dialog.findViewById(R.id.cancle).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		dialog.findViewById(R.id.set).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				int hour = hourView.getCurrentItem();
				int min = minView.getCurrentItem();
				if (isStart) {
					startView.setValue(Util.formatTime(hour, min));
					sedentariness.startHour = hour;
					sedentariness.startMinute = min;
				} else {
					endView.setValue(Util.formatTime(hour, min));
					sedentariness.endHour = hour;
					sedentariness.endMinute = min;
				}
				dialog.dismiss();
			}
		});
		dialog.show();

	}

}
