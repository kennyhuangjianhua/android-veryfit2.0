package com.veryfit.multi.ui.fragment.firstbound;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.util.UnitFormat;
import com.veryfit.multi.view.DialogUtil;
import com.veryfit.multi.view.RulerView;
import com.veryfit.multi.view.DialogUtil.OnHeightFormatSelectListener;

public class PersonWeightFragment extends PersonBaseFragment implements View.OnClickListener {
	public PersonWeightFragment(OnPagerChangedListener listener) {
		super(listener);
	}

	private View mRootView = null;
	private boolean isPrepared = false;

	private Button next, previous;
	private RulerView ruler_weight;

	private int unitType;

	private static final int MIN_KG = 0;
	private static final int MIN_LB = 0;

	private int weight = -1;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_person_weight, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	public void initView() {
		next = (Button) mRootView.findViewById(R.id.person_weight_next);
		previous = (Button) mRootView.findViewById(R.id.person_weight_previous);
		ruler_weight = (RulerView) mRootView.findViewById(R.id.person_inof_weight);
		ruler_weight.setData(60);
		next.setOnClickListener(this);
		previous.setOnClickListener(this);

	}

	@Override
	public void onThemeChanged() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}
		unitType = AppSharedPreferences.getInstance().getUnitType();
		switchUnitType();
	}

	private void switchUnitType() {
		if (weight == -1) {
			weight = AppSharedPreferences.getInstance().getUserWeight();
		}
		DebugLog.d("weight = " + weight);
		if (unitType == Constant.METRIC) {
			ruler_weight.initData("kg", "", 250, MIN_KG, 10, 5);
			ruler_weight.setData(weight);
		} else if (unitType == Constant.BRITISH) {
			ruler_weight.initData("lb", "", 500, MIN_LB, 10, 5);
			DebugLog.d("weight lb= " + UnitFormat.kg2lb(weight));
			ruler_weight.setData(UnitFormat.kg2lb(weight));
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.person_weight_previous) {
			setPagerIndex(1);
		}

		if (v.getId() == R.id.person_weight_next) {
			int data = ruler_weight.getCenterData();
			DebugLog.d("data***" + data);
			if (unitType == Constant.METRIC) {
				weight = data;
				AppSharedPreferences.getInstance().setUserWeight(data);
			} else if (unitType == Constant.BRITISH) {
				int kg = UnitFormat.lb2kg(data);
				DebugLog.d("kg***" + kg);
				weight = kg;
				AppSharedPreferences.getInstance().setUserWeight(kg);
			}
			setPagerIndex(3);
		}
	}
}
