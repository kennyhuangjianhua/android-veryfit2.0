package com.veryfit.multi.ui.activity;

import java.util.concurrent.ConcurrentLinkedQueue;
import no.nordicsemi.android.dfu.DfuService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.database.AlarmNotify;
import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.DeviceRestartCmd;
import com.project.library.device.cmd.WareUpdateCmd;
import com.project.library.device.cmd.getinfo.GetInfoCmd;
import com.project.library.device.cmd.health.HealthSyncRequest;
import com.project.library.device.cmd.health.HealthSyncSuccess;
import com.project.library.device.cmd.notify.IncomingCall;
import com.project.library.device.cmd.notify.NotifyCmd;
import com.project.library.device.cmd.settings.MultiTarget;
import com.project.library.device.cmd.settings.Sedentariness;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.device.cmd.settings.Units;
import com.project.library.device.cmd.settings.Userinfos;
import com.project.library.share.LibSharedPreferences;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.util.Constant;

public class OtherActivity extends BaseActivity {

	TextView textId1;
	Button syncDataMode;
	CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_other);
		textId1 = (TextView) findViewById(R.id.textId1);
		syncDataMode = (Button) findViewById(R.id.syncDataMode);
		mCore.addListener(mAppListener);

		showInitData();
	}

	private void showInitData() {
		showSafeMode(AppSharedPreferences.getInstance().getSyncHealdataMode());
	}

	private void showSafeMode(boolean safe) {
		syncDataMode.setText(safe ? "现在为安全模式" : "现在为非安全模式");
	}

	private void connect() {
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				String addr = AppSharedPreferences.getInstance().getBindDeviceAddr();
				if (TextUtils.isEmpty(addr)) {
					DebugLog.e("设备都没有，连接");
					return;
				}
				mCore.connect(addr);
			}
		}, 2000L);
	}

	public void onConnect(View v) {
		connect();
	}

	/** 绑定 */
	public void Bind(View v) {
		mCore.writeForce(BindUnbindCmd.getInstance().getBindCmd());
	}

	/** 解绑 */
	public void unBind(View v) {
		// 设备不在线时解绑，直接删除本地设备地址。[不需要连接上再解绑]
		mCore.writeForce(BindUnbindCmd.getInstance().getUnbindCmd());
	}

	/** 固件升级 */
	public void wareUpdate(View v) {
		System.out.println("固件升级");
		mCore.write(WareUpdateCmd.getInstance().getWareUpdateCmd());
	}

	/** 同步数据模式切换 */
	public void syncDataMode(View v) {
		boolean safe = AppSharedPreferences.getInstance().getSyncHealdataMode();
		AppSharedPreferences.getInstance().setSyncHealdataMode(!safe);

		showSafeMode(!safe);
	}

	/** 获取同步数据安全模式 */
	private byte getSafeMode() {
		return AppSharedPreferences.getInstance().getSyncHealdataMode() ? HealthSyncSuccess.MODE_SAFE : HealthSyncSuccess.MODE_OTHER;
	}

	/** 同步数据[打开开关并同步数据] */
	public void syncData(View v) {
		textId1.setText("开始同步数据");
		LibSharedPreferences.getInstance().setSyncData(true);
		mCore.writeForce(HealthSyncRequest.getInstance().getHealthSyncRequestCmd(HealthSyncRequest.FLAG_FOREGROUND, getSafeMode()));
	}

	/** 打开同步数据总开关[只打开开关，不同步数据] */
	public void openSync(View v) {
		LibSharedPreferences.getInstance().setSyncData(false);
		mCore.writeForce(HealthSyncRequest.getInstance().getHealthSyncRequestCmd(HealthSyncRequest.FLAG_FOREGROUND, getSafeMode()));
	}

	/** 关闭同步数据总开关 */
	public void closeSync(View v) {
		mCore.writeForce(HealthSyncSuccess.getInstance().getHealthSyncSuccessCmd(HealthSyncRequest.FLAG_FOREGROUND, getSafeMode()));
	}

	/** 获取设备基本信息 */
	public void getDeviceInfosBasic(View v) {
		mCore.write(GetInfoCmd.getInstance().getGetInfoCmd(GetInfoCmd.KEY_BASIC));
	}

	/** 获取设备支持功能列表 */
	public void getDeviceInfosFunction(View v) {
		mCore.write(GetInfoCmd.getInstance().getGetInfoCmd(GetInfoCmd.KEY_FUNCTION));
	}

	/** 获取设备时间 */
	public void getDeviceInfosTime(View v) {
		mCore.write(GetInfoCmd.getInstance().getGetInfoCmd(GetInfoCmd.KEY_TIME));
	}

	/** 获取设备mac地址 */
	public void getDeviceInfosMac(View v) {
		mCore.write(GetInfoCmd.getInstance().getGetInfoCmd(GetInfoCmd.KEY_MAC));
	}

	/** 获取设备电池信息 */
	public void getDeviceInfosBattery(View v) {
		mCore.write(GetInfoCmd.getInstance().getGetInfoCmd(GetInfoCmd.KEY_BATTERY));
	}

	/** 时间设置 */
	public void timeSettings(View v) {
		mCore.write(SettingsCmd.getInstance().getTimeSettingsCmd());
	}

	private ConcurrentLinkedQueue<AlarmNotify> mAlarmList = new ConcurrentLinkedQueue<AlarmNotify>();

	/** 闹钟设置 */
	public void alarmSettings(View v) {
		if (mAlarmList.isEmpty()) {
			// id从1开始
			for (int i = 1; i <= 5; i++) {
				AlarmNotify alarm = new AlarmNotify();
				alarm.setAlarmId(i);
				alarm.setAlarmStatus(AlarmNotify.STATUS_ADD_MODIFY);
				alarm.setAlarmType(AlarmNotify.TYPE_ALARM_SPORT);
				alarm.setAlarmHour(12);
				alarm.setAlarmMinute(00);
				alarm.setAlarmRepetitions(1);
				alarm.setAlarmSnoozeDuration(0);

				mAlarmList.add(alarm);
			}
		}

		// 一条一条发送
		mCore.writeForce(SettingsCmd.getInstance().getAlarmClockSettingsCmd(mAlarmList.peek()));
	}

	/** 运动目标、睡眠目标设置 */
	public void multiTargetSettings(View v) {
		MultiTarget target = new MultiTarget();
		target.sportType = MultiTarget.TYPE_STEP;
		target.sportTarget = 10000;

		target.sleepFlag = MultiTarget.FLAG_SLEEP_NORMAL;
		target.sleepHour = 8;
		target.sleepMinute = 30;

		mCore.writeForce(SettingsCmd.getInstance().getMultiTargetSettingsCmd(target));
	}

	/** 设置用户信息 */
	public void UserInfosSettings(View v) {
		Userinfos info = new Userinfos();
		info.height = 200;
		info.weight = 100;
		info.gender = Userinfos.MALE;
		info.year = 2000;
		info.month = 10;
		info.day = 10;
		mCore.writeForce(SettingsCmd.getInstance().getUserinfosSettingsCmd(info));
	}

	/** 设置单位 */
	public void UnitSettings(View v) {
		Units units = new Units();
		units.dist = Units.UNIT_DIST_KM;
		units.weight = Units.UNIT_WEIGHT_KG;
		units.temp = Units.UNIT_TEMP_C;
		units.stride = Units.UNIT_STRIDE_CM;
		mCore.writeForce(SettingsCmd.getInstance().getUnitSettingsCmd(units));
	}

	/** 久坐提醒设置 */
	public void sedentarinessSettings(View v) {
		Sedentariness s = new Sedentariness();
		s.startHour = 10;
		s.startMinute = 10;
		s.endHour = 20;
		s.endMinute = 20;
		s.interval = 30;
		s.repetitions = 8;

		mCore.writeForce(SettingsCmd.getInstance().getSedentarinessSettingsCmd(s));
	}

	/** 来电提醒命令 */
	public void incomingCallNotify(View v) {
		IncomingCall message = new IncomingCall();
		mCore.writeForce(NotifyCmd.getInstance().getIncomingCallCmd(message));
	}

	/** 来电状态提醒命令 */
	public void incomingCallStatusNotify(View v) {
		mCore.writeForce(NotifyCmd.getInstance().getIncomingCallStatusCmd(IncomingCall.INCOMING_CALL_STATUS_ACCEPT));
	}

	/** 收到信息提醒 */
	public void incomingMessageNotify(View v) {
	}

	/** 设备重启 */
	public void deviceRestart(View v) {
		mCore.writeForce(DeviceRestartCmd.getInstance().getDeviceRestartCmd());
	}

	@Override
	protected void onResume() {
		super.onResume();

		// We are using LocalBroadcastReceiver instead of normal
		// BroadcastReceiver for optimization purposes
		final LocalBroadcastManager broadcastManager = LocalBroadcastManager.getInstance(this);
		broadcastManager.registerReceiver(mDfuUpdateReceiver, makeDfuUpdateIntentFilter());
	}

	@Override
	protected void onPause() {
		super.onPause();

		final LocalBroadcastManager broadcastManager = LocalBroadcastManager.getInstance(this);
		broadcastManager.unregisterReceiver(mDfuUpdateReceiver);
	}

	private static IntentFilter makeDfuUpdateIntentFilter() {
		final IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(DfuService.BROADCAST_PROGRESS);
		intentFilter.addAction(DfuService.BROADCAST_ERROR);
		return intentFilter;
	}

	private final BroadcastReceiver mDfuUpdateReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(final Context context, final Intent intent) {
			// DFU is in progress or an error occurred
			final String action = intent.getAction();

			if (DfuService.BROADCAST_PROGRESS.equals(action)) {
				final int progress = intent.getIntExtra(DfuService.EXTRA_DATA, 0);
				final int currentPart = intent.getIntExtra(DfuService.EXTRA_PART_CURRENT, 1);
				final int totalParts = intent.getIntExtra(DfuService.EXTRA_PARTS_TOTAL, 1);
				updateProgressBar(progress, currentPart, totalParts, false, false);
			}
		}
	};

	private APPCoreServiceListener mAppListener = new APPCoreServiceListener() {

		@Override
		public void onBLEDisConnected(String address) {
			mCore.removeListener(this);
			finish();
		}

		@Override
		public void onWareUpdate(byte status) {
			if (status == WareUpdateCmd.STATUS_SUCCESS) {
				DebugLog.e("准备升级喽");
				startWareUpdateService();
			}
		}

		@Override
		public void onBindUnbind(byte status) {

			if (status == BindUnbindCmd.STATUS_BIND_SUCCESS) {
				DebugLog.e("绑定成功");
			} else if (status == BindUnbindCmd.STATUS_UNBIND_SUCCESS) {
				DebugLog.e("解绑成功");
				mCore.removeListener(this);
				finish();
			}
		}

		@Override
		public void onSettingsSuccess(byte cmdKey, boolean success) {
			if (success) {
				DebugLog.e("设置成功： " + cmdKey);
				if (cmdKey == SettingsCmd.KEY_ALARM_CLOCK_SETTINGS) {
					mAlarmList.poll();
					AlarmNotify alarm = mAlarmList.peek();
					if (alarm == null) {
						DebugLog.e("全部闹钟设置成功。");
					} else {
						mCore.writeForce(SettingsCmd.getInstance().getAlarmClockSettingsCmd(alarm));
					}
				}
			} else {
				DebugLog.e("设置失败： " + cmdKey);
			}
		}

		@Override
		public void onDataSendTimeOut(byte[] data) {
			// 发送超时的在这里判断

		}

		public void onSyncData(int process) {
			if (process == 100) {
				DebugLog.d("APP收到同步数据结束");
				textId1.setText("同步数据结束。。。");
			} else {
				textId1.setText("正在同步数据，已完成" + process + "%");
			}
		}

	};

	private void startWareUpdateService() {
		final boolean keepBond = false;
		final Intent service = new Intent(this, DfuService.class);
		String addr = AppSharedPreferences.getInstance().getBindDeviceAddr();
		if (TextUtils.isEmpty(addr)) {
			DebugLog.e("设备都没有，不升级");
			return;
		}
		service.putExtra(DfuService.EXTRA_DEVICE_ADDRESS, addr);
		service.putExtra(DfuService.EXTRA_DEVICE_NAME, "DfuTarg");
		service.putExtra(DfuService.EXTRA_FILE_PATH, Constant.APP_ROOT_PATH + "/veryfit2.zip");
		service.putExtra(DfuService.EXTRA_KEEP_BOND, keepBond);
		startService(service);
	}

	private void updateProgressBar(final int progress, final int part, final int total, final boolean error, final boolean connectionError) {
		switch (progress) {
		case DfuService.PROGRESS_CONNECTING:
			break;
		case DfuService.PROGRESS_STARTING:
			break;
		case DfuService.PROGRESS_ENABLING_DFU_MODE:
			break;
		case DfuService.PROGRESS_VALIDATING:
			break;
		case DfuService.PROGRESS_DISCONNECTING:
			break;
		case DfuService.PROGRESS_COMPLETED: {
			textId1.setText("升级完成。。");
			connect();
		}
			break;
		case DfuService.PROGRESS_ABORTED:
			break;
		default: {
			if (error) {
				// showErrorMessage(progress, connectionError);
			} else {
				textId1.setText(progress + "%");
			}
		}
			break;
		}
	}

	@Override
	protected void onThemeChanged() {
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			mCore.removeListener(mAppListener);
			setResult(RESULT_OK);
			finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
