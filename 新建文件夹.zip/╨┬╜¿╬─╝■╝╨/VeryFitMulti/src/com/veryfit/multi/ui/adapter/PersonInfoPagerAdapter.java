package com.veryfit.multi.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.veryfit.multi.ui.fragment.firstbound.OnPagerChangedListener;
import com.veryfit.multi.ui.fragment.firstbound.PersonBirthdayFragment;
import com.veryfit.multi.ui.fragment.firstbound.PersonHeightFragment;
import com.veryfit.multi.ui.fragment.firstbound.PersonSexFragment;
import com.veryfit.multi.ui.fragment.firstbound.PersonTargetFragment;
import com.veryfit.multi.ui.fragment.firstbound.PersonWeightFragment;

public class PersonInfoPagerAdapter extends FragmentPagerAdapter {
	private List<Fragment> fgs;

	public PersonInfoPagerAdapter(FragmentManager fm, OnPagerChangedListener listener) {
		super(fm);
		// TODO Auto-generated constructor stub
		fgs = new ArrayList<Fragment>();
		fgs.add(new PersonSexFragment(listener));
		fgs.add(new PersonHeightFragment(listener));
		fgs.add(new PersonWeightFragment(listener));
		fgs.add(new PersonBirthdayFragment(listener));
		fgs.add(new PersonTargetFragment(listener));
	}

	@Override
	public Fragment getItem(int arg0) {
		// TODO Auto-generated method stub
		return fgs.get(arg0);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return fgs.size();
	}

}
