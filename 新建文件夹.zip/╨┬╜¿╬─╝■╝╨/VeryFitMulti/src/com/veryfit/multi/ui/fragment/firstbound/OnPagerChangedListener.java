package com.veryfit.multi.ui.fragment.firstbound;

public interface OnPagerChangedListener {
	void setPagerIndex(int index);
}
