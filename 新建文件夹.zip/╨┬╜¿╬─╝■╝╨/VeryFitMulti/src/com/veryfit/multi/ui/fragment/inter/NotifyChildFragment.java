package com.veryfit.multi.ui.fragment.inter;

public interface NotifyChildFragment {

	void onDateClick(int dateOffset);

	void onReloadData(int index);

}