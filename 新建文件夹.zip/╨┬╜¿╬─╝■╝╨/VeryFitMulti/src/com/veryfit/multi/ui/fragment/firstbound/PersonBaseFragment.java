package com.veryfit.multi.ui.fragment.firstbound;

import com.veryfit.multi.base.BaseFragment;

public abstract class PersonBaseFragment extends BaseFragment {
	protected OnPagerChangedListener mOnPagerChangedListener = null;

	public PersonBaseFragment(OnPagerChangedListener listener) {
		mOnPagerChangedListener = listener;
	}

	public void setPagerIndex(int index) {
		if (mOnPagerChangedListener != null) {
			mOnPagerChangedListener.setPagerIndex(index);
		}
	}
}
