package com.veryfit.multi.ui.adapter;

import java.util.Collections;
import java.util.List;

import com.project.library.database.AlarmNotify;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.util.Util;
import com.veryfit.multi.view.CustomToggleButton;
import com.veryfit.multi.view.CustomToggleButton.OnSwitchListener;
import com.veryfit.multi.vo.Alarm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class AlarmAdapter extends BaseAdapter {
	private List<AlarmNotify> datas;
	private LayoutInflater inflater;

	private String[] alarmTypes;

	public boolean sendingData;

	public AlarmAdapter(List<AlarmNotify> datas, Context context) {
		super();
		this.datas = datas;
		inflater = LayoutInflater.from(context);
		alarmTypes = context.getResources().getStringArray(R.array.alarmType);
	}

	/**
	 * 如果未达到支持闹钟数的最大值，那么就增加一个默认的闹钟
	 * 
	 * @return true表示增加成功，否则返回false
	 */
	public AlarmNotify addAlarm() {
		if (datas.size() < AlarmNotify.MAX_ALARM_COUNT) {
			AlarmNotify alarm = new AlarmNotify();
			alarm.setAlarmId(getAlarmId());
			datas.add(alarm);
			notifyDataSetChanged();
			return alarm;
		}
		return null;
	}

	public int getAlarmId() {
		// 已经是id升序的
		Collections.sort(datas);
		int i = 0;
		for (; i < datas.size(); i++) {
			if (datas.get(i).getAlarmId() != i + 1) {
				return i + 1;
			}
		}
		return i + 1;
	}

	@Override
	public int getCount() {
		return datas.size();
	}

	@Override
	public Object getItem(int position) {
		return datas.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.item_alarm, null);
			holder.icon = (ImageView) convertView.findViewById(R.id.alarm_icon);
			holder.time = (TextView) convertView.findViewById(R.id.alarm_time);
			holder.cycle = (TextView) convertView.findViewById(R.id.alarm_cycle);
			holder.toggleBtn = (CustomToggleButton) convertView.findViewById(R.id.alarm_switch);
			holder.type = (TextView) convertView.findViewById(R.id.alarm_tittle);
			holder.progress = (ProgressBar) convertView.findViewById(R.id.progress_circle);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		final AlarmNotify alarm = datas.get(position);
		holder.time.setText(Util.formatTime(alarm.getAlarmHour(), alarm.getAlarmMinute()));
		holder.cycle.setText(alarm.getRepeat(convertView.getResources().getStringArray(R.array.weekDay)));
		holder.toggleBtn.setSwitchState(alarm.isOpen());
		holder.toggleBtn.setOnSwitchListener(new OnSwitchListener() {

			@Override
			public void onSwitched(boolean isSwitchOn) {
				DebugLog.d("isSwitchOn = " + isSwitchOn);
				alarm.setOpen(isSwitchOn);
			}
		});
		holder.type.setText(alarmTypes[alarm.getAlarmType()]);
		if (sendingData && alarm.hasModify) {
			holder.progress.setVisibility(View.VISIBLE);
		} else {
			holder.progress.setVisibility(View.GONE);
		}
		return convertView;
	}

	class ViewHolder {
		ImageView icon;
		TextView time, cycle, type;
		CustomToggleButton toggleBtn;
		ProgressBar progress;
	}

}
