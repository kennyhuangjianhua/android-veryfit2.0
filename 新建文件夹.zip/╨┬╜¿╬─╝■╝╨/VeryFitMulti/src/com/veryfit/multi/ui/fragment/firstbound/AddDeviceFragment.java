package com.veryfit.multi.ui.fragment.firstbound;

import java.util.ArrayList;
import java.util.Collections;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.entity.BleDevice;
import com.project.library.util.BleScanTool;
import com.project.library.util.BleStatus;
import com.project.library.util.BleScanTool.ScanDeviceListener;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.activity.FirstStartActivity;
import com.veryfit.multi.ui.adapter.DeviceAdapter;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.view.DialogUtil;
import com.veryfit.multi.view.DialogUtil.OnDialogButtonClick;

public class AddDeviceFragment extends BaseFragment implements OnClickListener {
	private CoreServiceProxy mCore = CoreServiceProxy.getInstance();
	private BleScanTool sTool = BleScanTool.getInstance();
	private ArrayList<BleDevice> mDeviceList = new ArrayList<BleDevice>();

	private String mDeviceAddr = "";
	private View mRootView = null;
	private boolean isPrepared = false;
	private ImageView reRefresh;
	private ProgressBar pb;
	private ListView lv_devices;
	private DeviceAdapter adapter;
	private FrameLayout fl_notice;
	private TextView scanTitle;
	private LinearLayout ll_refresh;
	private Button btn_refresh, btn_bound;

	private OnFinishListener mOnFinishListener = null;

	// private boolean isScanning;
	private Handler mHandler = new Handler() {
		public void handleMessage(android.os.Message msg) {
			// isScanning = false;
			// scanDevice(isScanning);
			pb.setVisibility(View.INVISIBLE);
			scanTitle.setText(R.string.refresh_fail_title);
			reRefresh.setVisibility(View.VISIBLE);
			/** 测试用 */
			// bindSuccess();
		};
	};
	
	


	private void bindSuccess() {
		AppSharedPreferences.getInstance().setBindDeviceAddr(mDeviceAddr);
		mCore.write(SettingsCmd.getInstance().getTimeSettingsCmd());
	}

	private void timeSettingsSuccess() {
		if (AppSharedPreferences.getInstance().isFirstStartApp()) {
			((FirstStartActivity) getActivity()).jumpToSettings();
		} else {
			if (mOnFinishListener != null) {
				mOnFinishListener.OnFinish();
			}
		}
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.activity_scan_device, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	public void initView() {
		pb = (ProgressBar) mRootView.findViewById(R.id.scan_progress);
		reRefresh = (ImageView) mRootView.findViewById(R.id.scan_fail);
		ll_refresh = (LinearLayout) mRootView.findViewById(R.id.layout_scanning);
		scanTitle = (TextView) mRootView.findViewById(R.id.scanning_title);
		lv_devices = (ListView) mRootView.findViewById(R.id.lv_devices);
		btn_refresh = (Button) mRootView.findViewById(R.id.device_refresh);
		btn_bound = (Button) mRootView.findViewById(R.id.device_bound);
		fl_notice = (FrameLayout) mRootView.findViewById(R.id.fram_click);

		adapter = new DeviceAdapter(mDeviceList, getActivity());
		lv_devices.setAdapter(adapter);
		lv_devices.setOnItemClickListener(onDeviceChoice);

		btn_bound.setVisibility(View.INVISIBLE);
		// fl_notice.setVisibility(View.INVISIBLE);
		// scanTitle.setVisibility(View.INVISIBLE);

		btn_bound.setOnClickListener(this);
		btn_refresh.setOnClickListener(this);
		fl_notice.setOnClickListener(this);

		mCore.addListener(mAppListener);
		// if (mCore.isAvailable()) {
		// checkBluethoothConection();
		// }
		startScanDevice();
	}

	private OnItemClickListener onDeviceChoice = new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			adapter.checkDevice = (BleDevice) parent.getItemAtPosition(position);
			btn_bound.setVisibility(View.VISIBLE);
			adapter.notifyDataSetChanged();
		}
	};

	@Override
	public void onThemeChanged() {

	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared) {
			return;
		}

	}

	/**
	 * 判断蓝牙状态
	 */
	private boolean checkBluethoothConection() {
		boolean flag = sTool.isBluetoothOpen();
		if (!flag) {
			// 通知用户蓝牙未打开
			fl_notice.setVisibility(View.INVISIBLE);
			scanTitle.setVisibility(View.INVISIBLE);
			DialogUtil.showBleEnableDialog(getActivity());
			// }else{
			// 开始扫描设备[如果第一次进来时蓝牙开启状态下需要自动扫描]
			// scanDevice(true);
			// startScanDevice();
		}
		return flag;
	}

	private void scanDevice(boolean isScan) {
		sTool.addFilterName(Constant.DEVICE_NAME);
		sTool.addFilterName(Constant.DEVICE_NAME1);
		sTool.addFilterName(Constant.DEVICE_NAME2);
		sTool.addFilterName(Constant.DEVICE_NAME3);
		sTool.addFilterName(Constant.DEVICE_NAME4);
		sTool.addScanDeviceListener(mScanDeviceListener);
		sTool.scanLeDevice(isScan);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.device_refresh:
			startScanDevice();
			break;
		case R.id.device_bound:
			adapter.binding = true;
			adapter.notifyDataSetChanged();
			scanDevice(false);
			btn_refresh.setEnabled(false);
			btn_bound.setEnabled(false);
			mCore.connect(adapter.checkDevice.mDeviceAddress);
			mDeviceAddr = adapter.checkDevice.mDeviceAddress;
			break;
		case R.id.fram_click:
			startScanDevice();
			break;

		default:
			break;
		}
	}

	private void onBindFinish(final boolean success) {
		getActivity().runOnUiThread(new Runnable() {

			@Override
			public void run() {
				btn_refresh.setEnabled(true);
				btn_bound.setEnabled(true);
				adapter.binding = false;
				adapter.notifyDataSetChanged();
				if (success) {
					bindSuccess();
				}
			}
		});
	}

	public void startScanDevice() {
		if (!checkBluethoothConection()) {
			return;
		}
		mDeviceList.clear();
		// if (!isScanning) {
		// isScanning = true;
		showStartScaning();
		adapter.checkDevice = null;
		scanDevice(true);
		// }
	}

	public void close() {
		mCore.removeListener(mAppListener);
		sTool.removeScanDeviceListener(mScanDeviceListener);
		if (sTool.isScanning()) {
			scanDevice(false);
		}
	}

	private ScanDeviceListener mScanDeviceListener = new ScanDeviceListener() {

		@Override
		public void onFinish() {
			// isScanning = false;
			showNoDeviceFound();
		}

		@Override
		public void onFind(BleDevice device) {
			showList(device);
		}
	};

	private void showNoDeviceFound() {
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				if (mDeviceList.size() == 0) {
					pb.setVisibility(View.INVISIBLE);
					scanTitle.setText(R.string.refresh_fail_title);
					reRefresh.setVisibility(View.VISIBLE);
				}
				btn_refresh.setEnabled(true);
			}
		});
	}

	private void showStartScaning() {
		lv_devices.setVisibility(View.GONE);
		ll_refresh.setVisibility(View.VISIBLE);
		pb.setVisibility(View.VISIBLE);
		scanTitle.setText(R.string.scaning_title);
		reRefresh.setVisibility(View.GONE);
		btn_refresh.setEnabled(false);
		btn_bound.setVisibility(View.GONE);
	}

	private void showList(final BleDevice device) {
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				mDeviceList.add(device);
				Collections.sort(mDeviceList);
				DebugLog.d("size = " + mDeviceList.size());
				// 更新界面等操作
				adapter.notifyDataSetChanged();
				lv_devices.setVisibility(View.VISIBLE);
				ll_refresh.setVisibility(View.GONE);
			}
		});
	}

	public void setOnFinishListener(OnFinishListener listener) {
		mOnFinishListener = listener;
	}

	private APPCoreServiceListener mAppListener = new APPCoreServiceListener() {

		@Override
		public void onCoreServiceConnected() {
			startScanDevice();
			// checkBluethoothConection();
		}

		@Override
		public void onBlueToothError(int error) {
			if (error == BleStatus.STATE_ON) {
				// 蓝牙已开启。什么都不用做，搜索有搜索按钮
				fl_notice.setVisibility(View.VISIBLE);
				scanTitle.setVisibility(View.VISIBLE);
				startScanDevice();
			}
		}

		@Override
		public void onBLEConnected() {
			mCore.writeForce(BindUnbindCmd.getInstance().getBindCmd());
		}

		@Override
		public void onBLEConnecting() {
		}

		@Override
		public void onBLEDisConnected(String address) {
//			onBindFinish(false);
		}

		@Override
		public void onBindUnbind(byte status) {
			if (status == BindUnbindCmd.STATUS_BIND_SUCCESS) {
				// 绑定成功
				onBindFinish(true);
				// 信息设置?
			}
		}
		@Override
		public void onSettingsSuccess(byte cmdKey, boolean success) {
			if (success) {
				DebugLog.e("设置成功： " + cmdKey);
				if (cmdKey == SettingsCmd.KEY_TIME_SETTINGS) {
					DebugLog.e("时间设置成功。。。");
					timeSettingsSuccess();
				}
			} else {
				// 设置失败，可能是硬件问题，或者是设备断开了
				DebugLog.e("设置失败： " + cmdKey);
			}
		}
	};

	/**
	 * 绑定设备成功后返回
	 * */
	public interface OnFinishListener {
		void OnFinish();
	}
}
