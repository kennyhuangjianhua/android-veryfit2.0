package com.veryfit.multi.ui.fragment.main;

import java.util.Calendar;
import java.util.concurrent.CopyOnWriteArrayList;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.util.TempUtil;
import com.veryfit.multi.view.DataShowView;
import com.veryfit.multi.view.DataShowView.DataModel;
import com.veryfit.multi.view.DetailChart.PageData;
import com.veryfit.multi.view.DetailViewPager;
import com.veryfit.multi.view.DetailViewPager.PageListener;

/** 详情 */
public class DetailsFragment extends BaseFragment implements PageListener {

	private String[] WEEK_LABELS;

	private String[] MONTH_LABELS;

	private String[] YEAR_LABELS;

	private String[] NIGHT_LABELS;

	private int DAY_LABLE_COLOR;

	private int NIGHT_LABLE_COLOR;

	private String[] lables;

	private View mRootView = null;

	private boolean isPrepared = false;

	private DetailViewPager pager;

	private RadioGroup chartTypeGroup, pageTypeGroup;

	private DataShowView dataView0, dataView1;


	private HandlerThread mLoadDataThread = null;
	private Handler mLoadDataHandler = new Handler();

	private int dataIndex;

	/**
	 * viewPage 的数据加载做分页功能，每次加载4条数据，pageIndex表示当前已经加载了几页数据 ,
	 * 因为有一个预览数据1条，所以pageIndex = 0时，最多有5条
	 */
	private int pageIndex;

	/**
	 * chartType 0-->week 1-->month , 2-->year pageType 0-->day 1-->night
	 */
	private int chartType, pageType;

	/** 将查到的数据放到这个地方 */
	private CopyOnWriteArrayList<PageData> sportWeekData, sportMonthData, sportYearData, sleepWeekData, sleepMonthData, sleepYearData;

	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_main_details, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	private void initView() {
		pager = (DetailViewPager) (mRootView.findViewById(R.id.chart_container));
		chartTypeGroup = (RadioGroup) mRootView.findViewById(R.id.chartType);
		pageTypeGroup = (RadioGroup) mRootView.findViewById(R.id.dayOrNight);
		dataView0 = (DataShowView) mRootView.findViewById(R.id.data0);
		dataView1 = (DataShowView) mRootView.findViewById(R.id.data1);

		chartTypeGroup.setOnCheckedChangeListener(onChartTypeChange);
		pageTypeGroup.setOnCheckedChangeListener(onPageChange);
		pager.setListener(this);

		DataModel model1 = new DataModel("", "");
		DataModel model2 = new DataModel("", "");
		DataModel model3 = new DataModel("", "");
		dataView0.initDatas(model1, model2, model3);
		DataModel model4 = new DataModel("", "");
		DataModel model5 = new DataModel("", "");
		DataModel model6 = new DataModel("", "");
		dataView1.initDatas(model4, model5, model6);

		WEEK_LABELS = getResources().getStringArray(R.array.detail_act_week_label);
		MONTH_LABELS = getResources().getStringArray(R.array.detail_act_month_label);
		YEAR_LABELS = getResources().getStringArray(R.array.detail_act_year_label);
		NIGHT_LABELS = getResources().getStringArray(R.array.detail_sleep_label);
		lables = WEEK_LABELS;
		DAY_LABLE_COLOR = getResources().getColor(R.color.theme_tittle_bg);
		NIGHT_LABLE_COLOR = getResources().getColor(R.color.theme_text_color_lable);

		loadData(false);
	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}
		if (WEEK_LABELS == null) {

		}
		// 填充数据

		if (sleepYearData == null) {

		} else {
			int[] goal = TempUtil.getGoal(LongDateUtil.Calendar2LongDate(Calendar.getInstance()));
			updateFirstDataGoal(sportWeekData, goal, Constant.DETAIL_PAGE_TYPE_SPORT);
			updateFirstDataGoal(sportMonthData, goal, Constant.DETAIL_PAGE_TYPE_SPORT);
			updateFirstDataGoal(sportYearData, goal, Constant.DETAIL_PAGE_TYPE_SPORT);
			updateFirstDataGoal(sleepWeekData, goal, Constant.DETAIL_PAGE_TYPE_SLEEP);
			updateFirstDataGoal(sleepMonthData, goal, Constant.DETAIL_PAGE_TYPE_SLEEP);
			updateFirstDataGoal(sleepYearData, goal, Constant.DETAIL_PAGE_TYPE_SLEEP);
			updateData();
		}

	}

	private void updateFirstDataGoal(CopyOnWriteArrayList<PageData> datas, int[] goal, int pageType) {
		PageData data = datas.get(0);
		data.goal = goal[pageType];
		data.goalString = TempUtil.getGoalString(getResources(), data.goal, pageType);
	}

	/** 每种数据先加载一条 ， 再加载4条，再全部加载 */
	private void loadData(final boolean updateData) {
		if (!updateData) {
			sportWeekData = TempUtil.getPageDatas(0, Constant.DETAIL_PAGE_TYPE_SPORT, 0);
			pager.setDatas(sportWeekData , Constant.DETAIL_CHART_TYPE_WEEK);
		}
		mLoadDataHandler.post(new Runnable() {

			@Override
			public void run() {
				if (updateData) {
					sportWeekData = TempUtil.getPageDatas(Constant.DETAIL_CHART_TYPE_WEEK, Constant.DETAIL_PAGE_TYPE_SPORT, 0);
				}
				sportMonthData = TempUtil.getPageDatas(Constant.DETAIL_CHART_TYPE_MONRH, Constant.DETAIL_PAGE_TYPE_SPORT, 0);
				sportYearData = TempUtil.getPageDatas(Constant.DETAIL_CHART_TYPE_YEAR, Constant.DETAIL_PAGE_TYPE_SPORT, 0);
				DebugLog.d("size = " + sportYearData.size());
				sleepWeekData = TempUtil.getPageDatas(Constant.DETAIL_CHART_TYPE_WEEK, Constant.DETAIL_PAGE_TYPE_SLEEP, 0);
				sleepMonthData = TempUtil.getPageDatas(Constant.DETAIL_CHART_TYPE_MONRH, Constant.DETAIL_PAGE_TYPE_SLEEP, 0);
				sleepYearData = TempUtil.getPageDatas(Constant.DETAIL_CHART_TYPE_YEAR, Constant.DETAIL_PAGE_TYPE_SLEEP, 0);
				dataIndex = 0;
				updateData();
				loadMoreData(updateData);
			}
		});
	}

	/** 加载页面数据 */
	private void loadMoreData(final boolean updateData) {
		mLoadDataHandler.post(new Runnable() {
			@Override
			public void run() {
				// 每次加载4条
				int pageSize = 4;
				// 加载4条数据
				sportWeekData.addAll(TempUtil.getPageMoreDatas(Constant.DETAIL_CHART_TYPE_WEEK, Constant.DETAIL_PAGE_TYPE_SPORT, 0, pageSize));
				sportMonthData.addAll(TempUtil.getPageMoreDatas(Constant.DETAIL_CHART_TYPE_MONRH, Constant.DETAIL_PAGE_TYPE_SPORT, 0, pageSize));
				sportYearData.addAll(TempUtil.getPageMoreDatas(Constant.DETAIL_CHART_TYPE_YEAR, Constant.DETAIL_PAGE_TYPE_SPORT, 0, pageSize));
				sleepWeekData.addAll(TempUtil.getPageMoreDatas(Constant.DETAIL_CHART_TYPE_WEEK, Constant.DETAIL_PAGE_TYPE_SLEEP, 0, pageSize));
				sleepMonthData.addAll(TempUtil.getPageMoreDatas(Constant.DETAIL_CHART_TYPE_MONRH, Constant.DETAIL_PAGE_TYPE_SLEEP, 0, pageSize));
				sleepYearData.addAll(TempUtil.getPageMoreDatas(Constant.DETAIL_CHART_TYPE_YEAR, Constant.DETAIL_PAGE_TYPE_SLEEP, 0, pageSize));
				updateData();
				// 加载剩余的全部
				if (!updateData) {
					sportWeekData.addAll(TempUtil.getPageLeftDatas(Constant.DETAIL_CHART_TYPE_WEEK, Constant.DETAIL_PAGE_TYPE_SPORT, pageSize));
					sportMonthData.addAll(TempUtil.getPageLeftDatas(Constant.DETAIL_CHART_TYPE_MONRH, Constant.DETAIL_PAGE_TYPE_SPORT, pageSize));
					sportYearData.addAll(TempUtil.getPageLeftDatas(Constant.DETAIL_CHART_TYPE_YEAR, Constant.DETAIL_PAGE_TYPE_SPORT, pageSize));
					sleepWeekData.addAll(TempUtil.getPageLeftDatas(Constant.DETAIL_CHART_TYPE_WEEK, Constant.DETAIL_PAGE_TYPE_SLEEP, pageSize));
					sleepMonthData.addAll(TempUtil.getPageLeftDatas(Constant.DETAIL_CHART_TYPE_MONRH, Constant.DETAIL_PAGE_TYPE_SLEEP, pageSize));
					sleepYearData.addAll(TempUtil.getPageLeftDatas(Constant.DETAIL_CHART_TYPE_YEAR, Constant.DETAIL_PAGE_TYPE_SLEEP, pageSize));
				}
				updateData();
			}
		});
	}

	@Override
	public void onThemeChanged() {
		DebugLog.e("详情收到主题切换的通知");
	}

	private OnCheckedChangeListener onChartTypeChange = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			//更改index ，更改逻辑：从周到月时，就到对应的月，从月到周时，就到对应月的第一周，年转换相同
			switch (checkedId) {
			case R.id.week:
				if (chartType == Constant.DETAIL_CHART_TYPE_MONRH) {
					dataIndex *= 4;
				} else {
					dataIndex *= 54;
				}
				chartType = Constant.DETAIL_CHART_TYPE_WEEK;
				break;
			case R.id.month:
				if (chartType == Constant.DETAIL_CHART_TYPE_WEEK) {
					dataIndex /= 4;
				} else {
					dataIndex *= 12;
				}
				chartType = Constant.DETAIL_CHART_TYPE_MONRH;
				break;
			case R.id.year:
				if (chartType == Constant.DETAIL_CHART_TYPE_WEEK) {
					dataIndex /= 54;
				} else {
					dataIndex /= 12;
				}
				chartType = Constant.DETAIL_CHART_TYPE_YEAR;
				break;
			}
			updateLables();
			updateData();
		}
	};

	private OnCheckedChangeListener onPageChange = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			switch (checkedId) {
			case R.id.day:
				pageType = Constant.DETAIL_PAGE_TYPE_SPORT;
				mRootView.setBackgroundResource(R.drawable.bg_day);
				dataView0.setUnitColor(DAY_LABLE_COLOR);
				dataView1.setUnitColor(DAY_LABLE_COLOR);
				break;
			case R.id.night:
				dataView0.setUnitColor(NIGHT_LABLE_COLOR);
				dataView1.setUnitColor(NIGHT_LABLE_COLOR);
				pageType = Constant.DETAIL_PAGE_TYPE_SLEEP;
				mRootView.setBackgroundResource(R.drawable.bg_night);
				break;
			}
			updateLables();
			updateData();
		}

	};

	private void updateData() {
		if (pageType == Constant.DETAIL_PAGE_TYPE_SPORT) {
			switch (chartType) {
			case Constant.DETAIL_CHART_TYPE_WEEK:
				pager.setDatas(sportWeekData, dataIndex , chartType);
				break;
			case Constant.DETAIL_CHART_TYPE_MONRH:
				pager.setDatas(sportMonthData, dataIndex , chartType);
				break;
			case Constant.DETAIL_CHART_TYPE_YEAR:
				pager.setDatas(sportYearData, dataIndex , chartType);
				break;
			}
		} else {

			switch (chartType) {
			case Constant.DETAIL_CHART_TYPE_WEEK:
				pager.setDatas(sleepWeekData, dataIndex , chartType);
				break;
			case Constant.DETAIL_CHART_TYPE_MONRH:
				pager.setDatas(sleepMonthData, dataIndex , chartType);
				break;
			case Constant.DETAIL_CHART_TYPE_YEAR:
				pager.setDatas(sleepYearData, dataIndex , chartType);
				break;
			}
			

		}
	}

	private void updateLables() {
		if (pageType == 1) {
			lables = NIGHT_LABELS;
		} else {
			switch (chartType) {
			case Constant.DETAIL_CHART_TYPE_WEEK:
				lables = WEEK_LABELS;
				break;
			case Constant.DETAIL_CHART_TYPE_MONRH:
				lables = MONTH_LABELS;
				break;
			case Constant.DETAIL_CHART_TYPE_YEAR:
				lables = YEAR_LABELS;
				break;
			}
		}

	}

	@Override
	public void onPageSelected(PageData selectedData, int index) {
		dataIndex = index;
		DebugLog.d("dataIndex = " + dataIndex);
		for (int i = 0; i < 6; i++) {
			if (i < 3) {
				dataView0.updateData(i, lables[i], selectedData.dataShow0[i]);
			} else {
				dataView1.updateData(i % 3, lables[i], selectedData.dataShow0[i]);
			}
		}
	}

	@Override
	public void needMore(int pageIndex) {

	}

	/** 有新的数据同步，则需要更新 */
	public void updateHealthData() {
		DebugLog.e("详情界面收到数据更新的通知");
		loadData(true);

	}
}
