package com.veryfit.multi.ui.fragment.firstbound;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioGroup;

import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.share.AppSharedPreferences;

public class PersonSexFragment extends PersonBaseFragment {
	private View mRootView = null;
	private boolean isPrepared = false;
	private RadioGroup radioGroup;

	private Button next;

	public PersonSexFragment(OnPagerChangedListener listener) {
		super(listener);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_person_sex, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	public void initView() {
		next = (Button) mRootView.findViewById(R.id.pserson_sex_next);
		radioGroup = (RadioGroup) mRootView.findViewById(R.id.person_sex);
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				AppSharedPreferences.getInstance().setUserSex(radioGroup.getCheckedRadioButtonId() == R.id.person_sex_boy);
				setPagerIndex(1);
			}
		});
	}

	@Override
	public void onThemeChanged() {

	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}

		radioGroup.check(AppSharedPreferences.getInstance().getUserSex() ? R.id.person_sex_boy : R.id.person_sex_girl);
	}

}
