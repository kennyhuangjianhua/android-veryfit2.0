package com.veryfit.multi.ui.fragment.firstbound;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.veryfit.multi.R;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.view.RulerView;

public class PersonBirthdayFragment extends PersonBaseFragment implements View.OnClickListener {
	public PersonBirthdayFragment(OnPagerChangedListener listener) {
		super(listener);
	}

	private View mRootView = null;
	private boolean isPrepared = false;

	private Button next, previous;

	private RulerView ruler_birthday;

	private int year = -1;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_person_birthday, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	public void initView() {
		next = (Button) mRootView.findViewById(R.id.person_birthday_next);
		previous = (Button) mRootView.findViewById(R.id.person_birthday_previous);
		ruler_birthday = (RulerView) mRootView.findViewById(R.id.person_inof_birthday);
		next.setOnClickListener(this);
		previous.setOnClickListener(this);
	}

	@Override
	public void onThemeChanged() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}
		if (year == -1) {
			year = AppSharedPreferences.getInstance().getUserBirthdayYear();
		}
		ruler_birthday.setData(year);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.person_birthday_previous) {
			setPagerIndex(2);
		}

		if (v.getId() == R.id.person_birthday_next) {
			year = ruler_birthday.getCenterData();
			Toast.makeText(getActivity(), "生日:" + year, Toast.LENGTH_LONG).show();
			AppSharedPreferences.getInstance().setUserBirthdayYear(year);
			setPagerIndex(4);
		}
	}
}
