package com.veryfit.multi.ui.fragment.main;

import java.lang.reflect.Type;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.getinfo.GetInfoCmd;
import com.project.library.share.LibSharedPreferences;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.activity.device.AddDeviceActivity;
import com.veryfit.multi.ui.activity.device.DeviceUpdateActivity;
import com.veryfit.multi.util.HttpUtil;
import com.veryfit.multi.view.group.ItemLableValue;
import com.veryfit.multi.view.DialogUtil;
import com.veryfit.multi.view.DialogUtil.OnUnBoundDeviceListener;
import com.veryfit.multi.vo.json.DeviceUpdateInfo;
import com.veryfit.multi.vo.json.DeviceUpdateList;

/** 设备 */
public class DeviceFragment extends BaseFragment implements OnClickListener {
	
	private static final int REQUEST_UPDATE_DEVICE = 1;

    private View mRootView = null;
    private boolean isPrepared = false;
	private ItemLableValue remind_phone, remind_sport, remind_alarm , device_update;

	private TextView deviceName, syncTime, deviceVersion, battery;
    private TextView unbind;
	protected CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	private AppSharedPreferences share;
	
	private DeviceUpdateInfo updateInfo;
	
	private Handler handler = new Handler();



	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);
		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_main_device, container, false);
			mCore.addListener(mAppListener);
			share = AppSharedPreferences.getInstance();
			initView();
			isPrepared = true;
			lazyLoad();
		}
		return mRootView;
	}

	private void initView() {
		remind_phone = (ItemLableValue) mRootView.findViewById(R.id.remind_phone);
		remind_alarm = (ItemLableValue) mRootView.findViewById(R.id.remind_alarm);
		remind_sport = (ItemLableValue) mRootView.findViewById(R.id.remind_sport);
		remind_alarm.setValueState(true, R.string.alarm_count);

		deviceName = (TextView) mRootView.findViewById(R.id.deviceName);
		syncTime = (TextView) mRootView.findViewById(R.id.syncTime);
		deviceVersion = (TextView) mRootView.findViewById(R.id.deviceVersion);
		battery = (TextView) mRootView.findViewById(R.id.battery);
		device_update = (ItemLableValue) mRootView.findViewById(R.id.device_update);
		

		unbind = (TextView) mRootView.findViewById(R.id.unbind);

		unbind.setOnClickListener(this);
		
		getDeviceUpdateInfo();
	}

	@Override
	public void onInVisible() {
		super.onInVisible();

		if (mCore != null) {
			mCore.removeListener(mAppListener);
		}
	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}
		mCore.addListener(mAppListener);

		remind_phone.setOpen(share.getDeviceRemindPhoneSwitch());
		remind_sport.setOpen((share.getDeviceRemindSportRepetitions() & 1) == 1);
		// 填充数据

		updateTitle();
		updateBindTextInfo();

		// 每次进来都获取一次设备基本信息
		if (mCore.isDeviceConnected()) {
			mCore.write(GetInfoCmd.getInstance().getGetInfoCmd(GetInfoCmd.KEY_BASIC));
		}
		
		
	}

	

	private void updateTitle() {
		// deviceName.setText("");
		String time = AppSharedPreferences.getInstance().getDeviceSyncEndTime();
		if (TextUtils.isEmpty(time)) {
			syncTime.setText(getString(R.string.sync_time_null));
		} else {
			syncTime.setText(String.format(getString(R.string.sync_time), time));
		}
		deviceVersion.setText(String.format(getString(R.string.device_version), LibSharedPreferences.getInstance().getDeviceFirmwareVersion()));
		battery.setText(String.format(getString(R.string.battery), LibSharedPreferences.getInstance().getDeviceEnerge()));
	}

	@Override
	public void onThemeChanged() {
		DebugLog.e("设备收到主题切换的通知");
	}

	@Override
	public void onClick(View v) {
		DebugLog.e("onclick");
		switch (v.getId()) {
		case R.id.unbind:
			onUnbindTextClick();
			break;
		case R.id.device_update:
			DebugLog.e("onclickupdate");
			Intent updateDevice = new Intent(getActivity() , DeviceUpdateActivity.class);
			updateDevice.putExtra("updateInfo", updateInfo);
			startActivityForResult(updateDevice, REQUEST_UPDATE_DEVICE);
			break;

		default:
			break;
		}
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode == REQUEST_UPDATE_DEVICE && resultCode != 0){
			device_update.setValueState(false, R.string.isLastVersion);
		}
	}

	protected APPCoreServiceListener mAppListener = new APPCoreServiceListener() {
		public void onBLEDisConnected(String address) {
		}

		@Override
		public void onSettingsSuccess(byte cmdKey, boolean success) {
		}

		@Override
		public void onDataSendTimeOut(byte[] data) {
			// 发送超时的在这里判断
			
		}
		

		@Override
		public void onGetInfo(byte cmdKey) {
			if (cmdKey == GetInfoCmd.KEY_BASIC) {
				updateTitle();

				if (CoreServiceProxy.getInstance().isDeviceConnected()) {
					CoreServiceProxy.getInstance().write(GetInfoCmd.getInstance().getGetInfoCmd(GetInfoCmd.KEY_FUNCTION));
				}

			} else if (cmdKey == GetInfoCmd.KEY_FUNCTION) {
				int alarmMaxCount = LibSharedPreferences.getInstance().getDeviceAlarmMaxCount();

				DebugLog.d("支持闹钟最大个数：" + alarmMaxCount);
			}
		}

		@Override
		public void onBindUnbind(byte status) {

			if (status == BindUnbindCmd.STATUS_BIND_SUCCESS) {
				DebugLog.e("绑定成功");
				getDeviceUpdateInfo();
			} else if (status == BindUnbindCmd.STATUS_UNBIND_SUCCESS) {
				// 删除绑定设备地址信息
				AppSharedPreferences.getInstance().setBindDeviceAddr("");
				DebugLog.e("解绑成功");
				mCore.removeListener(this);
				Toast.makeText(getActivity(), R.string.ble_unbind_success, Toast.LENGTH_SHORT).show();
			}

			updateBindTextInfo();
		}
	};
	
	private void getDeviceUpdateInfo() {
		if(HttpUtil.isNetworkConnected(getActivity()) && !share.getBindDeviceAddr().equals("")){
			new Thread(){
				public void run() {
					String json = HttpUtil.get(HttpUtil.PATH, null);
					DebugLog.d(json);
					Type listType = new TypeToken<DeviceUpdateList>(){}.getType();
					Gson gson = new Gson();
					DeviceUpdateList list = gson.fromJson(json, listType);
					if (list != null && !list.firmwareInfo.isEmpty())
					{
						updateInfo = list.getMyDevice(LibSharedPreferences.getInstance().getDeviceId());
						if(updateInfo.version > LibSharedPreferences.getInstance().getDeviceFirmwareVersion()){
							openDeviceUpdate();
						}
					}
				};
			}.start();
		}
	}
	
	private void openDeviceUpdate(){
		getActivity().runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				device_update.setOnClickListener(DeviceFragment.this);
				device_update.setValueState(true, R.string.canUpdate);
			}
		});
	}
	

	/** 更新解绑按键的功能以及显示 */
	private void updateBindTextInfo() {
		if (mCore.isAvailable()) {
			if(share.getBindDeviceAddr().equals("")){
				unbind.setText(getString(R.string.bind));
				device_update.setValueState(false, R.string.isLastVersion);
			}else  {//if  (mCore.isDeviceConnected())
				unbind.setText(getString(R.string.unbind));
//			} else{
//				unbind.setText(getString(R.string.conn));
			}
			
		}
	}

	private void onUnbindTextClick() {
		if (mCore.isAvailable()) {
			if(share.getBindDeviceAddr().equals("")){
				startActivity(new Intent(getActivity(), AddDeviceActivity.class));
			}else if (mCore.isDeviceConnected()) {
				mCore.writeForce(BindUnbindCmd.getInstance().getUnbindCmd());
			} else{
//				handler.postDelayed(connFail, 5000L);
				AppSharedPreferences.getInstance().setBindDeviceAddr("");
				device_update.setValueState(false, R.string.isLastVersion);
				updateBindTextInfo();
			}
		}
	}
	
	private Runnable connFail = new Runnable() {
		
		@Override
		public void run() {
			mCore.disconnect();
			AppSharedPreferences.getInstance().setBindDeviceAddr("");
		}
	};
}
