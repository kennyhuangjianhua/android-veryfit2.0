package com.veryfit.multi.ui.activity.mine;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.view.DialogUtil;
import com.veryfit.multi.view.DialogUtil.OnTimePickerSelectListener;
import com.veryfit.multi.view.DialogUtil.OnWheelSelectorListener;

public class SysSettingsActivity extends BaseActivity implements OnClickListener {
	private TextView tv_units;
	private TextView tv_time_notice;
	private ImageView back;
	private ImageView iv_about_us;
	private ImageView iv_normal_problem;
	private ImageView iv_app_version;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		setContentView(R.layout.activity_sys_settgins);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void initView() {
		// TODO Auto-generated method stub
		super.initView();
		tv_units=(TextView) findViewById(R.id.label_metric);
		tv_time_notice=(TextView) findViewById(R.id.label_day_notice);
		back=(ImageView) findViewById(R.id.bar_left);
		iv_about_us=(ImageView) findViewById(R.id.icon_about_us);
		iv_app_version=(ImageView) findViewById(R.id.icon_app_version);
		iv_normal_problem=(ImageView) findViewById(R.id.icon_normal_probleml);
	}

	@Override
	protected void initEvent() {
		// TODO Auto-generated method stub
		super.initEvent();
		tv_units.setOnClickListener(this);
		back.setOnClickListener(this);
		tv_time_notice.setOnClickListener(this);
		iv_about_us.setOnClickListener(this);
		iv_app_version.setOnClickListener(this);
		iv_normal_problem.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.label_metric:
			DialogUtil.showUnitSetDialog(this, new OnWheelSelectorListener() {
				
				@Override
				public void onWheelSelect(Object obj) {
					// TODO Auto-generated method stub
					Toast.makeText(SysSettingsActivity.this, (String)obj, Toast.LENGTH_LONG).show();
				}
			});
			break;
		case R.id.bar_left:
			finish();
			break;
		case R.id.icon_about_us:
			break;
		case R.id.icon_app_version:
			break;
		case R.id.icon_normal_probleml:
			break;
		case R.id.label_day_notice:
			DialogUtil.showWheelTimeDialog(this, 8, 55, new OnTimePickerSelectListener() {
				
				@Override
				public void OnTimePickerSelect(int hour, int minute) {
					// TODO Auto-generated method stub
					tv_time_notice.setText(getString(R.string.hour_minute, hour,minute));
				}
			});
			break;
		default:
			break;
		}
	}

	@Override
	protected void onThemeChanged() {
		// TODO Auto-generated method stub

	}
}
