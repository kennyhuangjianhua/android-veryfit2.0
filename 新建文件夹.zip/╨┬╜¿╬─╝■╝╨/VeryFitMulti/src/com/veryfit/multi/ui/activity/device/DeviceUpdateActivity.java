package com.veryfit.multi.ui.activity.device;

import java.io.File;
import java.lang.ref.WeakReference;

import no.nordicsemi.android.dfu.DfuService;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.database.AlarmNotify;
import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.WareUpdateCmd;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.share.LibSharedPreferences;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.util.HttpUtil;
import com.veryfit.multi.vo.json.DeviceUpdateInfo;

public class DeviceUpdateActivity extends BaseActivity implements OnClickListener{
	private static final int UPDATE_CMD_RESULT = 10;
	
	private static final int UPDATE_CMD_FAILED = 11;
	
	
	private TextView progressView;
	
//	private int deviceVersion;
	
	private DeviceUpdateInfo updateInfo;

	private String filePath;
	
	private ProgressBar progressBar;
	
	CoreServiceProxy mCore = CoreServiceProxy.getInstance();
	
	private static boolean updating;
	
	private static class UpdateHandler extends Handler{
		WeakReference<DeviceUpdateActivity> weak;
		
		public UpdateHandler(DeviceUpdateActivity activity){
			weak = new WeakReference<DeviceUpdateActivity>(activity);
		}
		
		public void handleMessage(android.os.Message msg) {
			DeviceUpdateActivity activity = weak.get();
			if(activity == null){
				return;
			}
			switch (msg.what) {
			case HttpUtil.DOWN_LOAD_PROGRESS:
				int progress = (Integer)msg.obj;
				activity.progressView.setText(activity.getString(R.string.otaDownLoading, progress));
				activity.progressBar.setProgress(progress);
				if(progress == 100){
					activity.progressView.setText(activity.getString(R.string.otaprepare, progress));
					activity.sendUpdateCmd();
				}
				break;
			case HttpUtil.CONN_ERROR:
				activity.update.setEnabled(true);
				updating = false;
				Toast.makeText(activity, R.string.httpConnError, Toast.LENGTH_SHORT).show();
				break;
			case UPDATE_CMD_FAILED:
				activity.update.setEnabled(true);
				updating = false;
				break;
			case UPDATE_CMD_RESULT:
				byte status = (Byte) msg.obj;
				switch (status) {
				case WareUpdateCmd.STATUS_SUCCESS:
					DebugLog.e("准备升级喽");
					activity.startWareUpdateService();
					break;
				case WareUpdateCmd.STATUS_LOW_BATTERY:
					activity.progressView.setText(R.string.otaLowPower);
					activity.update.setEnabled(true);
					updating = false;
					break;
				case WareUpdateCmd.STATUS_NOT_SUPPORT:
					activity.progressView.setText(R.string.otanotSupport);
					activity.update.setEnabled(true);
					updating = false;
					break;

				default:
					break;
				}
				break;

			default:
				break;
			}
		};
		
	}
	
	private final UpdateHandler handler = new UpdateHandler(this);
	
	
	private Button update;
	
	private CheckBox autoOta;
	
	private int count;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_device_update);
		updateInfo = (DeviceUpdateInfo) getIntent().getSerializableExtra("updateInfo");
		super.onCreate(savedInstanceState);
		filePath = Constant.FILE_PATH + "update_" + LibSharedPreferences.getInstance().getDeviceId() + "_" + updateInfo.version + ".zip";
		
		final LocalBroadcastManager broadcastManager = LocalBroadcastManager.getInstance(this);
		broadcastManager.registerReceiver(mDfuUpdateReceiver, makeDfuUpdateIntentFilter());
	}
	
	@Override
	protected void initView() {
		super.initView();
		update=(Button) findViewById(R.id.btn_update_device);
		progressView = (TextView) findViewById(R.id.update_progress);
		progressBar = (ProgressBar) findViewById(R.id.progressbar_updown);
		
		TextView currentVersion = (TextView) findViewById(R.id.current_version);
		TextView newVersion = (TextView) findViewById(R.id.new_version);
		TextView updateDetail = (TextView) findViewById(R.id.new_version_detail);
		
		currentVersion.setText(LibSharedPreferences.getInstance().getDeviceFirmwareVersion() + "");
		newVersion.setText(updateInfo.version + "");
		//此处需要判断语言设置
		updateDetail.setText(getString(R.string.new_version_detial, getResources().getConfiguration().locale.toString().contains("zh") ? updateInfo.info_ch : updateInfo.info_en));
		
		autoOta = (CheckBox) findViewById(R.id.autoOta);
		autoOta.setText(getString(R.string.otaTestCount , count));
		autoOta.setChecked(AppSharedPreferences.getInstance().getDeviceUpdateAuto());
		autoOta.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				AppSharedPreferences.getInstance().setDeviceUpdateAuto(isChecked);
			}
		});
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		update.setEnabled(!updating);
	}
	
	@Override
	protected void initData() {
		super.initData();
	}
	
	@Override
	protected void initEvent() {
		super.initEvent();
		update.setOnClickListener(this);
	}

	@Override
	protected void onThemeChanged() {

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_update_device:
			updating = true;
			update.setEnabled(false);
			downFile();
//			DialogUtil.showNoPowerDialog(this);
			break;
		case R.id.bar_left:
			finish();
			break;

		default:
			break;
		}
	}
	
	private void downFile(){
		File dir = new File(Constant.FILE_PATH);
		if(!dir.exists()){
			dir.mkdirs();
		}
		File file = new File(filePath);
		if(!file.exists()){
			if(HttpUtil.isNetworkConnected(this)){
				new Thread(){
					public void run() {
						HttpUtil.downLoad(handler, filePath, updateInfo.file);
					};
				}.start();
			}else{
				Toast.makeText(this, R.string.httpConnError, Toast.LENGTH_SHORT).show();
			}
		}else{
			sendUpdateCmd();
		}
	}

	private void sendUpdateCmd() {
		if(mCore.isDeviceConnected()){
			mCore.addListener(mAppListener);
			if(mCore.writeForce(WareUpdateCmd.getInstance().getWareUpdateCmd())){
				progressView.setText(R.string.otaprepare);
				progressBar.setProgress(0);
				return;
			}
		}
		update.setEnabled(true);
		updating = false;
	}
	
	private APPCoreServiceListener mAppListener = new APPCoreServiceListener() {


		@Override
		public void onWareUpdate(byte status) {
			handler.sendMessage(handler.obtainMessage(UPDATE_CMD_RESULT, status));
		}
		@Override
		public void onDataSendTimeOut(byte[] data) {
			// 发送超时的在这里判断
			handler.sendEmptyMessage(UPDATE_CMD_FAILED);
			
		}
		
		public void onBLEConnected() {
			if(!updating && autoOta.isChecked()){
				sendUpdateCmd();
			}
		};
		
		public void onSettingsSuccess(byte cmdKey, boolean success) {
			if(success && cmdKey == SettingsCmd.KEY_TIME_SETTINGS){
				if(!updating && autoOta.isChecked()){
					sendUpdateCmd();
				}
			}
		};

	};
	
	private void startWareUpdateService() {
		final boolean keepBond = false;
		final Intent service = new Intent(this, DfuService.class);
		String addr = AppSharedPreferences.getInstance().getBindDeviceAddr();
		if (TextUtils.isEmpty(addr)) {
			DebugLog.e("设备都没有，不升级");
			return;
		}
		DebugLog.e("开始升级");
		service.putExtra(DfuService.EXTRA_DEVICE_ADDRESS, addr);
		service.putExtra(DfuService.EXTRA_DEVICE_NAME, "DfuTarg");
		service.putExtra(DfuService.EXTRA_FILE_PATH, filePath);
		service.putExtra(DfuService.EXTRA_KEEP_BOND, keepBond);
		startService(service);
	}
	
	private IntentFilter makeDfuUpdateIntentFilter() {
		final IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(DfuService.BROADCAST_PROGRESS);
		intentFilter.addAction(DfuService.BROADCAST_ERROR);
		return intentFilter;
	}

	private final BroadcastReceiver mDfuUpdateReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(final Context context, final Intent intent) {
			// DFU is in progress or an error occurred
			final String action = intent.getAction();
			DebugLog.d("*****" + action);
			if (DfuService.BROADCAST_PROGRESS.equals(action)) {
				final int progress = intent.getIntExtra(DfuService.EXTRA_DATA, 0);
				final int currentPart = intent.getIntExtra(DfuService.EXTRA_PART_CURRENT, 1);
				final int totalParts = intent.getIntExtra(DfuService.EXTRA_PARTS_TOTAL, 1);
				updateProgressBar(progress, currentPart, totalParts, false, false);
			}else if(DfuService.BROADCAST_ERROR.equals(action)){
				update.setEnabled(true);
				progressBar.setProgress(0);
				progressView.setText(R.string.otaError);
				updating = false;
			}
		}
	};
	
	private void updateProgressBar(final int progress, final int part, final int total, final boolean error, final boolean connectionError) {
		switch (progress) {
		case DfuService.PROGRESS_CONNECTING:
			progressView.setText(R.string.otaConning);
			break;
		case DfuService.PROGRESS_STARTING:
			progressView.setText(R.string.otaprepare);
			progressBar.setProgress(0);
			break;
		case DfuService.PROGRESS_ENABLING_DFU_MODE:
			break;
		case DfuService.PROGRESS_VALIDATING:
			break;
		case DfuService.PROGRESS_DISCONNECTING:
			progressView.setText(R.string.otaDisConning);
			break;
		case DfuService.PROGRESS_COMPLETED: {
			updating = false;
			progressView.setText(R.string.otaComplete);
			progressBar.setProgress(100);
			mCore.connect(AppSharedPreferences.getInstance().getBindDeviceAddr());
			if(autoOta.isChecked()){
				autoOta.setText(getString(R.string.otaTestCount , ++count));
				return;
			}
			File file = new File(filePath);
			file.delete();
			setResult(1);
		}
			break;
		case DfuService.PROGRESS_ABORTED:
			break;
		default: {
			if (error) {
				// showErrorMessage(progress, connectionError);
			} else {
				progressView.setText(getString(R.string.otaUpdating , progress));
				progressBar.setProgress(progress);
			}
		}
			break;
		}
	}
	
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		final LocalBroadcastManager broadcastManager = LocalBroadcastManager.getInstance(this);
		broadcastManager.unregisterReceiver(mDfuUpdateReceiver);
		mCore.removeListener(mAppListener);
	}

}
