package com.veryfit.multi.ui.activity;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.device.cmd.DeviceBaseCommand;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;

/**
 * 这个是用于设备页中，所有要和设备通讯的activity，它处理了标题栏左右按钮的点击事件，和ble通讯的回调监听，以及正在通讯时的点击，按键事件拦截
 * 
 */
public abstract class BaseNotifyBleActivity extends BaseActivity {

	protected CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	protected boolean sendingData;

	protected ProgressBar progress;
	protected TextView sureBtn;

	protected byte cmdKey;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		initView();
	}

	@Override
	protected void initView() {
		progress = (ProgressBar) findViewById(R.id.progress_circle);
		sureBtn = (TextView) findViewById(R.id.tittle_right);
	}

	protected void showProgress() {
		progress.setVisibility(View.VISIBLE);
		sureBtn.setVisibility(View.GONE);
	}

	protected void showSureBtn() {
		sureBtn.setVisibility(View.VISIBLE);
		progress.setVisibility(View.GONE);
	}

	protected abstract void onSettingsSuccess();

	// protected void onDataSendTimeOut(byte[] data) {
	// sendingData = false;
	// Toast.makeText(this, R.string.bleDataSendTimeOut,
	// Toast.LENGTH_SHORT).show();
	// }

	protected abstract void onDataSendFailed();

	protected abstract void saveDate();

	public void onClick(View v) {
		// if(sendingData){
		// return;
		// }
		switch (v.getId()) {
		case R.id.bar_left:
			finish();
			break;
		case R.id.tittle_right:
			saveDate();
			break;

		default:
			break;
		}
	}

	protected boolean writeData(byte cmd[]) {
		cmdKey = DeviceBaseCommand.getCmdKey(cmd);
		if(!mCore.isDeviceConnected()){
			return false;
		}
		return mCore.write(cmd);
	}

	protected APPCoreServiceListener mAppListener = new APPCoreServiceListener() {
		public void onBLEDisConnected(String address) {
			sendingData = false;
		}

		@Override
		public void onSettingsSuccess(byte cmdKey, boolean success) {
			if (cmdKey == BaseNotifyBleActivity.this.cmdKey) {
				if (success) {
					DebugLog.e("设置成功： " + cmdKey);
					BaseNotifyBleActivity.this.onSettingsSuccess();
				} else {
					DebugLog.e("设置失败： " + cmdKey);
					sendingData = false;
					Toast.makeText(BaseNotifyBleActivity.this, R.string.settingDataFail, Toast.LENGTH_SHORT).show();
					BaseNotifyBleActivity.this.onDataSendFailed();
				}
			}
		}

		@Override
		public void onDataSendTimeOut(byte[] data) {
			if (cmdKey == BaseNotifyBleActivity.this.cmdKey) {
				// BaseNotifyBleActivity.this.onDataSendTimeOut(data);
				DebugLog.e("设置失败： " + cmdKey);
				sendingData = false;
				Toast.makeText(BaseNotifyBleActivity.this, R.string.settingDataFail, Toast.LENGTH_SHORT).show();
				BaseNotifyBleActivity.this.onDataSendFailed();
				// 发送超时的在这里判断
			}

		}
	};

	// public boolean onKeyDown(int keyCode, KeyEvent event) {
	// DebugLog.d("keycode = " + keyCode + " ******sendingData = " +
	// sendingData);
	// if (keyCode == KeyEvent.KEYCODE_BACK && sendingData) {
	// return true;
	// }
	// return super.onKeyDown(keyCode, event);
	// };

	@Override
	protected void onThemeChanged() {

	}

}
