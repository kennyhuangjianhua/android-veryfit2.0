package com.veryfit.multi.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;

import com.project.library.core.CoreServiceProxy;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.fragment.firstbound.AddDeviceFragment;
import com.veryfit.multi.ui.fragment.firstbound.PersonInfoFragment;

/** 第一次进入app[介绍页(介绍页有可能要独立出来)以及第一次搜索设备，设置个人信息] */
public class FirstStartActivity extends BaseActivity {
	private AppSharedPreferences mAppSharedPreferences = AppSharedPreferences.getInstance();
	private BaseFragment mLastFragment;
	private AddDeviceFragment mAddDeviceFragment = null;
	private PersonInfoFragment mPersonInfoFragment = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (mAppSharedPreferences.isFirstStartApp()) {
			init(savedInstanceState);
		} else {
			jumpToNext();
		}
	}

	private void init(Bundle savedInstanceState) {
		// 介绍页独立出去则，先介绍页

		// 介绍页之后才显示正常界面
		setContentView(R.layout.activity_firststart);
		if (savedInstanceState != null) {
			mLastFragment = (BaseFragment) getSupportFragmentManager().getFragment(savedInstanceState, "mLastFragment");
		}

		showAddDeviceFragment();
	}

	private void showAddDeviceFragment() {
		if (mAddDeviceFragment == null) {
			mAddDeviceFragment = new AddDeviceFragment();
		}
		changeFragment(this, mAddDeviceFragment, null);
	}

	private void showPersonInfoFragment() {
		if (mPersonInfoFragment == null) {
			mPersonInfoFragment = new PersonInfoFragment();
		}
		changeFragment(this, mPersonInfoFragment, null);
	}

	private void changeFragment(FragmentActivity activity, BaseFragment newFragment, String tag) {
		if (newFragment == null || mLastFragment == newFragment) {
			return;
		}
		FragmentTransaction transaction = activity.getSupportFragmentManager().beginTransaction();
		if ((mLastFragment != null) && (mLastFragment != newFragment)) {
			transaction.detach(mLastFragment);
		}

		if (!newFragment.isAdded()) {
			transaction.add(R.id.firstfragment_content, newFragment, tag);
		}

		if (newFragment.isDetached()) {
			transaction.attach(newFragment);
		}

		mLastFragment = newFragment;
		transaction.commitAllowingStateLoss();
	}

	/** 移除fragment,并清理fragment里面的各种数据 */
	private void removeFragments() {
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
		if (mAddDeviceFragment != null) {
			mAddDeviceFragment.close();
			transaction.remove(mAddDeviceFragment);
			mAddDeviceFragment = null;
		}
		if (mPersonInfoFragment != null) {
			mPersonInfoFragment.close();
			transaction.remove(mPersonInfoFragment);
			mPersonInfoFragment = null;
		}

		transaction.commitAllowingStateLoss();
		mLastFragment = null;
	}

	@Override
	protected void onSaveInstanceState(Bundle paramBundle) {
		getSupportFragmentManager().putFragment(paramBundle, "mLastFragment", mLastFragment);
		super.onSaveInstanceState(paramBundle);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		if (savedInstanceState != null) {
			mLastFragment = (BaseFragment) getSupportFragmentManager().getFragment(savedInstanceState, "mLastFragment");
		}
	}

	/** 各种信息设置完成之后，跳转主界面 */
	public void jumpToNext() {
		removeFragments();
		startActivity(new Intent(FirstStartActivity.this, MainActivity.class));
		mAppSharedPreferences.setFirstStartApp(false);
		finish();
	}

	/** 第一次进APP，绑定设备成功后，跳转到第一次个人信息设置界面 */
	public void jumpToSettings() {
		showPersonInfoFragment();
	}

	@Override
	protected void onThemeChanged() {
	}

	@Override
	protected void onDestroy() {
		removeFragments();
		super.onDestroy();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			// 返回键按情况处理
			// // 可能是两次按返回键退出
			removeFragments();
			CoreServiceProxy.fini();
			finish();
			android.os.Process.killProcess(android.os.Process.myPid());
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
