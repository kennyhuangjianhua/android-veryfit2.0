package com.veryfit.multi.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import com.veryfit.multi.ui.fragment.SleepFragment;
import com.veryfit.multi.ui.fragment.SportFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class MainDataAdapter extends FragmentPagerAdapter {

	private List<Fragment> frags;

	public MainDataAdapter(FragmentManager fm) {
		super(fm);
		frags = new ArrayList<Fragment>();
		frags.add(new SportFragment());
		frags.add(new SleepFragment());
	}

	@Override
	public Fragment getItem(int arg0) {
		return frags.get(arg0);
	}

	@Override
	public int getCount() {
		return frags.size();
	}
	
//	@Override  
//    public Object instantiateItem(View arg0, int arg1) {  
//        // TODO Auto-generated method stub  
//            try{  
//                ((ViewPager) arg0).addView(list.get(arg1%list.size()),0);  
//                }catch (Exception e) {  
//                    // TODO: handle exception  
//                }  
//            return list.get(arg1%list.size());  
//    } 

}
