package com.veryfit.multi.ui.adapter;

import java.util.ArrayList;
import java.util.List;

import com.veryfit.multi.view.DetailChart;

import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

public class CirclePagerAdapter extends PagerAdapter {

	private List<DetailChart> views = new ArrayList<DetailChart>();

	public CirclePagerAdapter(List<DetailChart> views) {
		super();
		this.views .addAll(views);
	}

	@Override
	public int getItemPosition(Object object) {
		// return super.getItemPosition(object);
		return POSITION_NONE;
	}

	@Override
	public void destroyItem(View arg0, int pos, Object arg2) {
		((ViewPager) arg0).removeView((View)arg2);
	}

	@Override
	public void finishUpdate(View arg0) {
	}

	@Override
	public int getCount() {
		return views.size();
	}

	@Override
	public Object instantiateItem(View arg0, int pos) {
		View v = views.get(pos);
		((ViewPager) arg0).addView(v, 0);
		return v;
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == (arg1);
	}

	@Override
	public void restoreState(Parcelable arg0, ClassLoader arg1) {
	}

	@Override
	public Parcelable saveState() {
		return null;
	}

	@Override
	public void startUpdate(View arg0) {
	}

	public void setAdapterView(ArrayList<DetailChart> adapterView) {
		views.clear();
		views.addAll(adapterView);
	}

}
