package com.veryfit.multi.ui.fragment;

public class OtherFragment {

}
