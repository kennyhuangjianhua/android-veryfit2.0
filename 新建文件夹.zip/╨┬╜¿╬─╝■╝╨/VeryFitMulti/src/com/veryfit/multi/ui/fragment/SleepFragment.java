package com.veryfit.multi.ui.fragment;

import java.util.Calendar;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.util.TempUtil;
import com.veryfit.multi.view.DataShowView.DataModel;
import com.veryfit.multi.view.PointLineView.onDateScrolling;
import com.veryfit.multi.view.DataShowView;
import com.veryfit.multi.view.SleepBarChart;
import com.veryfit.multi.view.SleepPieView;
import com.veryfit.multi.view.group.PointLineParent;
import com.veryfit.multi.vo.SleepData;

public class SleepFragment extends MainPageChildFragment implements OnClickListener, onDateScrolling {

	private View mRootView = null;
	private boolean isPrepared = false;
	private SleepBarChart barChart;

	private SleepPieView pieView;

	private PointLineParent lineParent;

	private SleepData sleepData;

	private DataShowView showView;

	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_sleep, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}
		// notifyParent.onRootViewCreate(mRootView);
		return mRootView;
	}

	private void initView() {

		pieView = (SleepPieView) mRootView.findViewById(R.id.centerDataPie);
		pieView.setOnClickListener(this);

		barChart = (SleepBarChart) mRootView.findViewById(R.id.sleepBarChart);
		barChart.setOnClickListener(this);

		lineParent = (PointLineParent) mRootView.findViewById(R.id.pointLineParent);
		lineParent.getGoToTheDayView().setOnClickListener(this);
		lineParent.setOnDateScrollingLinstener(this);
		lineParent.setType(PointLineParent.TYPE_SLEEP);

		showView = (DataShowView) mRootView.findViewById(R.id.dataShowView);

		int[] colors = barChart.getBarColors();
		DataModel model0 = new DataModel(colors[0], "", getResources().getString(R.string.showDataLableDeep));
		DataModel model1 = new DataModel(colors[1], "", getResources().getString(R.string.showDataLableLight));
		DataModel model2 = new DataModel(colors[2], "", getResources().getString(R.string.showDataLableAwake));
		showView.initDatas(model0, model1, model2);

	}

	@Override
	protected void lazyLoad() {

		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}

			/* **************************************************************
			 * 获取dataBase,并查出 1.每天的总步数列表 2.当天的数据详情 *
			 * **************************************************************
			 */
			lineParent.setDatas(TempUtil.getTotalSleep(0));
			sleepData = TempUtil.getSleepByDate(Calendar.getInstance(), lineParent.getShowingOffset());
			setSLeepData2Page();

		if (notifyParent != null) {
			notifyParent.notifyParentReloadMyDate(lineParent.getShowingOffset(), isLinePointChartShow());
		}
	}

	/**
	 * 将当天运动数据填到页面中去
	 */
	private void setSLeepData2Page() {
		pieView.setDatas(sleepData);

		barChart.setData(sleepData);

		showView.updateData(0, sleepData.deepTotal + "", null);
		showView.updateData(1, sleepData.lightTotal + "", null);
		showView.updateData(2, sleepData.awakeTotal + "", null);
	}

	@Override
	public void onThemeChanged() {
		DebugLog.e("主页收到主题切换的通知");
	}

	@Override
	public void onClick(final View v) {
		switch (v.getId()) {
		case R.id.centerDataPie:
			Animation anim1 = AnimationUtils.loadAnimation(getActivity(), R.anim.sleep_pie_close);
			anim1.setAnimationListener(new AnimationListener() {

				@Override
				public void onAnimationStart(Animation animation) {
					pieView.setEnabled(false);
					barChart.setEnabled(false);
				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					pieView.setEnabled(true);
					barChart.setEnabled(true);
					pieView.setVisibility(View.GONE);
					barChart.startOpenAnim(null);
					barChart.setVisibility(View.VISIBLE);
				}
			});
			v.startAnimation(anim1);
			break;
		case R.id.sleepBarChart:
			barChart.startCloseAnim(new AnimatorListener() {

				@Override
				public void onAnimationStart(Animator animation) {
					pieView.setEnabled(false);
					barChart.setEnabled(false);
				}

				@Override
				public void onAnimationRepeat(Animator animation) {

				}

				@Override
				public void onAnimationEnd(Animator animation) {
					pieView.setEnabled(true);
					barChart.setEnabled(true);
					Animation anim1 = AnimationUtils.loadAnimation(getActivity(), R.anim.sleep_pie_open);
					pieView.startAnimation(anim1);
					v.setVisibility(View.GONE);
					pieView.setVisibility(View.VISIBLE);
				}

				@Override
				public void onAnimationCancel(Animator animation) {
					v.setVisibility(View.GONE);
					pieView.setVisibility(View.VISIBLE);
				}
			});

			break;
		case R.id.gotoTheDay:
			sleepData = TempUtil.getSleepByDate(Calendar.getInstance(), lineParent.getShowingOffset());
			setSLeepData2Page();
			// 让父fragment记录下该时间，在其他子frag可见时，再重新加载所选日期的数据
			notifyParent.onClickGoToTheDay(lineParent.getShowingOffset());
			// 此处是关闭lineParent，参数随便传一个，比如0
			lineParent.toggle(0);
			if (notifyParent != null) {
				notifyParent.notifyParentReloadMyDate(lineParent.getShowingOffset(), isLinePointChartShow());
			}
			break;

		default:
			break;
		}
	}

	@Override
	public void onDateClick(int dateOffset) {
		lineParent.toggle(dateOffset);
		/**
		 * 此处等数据库写好后打开
		 */

		// progressView.setDatas(dataBase.getDataByDate(c).data, goal);
	}

	@Override
	public void onScrolling(int index) {
		if (notifyParent != null) {
			notifyParent.onDateScrolling(index);
		}
	}

	@Override
	public View getRootView() {
		return mRootView;
	}

	public boolean isLinePointChartShow() {
		return lineParent.getVisibility() == View.VISIBLE;
	}

	@Override
	public void onHealthDataChanged() {
		DebugLog.e("新数据收到，睡眠界面。");

		lineParent.setDatas(TempUtil.getTotalSleep(0));
		lineParent.setShowingOffset(0);
		sleepData = TempUtil.getSleepByDate(Calendar.getInstance(), lineParent.getShowingOffset());
		setSLeepData2Page();
		// 让父fragment通知其他子fragment更新页面数据
		notifyParent.onClickGoToTheDay(lineParent.getShowingOffset());

	}

	// public Calendar getSelectedDate() {
	// return lineParent.getCurrentData().date;
	// }

	@Override
	public void onReloadData(int index) {
		if (lineParent.getShowingOffset() != index) {
			// Calendar - index
			sleepData = TempUtil.getSleepByDate(Calendar.getInstance(), index);
			setSLeepData2Page();
		}

	}

}
