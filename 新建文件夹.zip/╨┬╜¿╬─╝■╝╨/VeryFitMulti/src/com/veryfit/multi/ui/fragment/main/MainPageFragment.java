package com.veryfit.multi.ui.fragment.main;

import java.util.Calendar;
import java.util.Random;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.ui.adapter.MainDataAdapter;
import com.veryfit.multi.ui.fragment.MainPageChildFragment;
import com.veryfit.multi.ui.fragment.OnHealthDataChangedListener;
import com.veryfit.multi.ui.fragment.inter.NotifyParentFragment;
import com.veryfit.multi.util.Util;
import com.veryfit.multi.view.CirclePageIndicator;
import com.veryfit.multi.view.MainPageRelativeLayout;
import com.veryfit.multi.vpeffect.AccordionTransformer;
import com.veryfit.multi.vpeffect.CubeTransformer;
import com.veryfit.multi.vpeffect.DefaultTransformer;
import com.veryfit.multi.vpeffect.DepthPageTransformer;
import com.veryfit.multi.vpeffect.InRightDownTransformer;
import com.veryfit.multi.vpeffect.InRightUpTransformer;
import com.veryfit.multi.vpeffect.RotateTransformer;
import com.veryfit.multi.vpeffect.ZoomOutPageTransformer;

/** 主页 */
public class MainPageFragment extends BaseFragment implements OnClickListener, NotifyParentFragment {

	private View mRootView = null;
	private boolean isPrepared = false;

//	private static String todayStr;

	private Calendar c;

	private int dateOffset;
	
	private TextView backToday;

    
   
    
	private OnHealthDataChangedListener mOnHealthDataChangedListener = null;

	private CheckBox dateView;
	private ViewPager pager;
	private MainDataAdapter pagerAdapter;
	private MainPageChildFragment currentFragment;
	private MainPageRelativeLayout scrollView;

	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_main_mainpage, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	private void initView() {
		c = Calendar.getInstance();
		
		backToday = (TextView) mRootView.findViewById(R.id.backToToday);
		backToday.setOnClickListener(this);

		scrollView = (MainPageRelativeLayout) mRootView.findViewById(R.id.main);
		scrollView.init(this);

		dateView = (CheckBox) mRootView.findViewById(R.id.date);
		setDate(dateOffset);
		dateView.setOnClickListener(this);

		pager = (ViewPager) mRootView.findViewById(R.id.chart_container);
		pagerAdapter = new MainDataAdapter(getChildFragmentManager());
		pager.setAdapter(pagerAdapter);
		pager.setPageTransformer(true, new CubeTransformer());

		currentFragment = (MainPageChildFragment) pagerAdapter.getItem(0);
		currentFragment.setNotifyParentFragment(this);

		CirclePageIndicator indicator = (CirclePageIndicator) mRootView.findViewById(R.id.pagerIndicator);
		indicator.setViewPager(pager);
		indicator.setOnPageChangeListener(pageChangeListener);

	}
	
	 @Override
	    public void onVisible() {
	    	// TODO Auto-generated method stub
	    	super.onVisible();
//	    	setTransfromer(new Random().nextInt(5));
	    }
	    
	    
	    public void setTransfromer(int position){
	    	switch (position) {
			case 0:
				pager.setPageTransformer(true, new DefaultTransformer());
				break;
			case 1:
				pager.setPageTransformer(true, new DepthPageTransformer());
				break;
			case 2:
				pager.setPageTransformer(true, new CubeTransformer());
				break;
//			case 3:
//				//99
//				pager.setPageTransformer(true, new RotateTransformer());
//				break;
			case 3:
				pager.setPageTransformer(true, new AccordionTransformer());
				break;
//			case 5:
//				//99
//				pager.setPageTransformer(true, new InRightUpTransformer());
//				break;
//			case 6:
//				//99
//				pager.setPageTransformer(true, new InRightDownTransformer());
//				break;
			case 4:
				pager.setPageTransformer(true, new ZoomOutPageTransformer());
				break;
			default:
				break;
			}
	    }

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}

	}

	@Override
	public void onThemeChanged() {
		DebugLog.e("主页收到主题切换的通知");
	}

	private OnPageChangeListener pageChangeListener = new OnPageChangeListener() {

		@Override
		public void onPageSelected(int arg0) {
			DebugLog.d("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*****" + arg0);
			currentFragment = (MainPageChildFragment) pagerAdapter.getItem(arg0);
			currentFragment.setNotifyParentFragment(MainPageFragment.this);
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {

		}

		/**
		 * arg0 有3个状态0，1，2 0-->停止状态 1-->正在滑动 2-->滑动完毕 一次完整的滑动，状态变化为1-->2-->0
		 */
		@Override
		public void onPageScrollStateChanged(int arg0) {

		}
	};

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.date:
			setDate(dateOffset);
			currentFragment.onDateClick(dateOffset);
			// dateView.setChecked(!dateView.isChecked());
			break;
		case R.id.backToToday:
			onClickGoToTheDay(0);
			currentFragment.onReloadData(0);
			break;

		default:
			break;
		}
	}
	
	private void setDate(int dateOffset){
		if(dateOffset == 0){
			dateView.setText(R.string.today);
		}else{
			dateView.setText(Util.formatToMonthAndDate(c, -dateOffset));
		}
	}

	@Override
	public void onClickGoToTheDay(int dateOffset) {
		this.dateOffset = dateOffset;
		setDate(dateOffset);
		dateView.setChecked(false);
		backToday.setVisibility(dateOffset != 0 ? View.VISIBLE : View.GONE);
	}

	@Override
	public void onDateScrolling(int dateOffset) {
		setDate(dateOffset);
	}

	@Override
	public void onRootViewCreate(View rootView) {
		// scrollView.setChildFragmentView(rootView);
		// mRootView.setBackground(rootView.getBackground());
		// rootView.setBackground(null);

	}

	@Override
	public void notifyParentReloadMyDate(int dateOffset, boolean isShow) {
		if (isShow) {
			dateView.setChecked(true);
			setDate(dateOffset);
		} else {
			setDate(this.dateOffset);
			dateView.setChecked(false);
			currentFragment.onReloadData(this.dateOffset);
		}
	}

	@Override
	public void onHealthDataChanged() {
		DebugLog.e("数据同步完成，通知子fragment更新数据");
		if (currentFragment != null) {
			currentFragment.onHealthDataChanged();
		}
		if (mOnHealthDataChangedListener != null) {
			mOnHealthDataChangedListener.OnHealthDataChanged();
		}
	}

	public void setOnHealthDataChanged(OnHealthDataChangedListener listener) {
		mOnHealthDataChangedListener = listener;
	}

}
