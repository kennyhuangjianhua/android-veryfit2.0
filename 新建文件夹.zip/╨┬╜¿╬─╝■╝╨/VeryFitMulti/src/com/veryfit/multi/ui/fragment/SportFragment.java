package com.veryfit.multi.ui.fragment;

import java.util.Calendar;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;

import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;
import com.veryfit.multi.R;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.util.DefaultConstant;
import com.veryfit.multi.util.TempUtil;
import com.veryfit.multi.view.DataShowView;
import com.veryfit.multi.view.DataShowView.DataModel;
import com.veryfit.multi.view.PointLineView.onDateScrolling;
import com.veryfit.multi.view.SportBarChart;
import com.veryfit.multi.view.SportPieView;
import com.veryfit.multi.view.group.PointLineParent;
import com.veryfit.multi.vo.SportData;

public class SportFragment extends MainPageChildFragment implements OnClickListener, onDateScrolling {

	private View mRootView = null;
	private boolean isPrepared = false;
	private SportBarChart barChart;

	private SportPieView pieView;

	private PointLineParent lineParent;

	private int goal = Constant.GOAL_SPORT;;


	private SportData sportData;

	private DataShowView showView;

	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_sport, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}
		if (notifyParent != null) {
			notifyParent.onRootViewCreate(mRootView);
		}
		return mRootView;
	}

	private void initView() {
		pieView = (SportPieView) mRootView.findViewById(R.id.centerDataPie);
		pieView.setOnClickListener(this);

		barChart = (SportBarChart) mRootView.findViewById(R.id.sportBarChart);
		barChart.setOnClickListener(this);

		lineParent = (PointLineParent) mRootView.findViewById(R.id.pointLineParent);
		lineParent.getGoToTheDayView().setOnClickListener(this);
		lineParent.setOnDateScrollingLinstener(this);
		lineParent.setType(PointLineParent.TYPE_SPORT);

		showView = (DataShowView) mRootView.findViewById(R.id.dataShowView);
		DataModel model1 = new DataModel("", getResources().getString(R.string.unit_kilometer));
		DataModel model2 = new DataModel("", getResources().getString(R.string.unit_calorie));
		showView.initDatas(model1, model2);
	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}
//		goal = TempUtil.getGoal(Calendar.getInstance().getTimeInMillis())[0];
		/* ******************************************
		 * 此处查出用户设置的运动目标填入进去 *******************************************
		 */
		// goal = AppSharedPreferences.getInstance().getGoalSport();

			/* **************************************************************
			 * 获取dataBase,并查出 1.每天的总步数列表 2.当天的数据详情 *
			 * **************************************************************
			 */
			lineParent.setDatas(TempUtil.getDayTotalSteps(0));
			sportData = TempUtil.getSprotByDate(Calendar.getInstance(), lineParent.getShowingOffset());
			goal = TempUtil.getGoal(LongDateUtil.Calendar2LongDate(sportData.date))[0];
//			DebugLog.d("goal = " + goal + "****date = " + sportData.date);
			setSportData2Page();

		if (notifyParent != null) {
			notifyParent.notifyParentReloadMyDate(lineParent.getShowingOffset(), isLinePointChartShow());
		}

	}

	/**
	 * 将当天运动数据填到页面中去
	 */
	private void setSportData2Page() {
		pieView.setGoal(goal);
		pieView.setSteps(sportData.steps, true);

		barChart.setDatas(sportData.details);
		barChart.setTittleString(sportData.steps + " / " + goal);

		/* ******************************************
		 * 此处做单位转换 *******************************************
		 */
		showView.updateData(0, String.format("%.2f", sportData.distance), null);
		showView.updateData(1, sportData.calorie + "", null);
	}

	@Override
	public void onThemeChanged() {
		DebugLog.e("主页收到主题切换的通知");
	}

	@Override
	public void onClick(final View v) {
		switch (v.getId()) {
		case R.id.centerDataPie:
			Animation anim1 = AnimationUtils.loadAnimation(getActivity(), R.anim.center_data_pie);
			anim1.setAnimationListener(new AnimationListener() {

				@Override
				public void onAnimationStart(Animation animation) {
					pieView.setEnabled(false);
				}

				@Override
				public void onAnimationRepeat(Animation animation) {

				}

				@Override
				public void onAnimationEnd(Animation animation) {
					barChart.startAnimSet();
					pieView.setEnabled(true);
					pieView.setVisibility(View.GONE);
				}
			});
			v.startAnimation(anim1);
			break;
		case R.id.sportBarChart:
			v.setVisibility(View.GONE);
			pieView.setVisibility(View.VISIBLE);
			pieView.startAnim(-1);
			break;
		case R.id.gotoTheDay:
			// 更新页面数据
			sportData = TempUtil.getSprotByDate(Calendar.getInstance(), lineParent.getShowingOffset());
			goal = TempUtil.getGoal(LongDateUtil.Calendar2LongDate(sportData.date))[0];
			setSportData2Page();
			// 让父fragment记录下该时间，在其他子frag可见时，再重新加载所选日期的数据
			notifyParent.onClickGoToTheDay(lineParent.getShowingOffset());
			// 此处是关闭lineParent，参数随便传一个，比如0
			lineParent.toggle(0);
			if (notifyParent != null) {
				notifyParent.notifyParentReloadMyDate(lineParent.getShowingOffset(), isLinePointChartShow());
			}
			break;

		default:
			break;
		}
	}

	@Override
	public void onDateClick(int dateOffset) {
		lineParent.toggle(dateOffset);
	}

	@Override
	public void onScrolling(int index) {
		if (notifyParent != null) {
			notifyParent.onDateScrolling(index);
		}
	}

	@Override
	public View getRootView() {
		return mRootView;
	}

	public boolean isLinePointChartShow() {
		return lineParent.getVisibility() == View.VISIBLE;
	}

	@Override
	public void onHealthDataChanged() {
		DebugLog.e("新数据收到，运动界面。");

		// 更新页面数据
		lineParent.setDatas(TempUtil.getDayTotalSteps(0));
		lineParent.setShowingOffset(0);
		sportData = TempUtil.getSprotByDate(Calendar.getInstance(), lineParent.getShowingOffset());
		goal = TempUtil.getGoal(LongDateUtil.Calendar2LongDate(sportData.date))[0];
		setSportData2Page();
		// 让父fragment通知其他子fragment更新页面数据
		notifyParent.onClickGoToTheDay(lineParent.getShowingOffset());
	}

	@Override
	public void onReloadData(int index) {
		if (lineParent.getShowingOffset() != index) {
			// Calendar - index
			sportData = TempUtil.getSprotByDate(Calendar.getInstance(), index);
			goal = TempUtil.getGoal(LongDateUtil.Calendar2LongDate(sportData.date))[0];
			setSportData2Page();
		}

	}

	// public Calendar getSelectedDate() {
	// return lineParent.getCurrentData().date;
	// }

}
