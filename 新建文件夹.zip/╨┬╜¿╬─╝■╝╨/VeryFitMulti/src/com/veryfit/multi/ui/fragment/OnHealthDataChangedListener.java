package com.veryfit.multi.ui.fragment;

public interface OnHealthDataChangedListener {
	/** 健康数据变化 */
	void OnHealthDataChanged();
}
