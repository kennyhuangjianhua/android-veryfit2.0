package com.veryfit.multi.ui.activity.mine;

import java.util.Arrays;
import java.util.Calendar;

import android.os.Bundle;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.project.library.database.Goal;
import com.project.library.device.cmd.settings.MultiTarget;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.LongDateUtil;
import com.veryfit.multi.R;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.activity.BaseNotifyBleActivity;
import com.veryfit.multi.util.TempUtil;
import com.veryfit.multi.view.RulerView;


public class TargetSettingActivity extends BaseNotifyBleActivity implements OnClickListener{
	private TextView tv_sure;
	private ImageView iv_back;
	private RulerView ruler_sport,ruler_sleep;
	
	private int[] goal;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_target_settings);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void initFirst() {
		super.initFirst();
	}

	@Override
	protected void initView() {
		super.initView();
		iv_back=(ImageView) findViewById(R.id.bar_left);
		tv_sure = (TextView) findViewById(R.id.tittle_right);
		ruler_sleep = (RulerView) findViewById(R.id.person_inof_sleep);
		ruler_sport = (RulerView) findViewById(R.id.person_inof_sport);
	}

	@Override
	protected void initEvent() {
		super.initEvent();
		tv_sure.setOnClickListener(this);
		iv_back.setOnClickListener(this);
	}

	@Override
	protected void initData() {
		super.initData();
		goal = TempUtil.getGoal(LongDateUtil.Calendar2LongDate(Calendar.getInstance()));
		ruler_sport.setData(goal[0]);
		ruler_sleep.setData(goal[1]);
	}


	@Override
	protected void onThemeChanged() {

	}

	@Override
	protected void onDataSendFailed() {
		Toast.makeText(this, R.string.settingDataFail, Toast.LENGTH_SHORT).show();
		showSureBtn();
	}


	@Override
	protected void saveDate() {
		int[] tempGoal = new int[] { ruler_sport.getCenterData(), ruler_sleep.getCenterData() };
		if (Arrays.equals(tempGoal, goal)) {
			finish();
		} else {
			TempUtil.saveGoal(new Goal(tempGoal[0], Goal.TYPE_SPORT), new Goal(tempGoal[1], Goal.TYPE_SLEEP));
			AppSharedPreferences.getInstance().setFlagGoalChange(true);
			sendData(tempGoal);
		}
	}

	private void sendData(int[] tempGoal) {
		MultiTarget target = new MultiTarget();
		target.sportType = MultiTarget.TYPE_STEP;
		target.sportTarget = tempGoal[0];

		target.sleepFlag = MultiTarget.FLAG_SLEEP_NORMAL;
		target.sleepHour = tempGoal[1] / 60;
		target.sleepMinute = tempGoal[1] % 60;

		mCore.addListener(mAppListener);
		
		if(writeData(SettingsCmd.getInstance().getMultiTargetSettingsCmd(target))){
			showProgress();
		}else{
			onDataSendFailed();
		}
	}
	

	@Override
	protected void onSettingsSuccess() {
		showSureBtn();
		AppSharedPreferences.getInstance().setFlagGoalChange(false);
		finish();
	}

	
	
}
