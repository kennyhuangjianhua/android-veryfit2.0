package com.veryfit.multi.ui.fragment;

import java.util.Calendar;

import android.view.View;

import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.ui.fragment.inter.NotifyChildFragment;
import com.veryfit.multi.ui.fragment.inter.NotifyParentFragment;

public abstract class MainPageChildFragment extends BaseFragment implements NotifyChildFragment {

	protected NotifyParentFragment notifyParent;

	public void setNotifyParentFragment(NotifyParentFragment notifyParentFragment) {
		notifyParent = notifyParentFragment;
	}

	// public abstract boolean isLinePointChartShow();

	public abstract View getRootView();

	// public abstract Calendar getSelectedDate();

	/** 健康数据变化 */
	public abstract void onHealthDataChanged();
}
