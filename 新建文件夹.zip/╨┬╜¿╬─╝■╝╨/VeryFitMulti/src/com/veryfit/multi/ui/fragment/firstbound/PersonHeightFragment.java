package com.veryfit.multi.ui.fragment.firstbound;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.util.UnitFormat;
import com.veryfit.multi.view.BaseRulerView;
import com.veryfit.multi.view.DialogUtil;
import com.veryfit.multi.view.DialogUtil.OnHeightFormatSelectListener;
import com.veryfit.multi.view.RulerView;
import com.veryfit.multi.view.RulerView.OnDataSelectedListener;

public class PersonHeightFragment extends PersonBaseFragment {
	public PersonHeightFragment(OnPagerChangedListener listener) {
		super(listener);
	}

	private View mRootView = null;
	private boolean isPrepared = false;

	private Button next;
	// private RulerView ruler_height;
	private boolean haveShowed = false;

	public BaseRulerView ruler_height;

	private int height = -1;

	private int unitType;

	private static final int MIN_INCH = 1;
	private static final int MIN_CM = 50;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_person_height, container, false);
			initView();
			initEvent();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser) {
			// 相当于Fragment的onResume
			// if (!haveShowed) {
			// haveShowed = true;
			// DialogUtil.showHeightFormatDialog(getActivity(), new
			// OnHeightFormatSelectListener() {
			//
			// @Override
			// public void onHeightFormat(int format) {
			// unitType = format;
			// AppSharedPreferences.getInstance().setUnitType(format);
			// }
			// });
			// }else{
			// unitType = AppSharedPreferences.getInstance().getUnitType();
			// }
			// switchUnitType();
		} else {
			// 相当于Fragment的onPause
		}
	}

	private void switchUnitType() {
		if (height == -1) {
			height = AppSharedPreferences.getInstance().getUserHeight();
		}
		DebugLog.d("height = " + height + "***sex = " + AppSharedPreferences.getInstance().getUserSex());
		if (unitType == Constant.METRIC) {
			ruler_height.initData(new String[] { "cm" }, 250, MIN_CM, 5, 10, 1);
			ruler_height.setData(height - MIN_CM);
		} else if (unitType == Constant.BRITISH) {
			ruler_height.initData(new String[] { "ft", "in" }, 9, MIN_INCH, 6, 1, 1);
			DebugLog.d("height inch= " + UnitFormat.cm2inchs(height));
			ruler_height.setData(UnitFormat.cm2inchs(height) - MIN_INCH * 12);
		}
	}

	public void initView() {
		next = (Button) mRootView.findViewById(R.id.pserson_height_next);
		ruler_height = (BaseRulerView) mRootView.findViewById(R.id.person_inof_height);

	}

	public void initEvent() {
		next.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				int[] data = ruler_height.getData();
				if (unitType == Constant.METRIC) {
					int cm = data[0] + data[1];
					height = cm;
					AppSharedPreferences.getInstance().setUserHeight(cm);
//					Toast.makeText(getActivity(), "身高:" + cm + "厘米", Toast.LENGTH_LONG).show();
				} else if (unitType == Constant.BRITISH) {
					int cm = UnitFormat.inch2cm(data);
					DebugLog.d("***" + cm);
					height = cm;
					AppSharedPreferences.getInstance().setUserHeight(cm);
				}
				setPagerIndex(2);
			}
		});
	}

	@Override
	public void onThemeChanged() {

	}

	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}
		//暂时不用设置单位
//		if (!haveShowed) {
//			haveShowed = true;
//			DialogUtil.showHeightFormatDialog(getActivity(), new OnHeightFormatSelectListener() {
//
//				@Override
//				public void onHeightFormat(int format) {
//					unitType = format;
//					AppSharedPreferences.getInstance().setUnitType(format);
//					switchUnitType();
//				}
//			});
//		}
		unitType = AppSharedPreferences.getInstance().getUnitType();
		switchUnitType();
	}

}
