package com.veryfit.multi.ui.fragment.main;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.ui.activity.mine.PersonalInformationActivity;
import com.veryfit.multi.ui.activity.mine.SysSettingsActivity;
import com.veryfit.multi.ui.activity.mine.TargetSettingActivity;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.view.CircleImageView;
import com.veryfit.multi.view.DialogUtil;
import com.veryfit.multi.vo.UserInfo;

/** 我的 */
public class UserFragment extends BaseFragment implements View.OnClickListener {

	private View mRootView = null;
	private boolean isPrepared = false;

    private Button change_theme_btn = null;
    private ImageView mine_target,mine_info,mine_settings;
    private TextView tv_userName;
    private CircleImageView iv_header;
    
    private String photoFile;
    
    private UserInfo userinfo=new UserInfo();

	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		if (null != mRootView) {
			ViewGroup parent = (ViewGroup) mRootView.getParent();
			if (null != parent) {
				parent.removeView(mRootView);
			}
		} else {
			mRootView = inflater.inflate(R.layout.fragment_mine, container, false);
			initView();
			isPrepared = true;
			lazyLoad();
		}

		return mRootView;
	}

    private void initView() {
    	
    	mine_info=(ImageView) mRootView.findViewById(R.id.mine_info);
    	mine_target=(ImageView) mRootView.findViewById(R.id.mine_target);
    	mine_settings=(ImageView) mRootView.findViewById(R.id.mine_settings);
    	iv_header=(CircleImageView) mRootView.findViewById(R.id.mine_header);
		iv_header.setImageBitmap(BitmapFactory.decodeFile(Constant.PIC_PATH +  DialogUtil.photoPath));
		tv_userName=(TextView) mRootView.findViewById(R.id.mine_name);
		
    	mine_info.setOnClickListener(this);
    	mine_target.setOnClickListener(this);
    	mine_settings.setOnClickListener(this);
    	iv_header.setOnClickListener(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == 123) {
                System.out.println("1111111111111");
            }
            Bitmap photo = DialogUtil.chooseFace(requestCode, resultCode, data, getActivity(),this);
    		if (photo != null) {
    			photoFile = Constant.PIC_PATH + DialogUtil.photoPath;
    			iv_header.setImageBitmap(photo);
    		}
        }
    }



	@Override
	protected void lazyLoad() {
		if (!isPrepared || !getUserVisibleHint()) {
			return;
		}
		userinfo.init();
		tv_userName.setText(userinfo.name);

		// 填充数据
		// change_theme_btn.setText("点击我切换主题123");
	}

	@Override
	public void onThemeChanged() {
		DebugLog.e("我的收到主题切换的通知");
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.mine_info:
			startActivity(new Intent(getActivity(), PersonalInformationActivity.class));
			break;
		case R.id.mine_target:
			startActivity(new Intent(getActivity(), TargetSettingActivity.class));
			break;
		case R.id.mine_settings:
			startActivity(new Intent(getActivity(), SysSettingsActivity.class));
			break;
		case R.id.mine_header:
			DialogUtil.showPhotosDaiglog(this.getActivity(),this);
			break;
		default:
			break;
		}
	}
	

	

}
