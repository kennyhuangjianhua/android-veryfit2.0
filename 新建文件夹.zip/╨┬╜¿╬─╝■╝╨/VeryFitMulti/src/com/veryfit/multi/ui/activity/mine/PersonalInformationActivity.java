package com.veryfit.multi.ui.activity.mine;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.ui.activity.BaseNotifyBleActivity;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.view.CircleImageView;
import com.veryfit.multi.view.DialogUtil;
import com.veryfit.multi.view.DialogUtil.OnBirthdaySelectListener;
import com.veryfit.multi.view.DialogUtil.OnWheelSelectorListener;
import com.veryfit.multi.vo.UserInfo;

public class PersonalInformationActivity extends BaseNotifyBleActivity implements OnClickListener{
	private TextView tv_username,tv_birthday,tv_sex,tv_height,tv_weight,tv_sure;//tv_username
	private  EditText ed_username;
	private ImageView iv_birthday,iv_sex,iv_height,iv_weight,back;
	private CircleImageView iv_header;
	
	private UserInfo info = new UserInfo();
	private String[] sex;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_personal_information);
		super.onCreate(savedInstanceState);
	}

	@Override
	protected void initFirst() {
		super.initFirst();
	}

	@Override
	protected void initView() {
		super.initView();
		iv_header=(CircleImageView) findViewById(R.id.mine_header);
		iv_sex=(ImageView) findViewById(R.id.personal_sex_to);
		iv_height=(ImageView) findViewById(R.id.personal_height_to);
		iv_weight=(ImageView) findViewById(R.id.personal_weight_to);
		iv_birthday=(ImageView) findViewById(R.id.personal_birthday_to);
		back=(ImageView) findViewById(R.id.bar_left);
//		tv_sure=(TextView) findViewById(R.id.bar_right);
		tv_username = (TextView) findViewById(R.id.mine_name);
		tv_sex=(TextView) findViewById(R.id.personal_sex);
		tv_height=(TextView) findViewById(R.id.personal_height);
		tv_weight=(TextView) findViewById(R.id.personal_weight);
		tv_birthday=(TextView) findViewById(R.id.personal_birthday);
		ed_username=(EditText) findViewById(R.id.personal_username);
		ed_username.setSelection(ed_username.getText().toString().length());
		
		iv_header.setImageBitmap(BitmapFactory.decodeFile(Constant.PIC_PATH +  DialogUtil.photoPath));
		
		sex = getResources().getStringArray(R.array.unit_sex);
	}

	@Override
	protected void initEvent() {
		super.initEvent();
		iv_sex.setOnClickListener(this);
		iv_height.setOnClickListener(this);
		iv_weight.setOnClickListener(this);
		iv_birthday.setOnClickListener(this);
//		tv_sure.setOnClickListener(this);
		back.setOnClickListener(this);
		ed_username.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				tv_username.setText(ed_username.getText().toString());
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
		});
	}

	@Override
	protected void initData() {
		super.initData();
		info.init();
		ed_username.setText(info.name);
		tv_birthday.setText(getString(R.string.person_birth, info.year , info.month , info.day));
		tv_sex.setText(sex[info.gender]);
		//此处现在不考虑公英制
		tv_height.setText(info.height + getString(R.string.unit_cm));
		tv_weight.setText(info.weight + getString(R.string.unit_kg));
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		switch (v.getId()) {
		case R.id.personal_sex_to:
			DialogUtil.showWheelSexDialog(this,info.gender, new OnWheelSelectorListener() {

				@Override
				public void onWheelSelect(Object obj) {
					// Toast.makeText(PersonalInformationActivity.this,
					// "性别:"+(String)obj, Toast.LENGTH_LONG).show();
//					tv_sex.setText((String) obj);
					info.gender = (Integer) obj;
					tv_sex.setText(sex[info.gender]);
				}
			});
			break;
		case R.id.personal_height_to:
			DialogUtil.showWheelHeightDialog(this,info.height ,  new OnWheelSelectorListener() {

				@Override
				public void onWheelSelect(Object obj) {
					// Toast.makeText(PersonalInformationActivity.this,
					// "身高:"+(Integer)obj+" cm", Toast.LENGTH_LONG).show();
					info.height = (Integer) obj;
					tv_height.setText( info.height + getString(R.string.unit_cm));
				}
			});
			break;
		case R.id.personal_weight_to:
			DialogUtil.showWheelWeightDialog(this, info.weight, new OnWheelSelectorListener() {

				@Override
				public void onWheelSelect(Object obj) {
					// Toast.makeText(PersonalInformationActivity.this,
					// "体重:"+(Integer)obj+"kg", Toast.LENGTH_LONG).show();
//					tv_weight.setText((Integer) obj + "kg");
					info.weight = (Integer) obj;
					tv_weight.setText(info.weight + getString(R.string.unit_kg));
				}
			});
			break;
		case R.id.personal_birthday_to:
			DialogUtil.showWheelBirthDayDialog(this,new int[]{info.year , info.month , info.day} ,  new OnBirthdaySelectListener() {

				@Override
				public void onBirthdaySelect(int year, int month, int day) {
					// Toast.makeText(PersonalInformationActivity.this,
					// "生日:"+year+"-"+month+"-"+day, Toast.LENGTH_LONG).show();
//					tv_birthday.setText(year + "年" + month + "月" + day + "日");
					info.day = day;
					info.year = year;
					info.month = month;
					tv_birthday.setText(getString(R.string.person_birth, year , month , day));
				}
			});
			break;
		case R.id.bar_left:
			finish();
			break;
//		case R.id.bar_right:
//			saveDate();
//			break;
		default:
			break;
		}
	}

	@Override
	protected void onThemeChanged() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onSettingsSuccess() {
		DebugLog.e("个人信息设置成功。");
		showSureBtn();
		finish();
		
	}

	@Override
	protected void onDataSendFailed() {
		Toast.makeText(this, R.string.settingDataFail, Toast.LENGTH_SHORT).show();
		showSureBtn();
	}

	@Override
	protected void saveDate() {
		info.name = ed_username.getText().toString();
		info.save();
		mCore.addListener(mAppListener);
		if(writeData(SettingsCmd.getInstance().getUserinfosSettingsCmd(info))){
			showProgress();
		}else{
			onDataSendFailed();
		}
		
	}
}
