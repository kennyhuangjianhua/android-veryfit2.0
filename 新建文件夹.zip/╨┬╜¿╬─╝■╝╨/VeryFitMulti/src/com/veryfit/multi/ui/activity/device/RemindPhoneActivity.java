package com.veryfit.multi.ui.activity.device;

import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.KeyEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.database.AlarmNotify;
import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.WareUpdateCmd;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.view.group.ItemToggleLayout;

public class RemindPhoneActivity extends BaseActivity {
	private static final int MIN_DELAY = 3, MAX_DELAY = 30;

	private TextView delayValue;

	private SeekBar delayBar;

	private int delay;

	private ItemToggleLayout toggle;

	private boolean isOpen;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_phone);
		loadData();
		initView();
		super.onCreate(savedInstanceState);
	}

	private void loadData() {
		AppSharedPreferences share = AppSharedPreferences.getInstance();
		delay = share.getDeviceRemindPhoneDelay();
		isOpen = share.getDeviceRemindPhoneSwitch();
	}

	protected void initView() {
		delayValue = (TextView) findViewById(R.id.phone_delay);
		setDelayValue(delay);

		delayBar = (SeekBar) findViewById(R.id.phone_remind_delay);
		delayBar.setMax(MAX_DELAY - MIN_DELAY);
		delayBar.setProgress(delay - MIN_DELAY);
		delayBar.setOnSeekBarChangeListener(seekChange);

		toggle = (ItemToggleLayout) findViewById(R.id.toggleLayout);
		toggle.setOpen(isOpen);
	}

	private OnSeekBarChangeListener seekChange = new OnSeekBarChangeListener() {
		public void onStopTrackingTouch(SeekBar seekBar) {
		}

		public void onStartTrackingTouch(SeekBar seekBar) {
		}

		@Override
		public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
			setDelayValue(progress + MIN_DELAY);
		}
	};

	private void setDelayValue(int delay) {
		String format = getResources().getString(R.string.phone_alert, delay);
		SpannableString span = new SpannableString(format);
		int start = format.indexOf(delay + "");
		int end = start + (delay + "").length();
		span.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.theme_tittle_bg)), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		span.setSpan(new RelativeSizeSpan(2f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		delayValue.setText(span);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bar_left:
			finish();
			break;
		case R.id.tittle_right:
			if (dataHasChange()) {
				AppSharedPreferences.getInstance().setDeviceRemindPhoneSwitch(toggle.isOpen());
				AppSharedPreferences.getInstance().setDeviceRemindPhoneDelay(delay);
			}
			finish();
			break;
		default:
			break;
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {

		}
		return super.onKeyDown(keyCode, event);
	}

	private boolean dataHasChange() {
		// if(toggle.isOpen() != isOpen){
		// toggle.showProgressBar();
		// }
		boolean change = toggle.isOpen() != isOpen || delay != (delayBar.getProgress() + MIN_DELAY);
		delay = (delayBar.getProgress() + MIN_DELAY);
		return change;
	}

	@Override
	protected void onThemeChanged() {

	}

}
