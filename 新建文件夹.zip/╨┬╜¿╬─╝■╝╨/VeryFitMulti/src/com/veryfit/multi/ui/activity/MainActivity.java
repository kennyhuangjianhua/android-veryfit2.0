package com.veryfit.multi.ui.activity;

import java.util.concurrent.CopyOnWriteArrayList;
import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.base.BaseFragment;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.OnThemeChangedListener;
import com.veryfit.multi.ui.fragment.OnHealthDataChangedListener;
import com.veryfit.multi.ui.fragment.main.DetailsFragment;
import com.veryfit.multi.ui.fragment.main.DeviceFragment;
import com.veryfit.multi.ui.fragment.main.MainPageFragment;
import com.veryfit.multi.ui.fragment.main.UserFragment;
import com.veryfit.multi.view.CustomRadioGroup;
import com.veryfit.multi.view.CustomRadioGroup.OnCheckedChangeListener;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewStub;
import android.widget.RelativeLayout;

/** 主界面 */
public class MainActivity extends BaseActivity implements OnCheckedChangeListener, OnHealthDataChangedListener {

	/** 主界面延迟加载 */
	private ViewStub mViewStub = null;
	/** 主界面 */
	private RelativeLayout mContainer;
	/** 主界面下方切换group */
	private CustomRadioGroup mTabGroup = null;
	private BaseFragment mLastFragment;
	private MainPageFragment mMainPageFragment = null;
	private DetailsFragment mDetailsFragment = null;
	private DeviceFragment mDeviceFragment = null;
	private UserFragment mUserFragment = null;
	/** 主题切换通知fragment */
	private CopyOnWriteArrayList<OnThemeChangedListener> mThemeChangedListeners = new CopyOnWriteArrayList<OnThemeChangedListener>();

	private CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	private AppSharedPreferences mAppSharedPreferences = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initLoadingView(savedInstanceState);
	}

	/** 加载启动页 */
	private void initLoadingView(final Bundle savedInstanceState) {
		mViewStub = (ViewStub) findViewById(R.id.viewstub_loadingview);
		// ImageView loadingView = (ImageView) mViewStub.inflate();
		mViewStub.inflate();

		// 模拟简单启动页
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {
				mViewStub.setVisibility(View.GONE);
				mViewStub = null;
				initMainView(savedInstanceState);
			}
		}, 3000L);
	}

	/** 正式初始化，正式加载主界面 */
	private void initMainView(Bundle savedInstanceState) {
		mViewStub = (ViewStub) findViewById(R.id.viewstub_main);
		mContainer = (RelativeLayout) mViewStub.inflate();

		mTabGroup = (CustomRadioGroup) mContainer.findViewById(R.id.main_tab_group);
		mTabGroup.setOnCheckedChangeListener(this);
		mTabGroup.check(R.id.main_tab_mainpage);
		if (savedInstanceState != null) {
			mLastFragment = (BaseFragment) getSupportFragmentManager().getFragment(savedInstanceState, "mLastFragment");
		}

		mAppSharedPreferences = AppSharedPreferences.getInstance();
		DebugLog.e("first start app : " + mAppSharedPreferences.isFirstStartApp());

		mCore.addListener(mAppListener);
		if (mCore.isAvailable()) {
			if (!mCore.isDeviceConnected()) {
				// 这里判断蓝牙是否打开，
				// 打开之后扫描设备
				// 扫描结束连接
				if (mCore.initBLE((byte) 0)) {
					String addr = AppSharedPreferences.getInstance().getBindDeviceAddr();
					if (!TextUtils.isEmpty(addr)) {
						mCore.connect(addr);
					}
				}
			}
		}
	}

	@Override
	public void onCheckedChanged(CustomRadioGroup group, int checkedId) {
		switch (checkedId) {
		case R.id.main_tab_mainpage:
			if (mMainPageFragment == null) {
				mMainPageFragment = new MainPageFragment();
				mMainPageFragment.setOnHealthDataChanged(this);
			}
			changeFragment(this, mMainPageFragment, null);
			break;
		case R.id.main_tab_details:
			if (mDetailsFragment == null) {
				mDetailsFragment = new DetailsFragment();
			}
			changeFragment(this, mDetailsFragment, null);
			break;
		case R.id.main_tab_device:
			if (mDeviceFragment == null) {
				mDeviceFragment = new DeviceFragment();
			}
			changeFragment(this, mDeviceFragment, null);
			break;
		case R.id.main_tab_user:
			if (mUserFragment == null) {
				mUserFragment = new UserFragment();
			}
			changeFragment(this, mUserFragment, null);
			break;
		default:
			break;
		}
	}

	/** 各个选项卡之间的切换 */
	private void changeFragment(FragmentActivity activity, BaseFragment newFragment, String tag) {
		if (newFragment == null || mLastFragment == newFragment) {
			return;
		}
		FragmentTransaction transaction = activity.getSupportFragmentManager().beginTransaction();
		if ((mLastFragment != null) && (mLastFragment != newFragment)) {
			transaction.detach(mLastFragment);
		}

		if (!newFragment.isAdded()) {
			transaction.add(R.id.fragment_content, newFragment, tag);
		}

		if (newFragment.isDetached()) {
			transaction.attach(newFragment);
		}

		mLastFragment = newFragment;
		addThemeChangedListener((OnThemeChangedListener) newFragment);
		transaction.commitAllowingStateLoss();
	}

	/** 添加主题切换的通知监听 */
	private void addThemeChangedListener(OnThemeChangedListener listener) {
		if (listener != null && (!mThemeChangedListeners.contains(listener))) {
			mThemeChangedListeners.add(listener);
		}
	}

	@Override
	protected void onSaveInstanceState(Bundle paramBundle) {
		getSupportFragmentManager().putFragment(paramBundle, "mLastFragment", mLastFragment);
		super.onSaveInstanceState(paramBundle);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		super.onRestoreInstanceState(savedInstanceState);
		if (savedInstanceState != null) {
			mLastFragment = (BaseFragment) getSupportFragmentManager().getFragment(savedInstanceState, "mLastFragment");
		}
	}

	@Override
	protected void onThemeChanged() {
		DebugLog.e("主题切换广播收到了...Main");
		// 自身主题切换
		// codes...
		// fragment主题切换
		for (OnThemeChangedListener listener : mThemeChangedListeners) {
			listener.onThemeChanged();
		}
	}

	@Override
	public void OnHealthDataChanged() {
		if (mDetailsFragment != null) {
			mDetailsFragment.updateHealthData();
		}
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		//

		android.os.Process.killProcess(android.os.Process.myPid());
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			CoreServiceProxy.fini();

			finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private APPCoreServiceListener mAppListener = new APPCoreServiceListener() {

		@Override
		public void onBlueToothError(int error) {
		}

		@Override
		public void onBLEConnecting() {

		}

		@Override
		public void onBLEConnected() {
			// startActivity(new Intent(MainActivity.this,
			// OtherActivity.class));
			mCore.write(SettingsCmd.getInstance().getTimeSettingsCmd());
		}

		@Override
		public void onBLEDisConnected(String address) {

		}

		@Override
		public void onSettingsSuccess(byte cmdKey, boolean success) {
			if (success) {
				DebugLog.e("设置成功： " + cmdKey);
				if (cmdKey == SettingsCmd.KEY_TIME_SETTINGS) {
					DebugLog.e("时间设置成功。。。");
				}
			} else {
				// 设置失败，可能是硬件问题，或者是设备断开了
				DebugLog.e("设置失败： " + cmdKey);
			}
		}

		@Override
		public void onCoreServiceConnected() {
		}

		@Override
		public void onCoreServiceDisconnected() {
		}
	};

}
