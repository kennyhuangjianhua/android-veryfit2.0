package com.veryfit.multi.ui.activity.device;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AbsListView.LayoutParams;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

import com.project.library.core.CoreServiceProxy;
import com.project.library.database.AlarmNotify;
import com.project.library.database.AlarmNotifyDao;
import com.project.library.database.DaoSession;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.ui.activity.BaseNotifyBleActivity;
import com.veryfit.multi.ui.adapter.AlarmAdapter;
import com.veryfit.multi.util.TempUtil;
import com.veryfit.multi.vo.Alarm;

import de.greenrobot.dao.query.QueryBuilder;

public class AlarmListActivity extends BaseNotifyBleActivity {

	private AlarmAdapter adapter;

	private List<AlarmNotify> alarms;

	private int currentModifyIndex;

	private AlarmNotifyDao alarmNotifyDao;

	protected CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	private ConcurrentLinkedQueue<AlarmNotify> mAlarmList = new ConcurrentLinkedQueue<AlarmNotify>();

	@Override
	protected void onThemeChanged() {

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_alarm_list);
		super.onCreate(savedInstanceState);
		ListView alarmList = (ListView) findViewById(R.id.alarm_list);
		View v = LayoutInflater.from(this).inflate(R.layout.alarm_list_footer, null);
		v.setLayoutParams(new AbsListView.LayoutParams(LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.item_device_detail)));
		alarmList.addFooterView(v);

		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		alarmNotifyDao = daoSession.getAlarmNotifyDao();
		QueryBuilder<AlarmNotify> alarmDaoQb = alarmNotifyDao.queryBuilder();
		alarmDaoQb.orderAsc(com.project.library.database.AlarmNotifyDao.Properties.AlarmId);
		alarms = alarmDaoQb.list();

		adapter = new AlarmAdapter(alarms, this);
		alarmList.setAdapter(adapter);
		alarmList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				currentModifyIndex = position;
				AlarmNotify alarm = (AlarmNotify) parent.getItemAtPosition(position);
				DebugLog.d("alarm = " + alarm.toString());
				Intent intent = new Intent(AlarmListActivity.this, AlarmSetActivity.class);
				intent.putExtra("alarm", alarm);
				startActivityForResult(intent, 1);
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == 1 && resultCode == 1 && data != null) {
			AlarmNotify alarm = data.getParcelableExtra("alarm");
			AlarmNotify.copy(alarm, alarms.get(currentModifyIndex));
			adapter.notifyDataSetChanged();
			DebugLog.d("requestCode = " + requestCode + "****resultCode = " + resultCode + "alarm = " + alarms.get(currentModifyIndex).toString());
		}
	}

	public void onClick(View v) {
		super.onClick(v);
		switch (v.getId()) {
		case R.id.alarm_add:
			// 如果已经达到闹钟数最大值，不能再添加
			AlarmNotify newAlarm = adapter.addAlarm();
			if (newAlarm != null) {
				newAlarm.hasModify = true;
				alarmNotifyDao.insert(newAlarm);
			} else {
				Toast.makeText(this, R.string.alarm_limit, Toast.LENGTH_SHORT).show();
			}
			break;

		default:
			break;
		}
	}

	@Override
	protected void onSettingsSuccess() {
		AlarmNotify alarmPre = mAlarmList.poll();
		if (alarmPre != null) {
			alarmPre.hasModify = false;
			adapter.notifyDataSetChanged();
		}
		AlarmNotify alarm = mAlarmList.peek();
		if (alarm == null) {
			DebugLog.e("全部闹钟设置成功。");
			sendingData = false;
			finish();
		} else {
			sendOneAlarm(alarm);
		}
	}

	@Override
	protected void saveDate() {
		mAlarmList.clear();
		for (int i = 0; i < alarms.size(); i++) {
			AlarmNotify alarm = alarms.get(i);
			if (alarm.hasModify) {
				alarmNotifyDao.update(alarm);
				mAlarmList.add(alarm);
			}
		}
		if (!mAlarmList.isEmpty()) {
			showProgress();
			mCore.addListener(mAppListener);
			// 一条一条发送
			sendOneAlarm(mAlarmList.peek());
		} else {
			finish();
		}
	}
	
	private void sendOneAlarm(AlarmNotify alarm){
		sendingData = writeData(SettingsCmd.getInstance().getAlarmClockSettingsCmd(mAlarmList.peek()));
		adapter.sendingData = sendingData;
		adapter.notifyDataSetChanged();
		if (!sendingData) {
			onDataSendFailed();
		}
	}

	@Override
	protected void onDataSendFailed() {
		Toast.makeText(this, R.string.settingDataFail, Toast.LENGTH_SHORT).show();
		adapter.sendingData = false;
		showSureBtn();
	}

}
