package com.veryfit.multi.ui.activity.device;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;

import com.project.library.core.CoreServiceProxy;
import com.veryfit.multi.R;
import com.veryfit.multi.base.BaseActivity;
import com.veryfit.multi.ui.fragment.firstbound.AddDeviceFragment;
import com.veryfit.multi.ui.fragment.firstbound.AddDeviceFragment.OnFinishListener;

/*** 替换为AddDeviceFragment,现在用于解绑后重新绑定设备 */
public class AddDeviceActivity extends BaseActivity implements OnFinishListener {

	private AddDeviceFragment mAddDeviceFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_add_deivces);
		super.onCreate(savedInstanceState);

		showAddDeviceFragment();
	}

	private void showAddDeviceFragment() {
		if (mAddDeviceFragment == null) {
			mAddDeviceFragment = new AddDeviceFragment();
			mAddDeviceFragment.setOnFinishListener(this);
		}
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
		transaction.add(R.id.activity_add_devices_content, mAddDeviceFragment);
		transaction.commitAllowingStateLoss();
	}

	/** 移除fragment,并清理fragment里面的各种数据 */
	private void close() {
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
		if (mAddDeviceFragment != null) {
			mAddDeviceFragment.close();
			transaction.remove(mAddDeviceFragment);
			mAddDeviceFragment = null;
		}

		transaction.commitAllowingStateLoss();

		CoreServiceProxy core = CoreServiceProxy.getInstance();
		if (core.isAvailable() && !core.isDeviceConnected()) {
			core.disconnect();
		}
	}

	@Override
	protected void onThemeChanged() {

	}

	@Override
	protected void initFirst() {
		super.initFirst();
	}

	@Override
	protected void initView() {
		super.initView();

	}

	@Override
	protected void initData() {
		super.initData();
	}

	@Override
	protected void initEvent() {
		super.initEvent();

	}

	@Override
	protected void onDestroy() {
		close();
		super.onDestroy();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			close();
			finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void OnFinish() {
		close();
		finish();
	}

}
