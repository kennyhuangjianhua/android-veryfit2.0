package com.veryfit.multi.util;

import java.util.Calendar;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;


public class Util {

	public static String getMaxLenthString(String[] strs) {
		String maxLen = "";
		if (strs != null)
			for (String string : strs) {
				if (string != null)
					maxLen = maxLen.length() > string.length() ? maxLen : string;
			}
		return maxLen;
	}

	public static String formatTime(int hour, int min) {
		return String.format("%02d:%02d", hour, min);
	}

	public static int format24To12(int hour) {
		int h = hour % 12;
		h = h == 0 ? 12 : h;
		return h;
	}

	public static boolean isAM(int hour) {
		boolean isAM = false;
		if (hour < 13 && hour != 0) {
			isAM = true;
		}
		return isAM;
	}

	public static int format12To24(int hour, boolean isAm) {
		int h;
		if (isAm) {
			h = hour;
		} else {
			h = hour == 12 ? 23 : hour + 12;
		}
		return h;
	}

	public static boolean isSameDay(Calendar c1, Calendar c2) {
		return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) && c1.get(Calendar.MONTH) == c2.get(Calendar.MONTH) && c1.get(Calendar.DATE) == c2.get(Calendar.DATE);
	}

	public static String formatToMonthAndDate(Calendar c) {
		return (c.get(Calendar.MONTH) + 1) + "/" + c.get(Calendar.DATE);
	}

	public static String formatToMonthAndDate(Calendar c, int dateOffset) {
		c.add(Calendar.DATE, dateOffset);
		String time = (c.get(Calendar.MONTH) + 1) + "/" + c.get(Calendar.DATE);
		c.add(Calendar.DATE, -dateOffset);
		return time;
	}

	public static String ss(Calendar c) {
		return c.get(Calendar.YEAR) + "/" + (c.get(Calendar.MONTH) + 1) + "/" + c.get(Calendar.DATE);
	}

	/**
	 * 将一天中的分钟序列数变为对应的hh:mm形式
	 * 
	 * @param mins
	 *            00:00为第一分钟， mins = h * 60 + m;范围1~1440
	 * @return
	 */
	public static String timeFormatter(int mins, boolean is24) {
		if (mins > 0 && mins <= 1440) {
			int h = getHourAndMin(mins, is24)[0];
			int min = mins % 60;
			if (is24) {
				return String.format("%1$02d:%2$02d", h == 24 ? 0 : h, min);
			} else {
				String m = (mins > 60 && mins < 13 * 60) ? " am" : " pm";
				return String.format("%1$02d:%2$02d", h == 24 ? 0 : h, min) + m;
			}
		}
		Log.e("Util", "timeFormatter Error : mins is out of range (0 , 1440].");
		return "";
	}

	public static int[] getHourAndMin(int mins, boolean is24) {
		int h = mins / 60;
		// 0 ,12,24都是12点 ， 下午的-12
		h = is24 ? h : (h % 12 == 0 ? 12 : h > 12 ? h - 12 : h);
		return new int[] { h, mins % 60 };
	}

	public static String getTimeStr(int[] hourAndMin) {
		return hourAndMin[0] + ":" + hourAndMin[1];
	}

	
	public static Bitmap geByFilePath(String filePath){
		
		Bitmap bt=BitmapFactory.decodeFile(filePath);
		
		return bt;
	}

	/**
	 * 获取同步结束时间
	 * 
	 * @return 15/08/04 14:33
	 * */
	public static String getSyncTimeStr(Calendar c) {
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%02d/%02d/%02d ", c.get(Calendar.YEAR) % 1000, c.get(Calendar.MONTH) + 1, c.get(Calendar.DATE)));
		sb.append(String.format("%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)));

		return sb.toString();
	}
}
