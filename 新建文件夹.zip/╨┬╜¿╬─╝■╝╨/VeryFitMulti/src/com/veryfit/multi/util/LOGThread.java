package com.veryfit.multi.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class LOGThread extends Thread {
	private String mPid = "";
	private String cmds = "";
	private FileWriter mFileWriter = null;
	private String fileName = "/LogCat.txt";

	public LOGThread(String pid) {
		mPid = pid;
		cmds = "logcat -b main -v time | grep \"(" + mPid + ")\"";

		try {
			File f = new File(Constant.LOG_PATH);
			if (!f.exists()) {
				f.mkdirs();
			}

			File localFile = new File(Constant.LOG_PATH + fileName);
			if (localFile.exists()) {
				localFile.deleteOnExit();
			}
			localFile.createNewFile();

			mFileWriter = new FileWriter(localFile);
		} catch (Exception e) {

		}
	}

	@Override
	public void run() {
		try {
			Process logcatProc = Runtime.getRuntime().exec(cmds);
			BufferedReader mReader = new BufferedReader(new InputStreamReader(logcatProc.getInputStream()));
			String line = null;
			while ((line = mReader.readLine()) != null) {
				if (line.length() == 0) {
					continue;
				}

				if (line.contains(mPid)) {
					if (mFileWriter != null) {
						mFileWriter.write(line + "\n");
						mFileWriter.flush();
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
