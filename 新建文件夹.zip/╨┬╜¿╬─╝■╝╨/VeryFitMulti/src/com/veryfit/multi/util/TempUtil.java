package com.veryfit.multi.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import android.content.Context;
import android.content.res.Resources;
import com.veryfit.multi.R;
import com.veryfit.multi.view.DetailChart.PageData;
import com.veryfit.multi.view.DetailChart.PageData.LineData;
import com.veryfit.multi.view.DetailChart.PageData.LineData.PointModel;
import com.project.library.database.DaoSession;
import com.project.library.database.Goal;
import com.project.library.database.GoalDao;
import com.project.library.database.SleepDataDay;
import com.project.library.database.SleepDataDayDao;
import com.project.library.database.SleepDataItem;
import com.project.library.database.SleepDataItemDao;
import com.project.library.database.SportDataDay;
import com.project.library.database.SportDataDayDao;
import com.project.library.database.SportDataItem;
import com.project.library.database.SportDataItemDao;
import com.project.library.database.StatisticalData;
import com.project.library.database.StatisticalDataDao;
import com.project.library.database.StatisticalDataFactory;
import com.project.library.device.cmd.health.HealthDataDetailsCache;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;
import com.veryfit.multi.vo.SleepData;
import com.veryfit.multi.vo.SleepItem;
import com.veryfit.multi.vo.SportData;

import de.greenrobot.dao.query.QueryBuilder;

/**
 * 测试数据模拟类
 * 
 * @author Administrator
 * 
 */
public class TempUtil {

	private static Context context;

	public static void init(Context context) {
		TempUtil.context = context;
	}

	public static SportData getSprotByDate(Calendar c, int offset) {
		SportData data = new SportData();

		long date = LongDateUtil.Calendar2LongDate(c);
		date = LongDateUtil.sub(date, offset);
		data.date = LongDateUtil.LongDate2Calendar(date);

		DaoSession daoSession = DBTool.getInstance().getDaoSession();

		SportDataDayDao sportDao = daoSession.getSportDataDayDao();
		QueryBuilder<SportDataDay> sportDaoQb = sportDao.queryBuilder();
		sportDaoQb.where(com.project.library.database.SportDataDayDao.Properties.Date.eq(date));
		List<SportDataDay> list = sportDaoQb.list();
		if (list.isEmpty()) {
			data.details = new ArrayList<Integer>();
			// 默认96个(也就是每天每15分钟一个数据，最好是根据设备获取的时间间隔来算)
			for (int i = 0; i < 96; i++) {
				data.details.add(0);
			}
			return data;
		}
		SportDataDay sportDataDay = list.get(0);
		data.calorie = sportDataDay.getTotalCalory();
		data.distance = sportDataDay.getTotalDistance() / 1000f;
		data.steps = sportDataDay.getTotalstepCount();

		SportDataItemDao itemDao = daoSession.getSportDataItemDao();
		List<SportDataItem> entities = itemDao.queryBuilder().where(com.project.library.database.SportDataItemDao.Properties.Date.eq(date)).list();
		int len = entities.size();
		data.details = new ArrayList<Integer>();
		for (int i = 0; i < len; i++) {
			data.details.add(entities.get(i).getStepCount());
		}

		return data;
	}

	public static SleepData getSleepByDate(Calendar c, int offset) {
		SleepData data = new SleepData();
		long date = LongDateUtil.Calendar2LongDate(c);
		date = LongDateUtil.sub(date, offset);
		data.date = LongDateUtil.LongDate2Calendar(date);

		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		SleepDataDayDao sleepDao = daoSession.getSleepDataDayDao();
		QueryBuilder<SleepDataDay> sleepDaoQb = sleepDao.queryBuilder();
		sleepDaoQb.where(com.project.library.database.SleepDataDayDao.Properties.Date.eq(date));
		List<SleepDataDay> list = sleepDaoQb.list();
		if (list.isEmpty()) {
			data.endTime = new int[] { 0, 0 };
			// 没有数据，默认5个
			ArrayList<SleepItem> items = new ArrayList<SleepItem>();
			for (int i = 0; i < 5; i++) {
				items.add(new SleepItem());
			}
			data.setItems(items);
			return data;
		}
		SleepDataDay sleepDataDay = list.get(0);
		data.endTime = new int[] { sleepDataDay.getEndTimeHour(), sleepDataDay.getEndTimeMinute() };
		data.durationMins = sleepDataDay.getTotalSleepMinutes();
		data.deepTotal = sleepDataDay.getDeepSleepMinutes();
		data.lightTotal = sleepDataDay.getLightSleepMinutes();
		data.awakeTotal = data.durationMins - data.deepTotal - data.lightTotal;

		DebugLog.e(data.durationMins + ">" + data.deepTotal + ">" + data.lightTotal + ">" + data.awakeTotal);

		SleepDataItemDao itemDao = daoSession.getSleepDataItemDao();
		List<SleepDataItem> entities = itemDao.queryBuilder().where(com.project.library.database.SleepDataItemDao.Properties.Date.eq(date)).list();
		ArrayList<SleepItem> items = new ArrayList<SleepItem>();
		for (SleepDataItem sleepDataItem : entities) {
			items.add(new SleepItem(sleepDataItem.getSleepStatus() - 1, sleepDataItem.getSleepMinutes()));// status对应-1。方便画图
		}
		data.setItems(items);
		return data;
	}

	/** 点击主页title日期，画折线图的数据。总步数 */
	public static List<Integer> getDayTotalSteps(int page) {
		LinkedList<Integer> datas = new LinkedList<Integer>();

		HealthDataDetailsCache cache = HealthDataDetailsCache.getInstance();
		HashMap<Long, SportDataDay> sportMap = cache.getSportMap();

		long minDate = cache.getMinDate();
		long currentDate = LongDateUtil.Calendar2LongDate(Calendar.getInstance());
		while (currentDate >= minDate) {
			Integer totalSteps = 0;
			if (sportMap.containsKey(currentDate)) {
				totalSteps = sportMap.get(currentDate).getTotalstepCount();
			}
			datas.add(totalSteps);
			currentDate = LongDateUtil.sub(currentDate, 1);
		}

		return datas;
	}

	/** 点击主页title日期，画折线图的数据。总睡眠时长 */
	public static List<Integer> getTotalSleep(int page) {
		LinkedList<Integer> datas = new LinkedList<Integer>();

		HealthDataDetailsCache cache = HealthDataDetailsCache.getInstance();
		HashMap<Long, SleepDataDay> sleepMap = cache.getSleepMap();

		long minDate = cache.getMinDate();
		long currentDate = LongDateUtil.Calendar2LongDate(Calendar.getInstance());
		while (currentDate >= minDate) {
			Integer totalSleep = 0;
			if (sleepMap.containsKey(currentDate)) {
				totalSleep = sleepMap.get(currentDate).getTotalSleepMinutes();
			}
			datas.add(totalSleep);
			currentDate = LongDateUtil.sub(currentDate, 1);
		}

		return datas;
	}

	/**
	 * @param pageType
	 *            睡眠1，运动0
	 * 
	 * @param dataType
	 *            0-->周数据 ， 1-->月数据,2-->年数据
	 * 
	 * @return
	 */
	private static int getHealthMaxSize(int pageType, int dataType) {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		StatisticalDataDao statisticalDataDao = daoSession.getStatisticalDataDao();
		QueryBuilder<StatisticalData> statisticalBuilder = statisticalDataDao.queryBuilder();
		statisticalBuilder.where(com.project.library.database.StatisticalDataDao.Properties.HealthType.eq(pageType));
		statisticalBuilder.where(com.project.library.database.StatisticalDataDao.Properties.Type.eq(dataType));
		statisticalBuilder.orderDesc(com.project.library.database.StatisticalDataDao.Properties.StopTime);
		List<StatisticalData> list = statisticalBuilder.list();
		int count = 1;
		if(!list.isEmpty()){
			long date1 = list.get(list.size() - 1).getStopTime();
			long date2 = list.get(0).getStopTime();
			switch (dataType) {
			
			case Constant.DETAIL_CHART_TYPE_MONRH:
				count = LongDateUtil.getMonthsBetweenDates(date1, date2);
				break;
			case Constant.DETAIL_CHART_TYPE_YEAR:
				count = LongDateUtil.getYearsBetweenDates(date1, date2);
				break;
			case Constant.DETAIL_CHART_TYPE_WEEK:
			default:
				count = LongDateUtil.getWeeksBetweenDates(date1, date2);
				break;
			}
		}
		return count;
	}

	/**
	 * 第一次只加载一页数据。先画图，一边画图一边加载剩余未加载完的数据
	 * 
	 * @param dataType
	 *            0-->周数据 ， 1-->月数据,2-->年数据
	 * 
	 * @param pageType
	 *            睡眠1，运动0
	 * 
	 * @param pageOffset
	 *            页面偏移
	 * 
	 * @return
	 */
	public static CopyOnWriteArrayList<PageData> getPageDatas(int dataType, int pageType, int pageIndex) {
		CopyOnWriteArrayList<PageData> datas = new CopyOnWriteArrayList<PageData>();
		datas.add(getDetailChartPageData(dataType, pageType, pageIndex));
		return datas;
	}

	/** 每次4条，需要修改 */
	public static CopyOnWriteArrayList<PageData> getPageMoreDatas(int dataType, int pageType, int pageIndex, int pageSize) {
		CopyOnWriteArrayList<PageData> datas = new CopyOnWriteArrayList<PageData>();
		DebugLog.d("maxSize = " + getHealthMaxSize(pageType, dataType));
		// 本次加载的最大条数：数据足够，就只加载everyPageSize条，如果不够，剩多少就加载多少
		int maxSize = Math.min(1 + pageSize, getHealthMaxSize(pageType, dataType) - pageSize * pageIndex);
		for (int i = 1; i < maxSize; i++) {
			datas.add(getDetailChartPageData(dataType, pageType, i));
		}
		return datas;
	}

	/** 每次4条，需要修改 */
	public static CopyOnWriteArrayList<PageData> getPageLeftDatas(int dataType, int pageType, int pageSize) {
		CopyOnWriteArrayList<PageData> datas = new CopyOnWriteArrayList<PageData>();
		int maxSize = getHealthMaxSize(pageType, dataType);
		for (int i = 1 + pageSize; i < maxSize; i++) {
			datas.add(getDetailChartPageData(dataType, pageType, i));
		}
		return datas;
	}

	/**
	 * @param dataType
	 *            0-->周数据 ， 1-->月数据,2-->年数据
	 * 
	 * @param pageType
	 *            睡眠1，运动0
	 * 
	 * @param pageOffset
	 *            页面偏移
	 * 
	 * @return
	 */
	public static PageData getDetailChartPageData(int dataType, int pageType, int pageOffset) {
		PageData pageData = new PageData();
		// 目标为当前统计时间段的离结束时间最近的且在结束时间之前的那个目标
		long date = 20150101L;
		switch (dataType) {
		case 0:
			date = LongDateUtil.getFirstDayOfWeek(pageOffset);
			pageData.goal = getGoal(LongDateUtil.add(date, 7 - 1))[pageType];
			break;
		case 1:
			date = LongDateUtil.getFirstDayOfMonth(pageOffset);
			int monthDays = LongDateUtil.getMonthDay(LongDateUtil.getYear(date), LongDateUtil.getMonth(date));
			pageData.goal = getGoal(LongDateUtil.add(date, monthDays - 1))[pageType];
			
			break;
		case 2:
			date = LongDateUtil.getFirstDayOfYear(pageOffset);
			pageData.goal = 0;
			break;
		default:
			date = LongDateUtil.getFirstDayOfWeek(pageOffset);
			pageData.goal = getGoal(LongDateUtil.add(date,  7 - 1))[pageType];
			break;
		}

		StatisticalData statisticalData = StatisticalDataFactory.getData(dataType, pageType, date);
		Resources res = context.getResources();
		pageData.goalString = getGoalString(res, pageData.goal, pageType);// "8小时6分钟"
		pageData.tittle = statisticalData.getTitleString();
		pageData.dataShow0 = statisticalData.getPageType(pageType);
		pageData.lines = new LineData[pageType + 1];
		for (int i = 0; i < pageData.lines.length; i++) {
			LineData lineData = new LineData();
			switch (pageType) {
			case 1:
				if (i == 0) {
					lineData.color = res.getColor(R.color.detail_chart_totalSleep);
					lineData.name = res.getString(R.string.detail_totalSleep);
				} else if (i == 1) {
					lineData.color = res.getColor(R.color.detail_chart_deepSleep);
					lineData.name = res.getString(R.string.detail_deepSleep);
				}
				lineData.datas = getSleepPoints(dataType, i, pageOffset);
				break;
			case 0:
				lineData.datas = getSportPoints(dataType, pageOffset);
				lineData.color = 0xFFef5543;
				break;

			default:
				break;
			}

			pageData.lines[i] = lineData;
		}

		return pageData;
	}

	/**
	 * @param dataType
	 *            周月年
	 * 
	 * @param sleepType
	 *            0总睡眠1深睡
	 * 
	 * */
	public static ArrayList<PointModel> getSleepPoints(int dataType, int sleepType, int pageOffset) {
		switch (dataType) {
		case 0:
			long startTime = LongDateUtil.getFirstDayOfWeek(pageOffset);
			return getSleepWeeksMonthsData(dataType, sleepType, startTime, 7);
		case 1:
			startTime = LongDateUtil.getFirstDayOfMonth(pageOffset);
			return getSleepWeeksMonthsData(dataType, sleepType, startTime, LongDateUtil.getMonthDay(LongDateUtil.getYear(startTime), LongDateUtil.getMonth(startTime)));
		case 2:
			return getSleepYearData(sleepType, pageOffset);
		default:
			return null;
		}
	}

	/**
	 * @param dataType
	 *            0-->周数据 ， 1-->月数据,2-->年数据
	 **/
	public static ArrayList<PointModel> getSportPoints(int dataType, int pageOffset) {
		switch (dataType) {
		case 0:
			long startTime = LongDateUtil.getFirstDayOfWeek(pageOffset);
			return getSportWeeksMonthsData(dataType, startTime, 7);
		case 1:
			startTime = LongDateUtil.getFirstDayOfMonth(pageOffset);
			return getSportWeeksMonthsData(dataType, startTime, LongDateUtil.getMonthDay(LongDateUtil.getYear(startTime), LongDateUtil.getMonth(startTime)));
		case 2:
			return getSportYearData(pageOffset);
		default:
			return null;
		}
	}

	/**
	 * 每周加载7天数据，每月加载具体每月天数的数据
	 * 
	 * @param dataType
	 *            周月年
	 * 
	 * @param sleepType
	 *            0总睡眠1深睡
	 * 
	 * */
	private static ArrayList<PointModel> getSleepWeeksMonthsData(int dataType, int sleepType, long startTime, int days) {
		String[] weeks = context.getResources().getStringArray(R.array.weekDay);
		ArrayList<PointModel> points = new ArrayList<PageData.LineData.PointModel>();
		HashMap<Long, SleepDataDay> map = HealthDataDetailsCache.getInstance().getSleepMap();
		Resources res = context.getResources();
		long time = startTime;
		for (int i = 0; i < days; i++) {
			PointModel point = new PointModel();
			SleepDataDay data = map.get(time);
			int steps = data == null ? 0 : (sleepType == 0 ? data.getTotalSleepMinutes() : data.getDeepSleepMinutes());
			point.data = steps;
			// 如果是月数据，太密集，显示不下，故隔4个显示一个，并且显示最后一个
			if (dataType == 1) {
				if (i % 4 == 0 || i == days - 1) {
					point.dataName = "" + (i + 1);
				} else {
					point.dataName = "";
				}
			} else {
				point.dataName = (dataType == 0) ? (weeks[i]) : ("" + (i + 1));// 1234567--30
			}
			if (data == null) {
				point.dataLabel = new String[] { res.getString(R.string.detail_totalSleepLable, getGoalString(res, 0, 1)), res.getString(R.string.detail_deepSleepLable, getGoalString(res, 0, 1)), res.getString(R.string.detail_lightSleepLable, getGoalString(res, 0, 1)), };
			} else {
				point.dataLabel = new String[] { res.getString(R.string.detail_totalSleepLable, getGoalString(res, data.getTotalSleepMinutes(), 1)), res.getString(R.string.detail_deepSleepLable, getGoalString(res, data.getDeepSleepMinutes(), 1)), res.getString(R.string.detail_lightSleepLable, getGoalString(res, data.getLightSleepMinutes(), 1)), };
			}
			points.add(point);
			time = LongDateUtil.add(time, 1);
		}

		return points;
	}

	/**
	 * 每周加载7天数据，每月加载具体每月天数的数据
	 * 
	 * @param dataType
	 *            0-->周数据 ， 1-->月数据,2-->年数据
	 **/
	private static ArrayList<PointModel> getSportWeeksMonthsData(int dataType, long startTime, int days) {
		String[] weeks = context.getResources().getStringArray(R.array.weekDay);
		ArrayList<PointModel> points = new ArrayList<PageData.LineData.PointModel>();
		HashMap<Long, SportDataDay> map = HealthDataDetailsCache.getInstance().getSportMap();
		long time = startTime;
		for (int i = 0; i < days; i++) {
			PointModel point = new PointModel();
			SportDataDay data = map.get(time);
			int steps = data == null ? 0 : data.getTotalstepCount();
			point.data = steps;
			// 如果是月数据，太密集，显示不下，故隔4个显示一个，并且显示最后一个
			if (dataType == 1) {
				if (i % 4 == 0 || i == days - 1) {
					point.dataName = "" + (i + 1);
				} else {
					point.dataName = "";
				}
			} else {
				point.dataName = (dataType == 0) ? (weeks[i]) : ("" + (i + 1));// 1234567--30
			}
			point.dataLabel = new String[] { steps + " " + context.getString(R.string.unit_step) };
			points.add(point);
			time = LongDateUtil.add(time, 1);
		}

		return points;
	}

	/**
	 * 每年加载数据，是根据每个月的总和来算，要算平均的话也类似
	 * 
	 * @param sleepType
	 *            0总睡眠1深睡
	 * */
	private static ArrayList<PointModel> getSleepYearData(int sleepType, int pageOffset) {
		ArrayList<PointModel> points = new ArrayList<PageData.LineData.PointModel>();
		PointModel[] pointTmp = new PointModel[12];

		Resources res = context.getResources();
		HealthDataDetailsCache cache = HealthDataDetailsCache.getInstance();
		HashMap<Long, SleepDataDay> map = cache.getSleepMap();
		Set<Long> keySet = map.keySet();
		int m = 1;
		for (Long long1 : keySet) {
			m = LongDateUtil.getMonth(long1);
			if (pointTmp[m - 1] == null) {
				pointTmp[m - 1] = new PointModel();
			}
			pointTmp[m - 1].data += (sleepType == 0 ? map.get(long1).getTotalSleepMinutes() : map.get(long1).getDeepSleepMinutes());
			pointTmp[m - 1].dataLabel = new String[] { res.getString(R.string.detail_totalSleepLable, getGoalString(res, map.get(long1).getTotalSleepMinutes(), 1)), res.getString(R.string.detail_deepSleepLable, getGoalString(res, map.get(long1).getDeepSleepMinutes(), 1)), res.getString(R.string.detail_lightSleepLable, getGoalString(res, map.get(long1).getLightSleepMinutes(), 1)), };
		}

		for (int j = 1; j <= 12; j++) {
			if (pointTmp[j - 1] == null) {
				pointTmp[j - 1] = new PointModel();
				pointTmp[j - 1].dataLabel = new String[] { res.getString(R.string.detail_totalSleepLable, getGoalString(res, 0, 1)), res.getString(R.string.detail_deepSleepLable, getGoalString(res, 0, 1)), res.getString(R.string.detail_lightSleepLable, getGoalString(res, 0, 1)), };
			}
			pointTmp[j - 1].dataName = String.format("%02d", j);
			points.add(pointTmp[j - 1]);
		}

		return points;
	}

	/** 每年加载数据，是根据每个月的总和来算，要算平均的话也类似 */
	public static ArrayList<PointModel> getSportYearData(int pageOffset) {
		ArrayList<PointModel> points = new ArrayList<PageData.LineData.PointModel>();
		PointModel[] pointTmp = new PointModel[12];

		HealthDataDetailsCache cache = HealthDataDetailsCache.getInstance();
		HashMap<Long, SportDataDay> map = cache.getSportMap();
		Set<Long> keySet = map.keySet();
		int m = 1;
		for (Long long1 : keySet) {
			m = LongDateUtil.getMonth(long1);
			DebugLog.d(keySet.size() + "******m:" + m);
			if (pointTmp[m - 1] == null) {
				pointTmp[m - 1] = new PointModel();
			}
			pointTmp[m - 1].data += map.get(long1).getTotalstepCount();
		}

		for (int j = 1; j <= 12; j++) {
			if (pointTmp[j - 1] == null) {
				pointTmp[j - 1] = new PointModel();
				pointTmp[j - 1].dataLabel = new String[] { 0 + " " + context.getString(R.string.unit_step) };
			} else {
				pointTmp[j - 1].dataLabel = new String[] { pointTmp[j - 1].data + " " + context.getString(R.string.unit_step) };
			}
			pointTmp[j - 1].dataName = String.format("%02d", j);
			points.add(pointTmp[j - 1]);
		}

		return points;
	}

	/**
	 * 查询出time之前的最近的一个目标值，比如time 20150804 就可能返回20150803的目标值
	 * 
	 * @return int[0] 最近的sportGoal int[1] 最近的sleepGoal
	 * */
	public static int[] getGoal(long time) {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		GoalDao goalDao = daoSession.getGoalDao();
		QueryBuilder<Goal> qb = goalDao.queryBuilder();
		// 按日期降序排序，运动在奇数位（index == 0），睡眠在偶数位，即第一个是睡眠数据
		qb.where(com.project.library.database.GoalDao.Properties.Date.le(time));
		DebugLog.d("*****time = " + time);
		qb.orderDesc(com.project.library.database.GoalDao.Properties.Date, com.project.library.database.GoalDao.Properties.Type);
		List<Goal> listGoal = qb.list();
		if (listGoal.isEmpty()) {
			return new int[] { Constant.GOAL_SPORT, Constant.GOAL_SLEEP };
		} else {
			return new int[] { listGoal.get(1).getGoal(), listGoal.get(0).getGoal() };
		}

	}

	/**
	 * @param pageType
	 *            0 sport 1 sleep
	 * */
	public static String getGoalString(Resources res, int goal, int pageType) {
		String string = "";
		if (pageType == 0) {
			string = goal + res.getString(R.string.unit_step);
		} else {
			string = goal / 60 + res.getString(R.string.unit_hour_zh) + goal % 60 + res.getString(R.string.unit_minute_zh);
		}

		return string;
	}

	public static void saveGoal(Goal... goals) {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		GoalDao goalDao = daoSession.getGoalDao();
		for (Goal goal : goals) {
			QueryBuilder<Goal> qb = goalDao.queryBuilder();
			qb.where(com.project.library.database.GoalDao.Properties.Date.eq(goal.getDate()),com.project.library.database.GoalDao.Properties.Type.eq(goal.getType()));
			List<Goal> data = qb.list();
			if(data.isEmpty()){
				goalDao.insert(goal);
			}else{
				data.get(0).setGoal(goal.getGoal());
				goalDao.update(data.get(0));
			}
		}
	}

}
