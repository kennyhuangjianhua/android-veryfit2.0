package com.veryfit.multi.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.veryfit.multi.vo.Alarm;
import com.veryfit.multi.vo.Alarm.AlarmType;

public class TestUtil {

}
