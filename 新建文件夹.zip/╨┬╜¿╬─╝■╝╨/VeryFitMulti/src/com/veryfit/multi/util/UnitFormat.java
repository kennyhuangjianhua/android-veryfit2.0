package com.veryfit.multi.util;

public class UnitFormat {

	/**
	 * 
	 * @param inch
	 *            inch[0] 英尺 inch[1] 英寸
	 * @return cm
	 */
	public static int inch2cm(int[] inch) {
		inch[1] = inch[0] * 12 + inch[1];
		return Math.round(inch[1] * 2.54f);
	}

	/**
	 * 
	 * @param cm
	 * @return inch inch[0] 英尺 inch[1] 英寸
	 */
	public static int[] cm2inch(int cm) {
		int[] inch = new int[2];
		inch[1] = cm2inchs(cm);
		inch[0] = inch[1] / 12;
		inch[1] = inch[1] % 12;
		return inch;
	}

	/**
	 * 
	 * @param cm
	 * @return inch 英寸
	 */
	public static int cm2inchs(int cm) {
		return Math.round(cm / 2.54f);
	}

	public static int kg2lb(int kg) {
		return Math.round(2.2046226f * kg);
	}

	public static int lb2kg(int lb) {
		return Math.round(lb / 2.2046226f);
	}

}
