package com.veryfit.multi.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.Thread.UncaughtExceptionHandler;

import com.project.library.core.CoreServiceProxy;
import com.veryfit.multi.R;

import android.content.Context;
import android.os.Environment;
import android.os.Looper;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.Toast;

public class CrashHandler implements UncaughtExceptionHandler {

	private static final String TAG = "CrashHandler";

	// private UncaughtExceptionHandler defaultUEH;
	private Context mCtx;

	private CrashHandler() {

	}

	private static class CrashHandlerFactory {
		private static CrashHandler instance = new CrashHandler();
	}

	public static CrashHandler getInstance() {
		return CrashHandlerFactory.instance;
	}

	public CrashHandler init(Context context) {
		// this.defaultUEH = Thread.getDefaultUncaughtExceptionHandler();
		mCtx = context;

		return this;
	}

	@Override
	public synchronized void uncaughtException(Thread thread, Throwable ex) {
		new Thread() {
			@Override
			public void run() {
				Looper.prepare();
				String msg = mCtx.getResources().getString(R.string.app_error_exit);
				Toast.makeText(mCtx, msg, Toast.LENGTH_SHORT).show();
				CoreServiceProxy mCoreService = CoreServiceProxy.getInstance();
				if (mCoreService != null && mCoreService.isAvailable()) {
					mCoreService.disconnect();
				}
				CoreServiceProxy.fini();
				Looper.loop();
			}
		}.start();

		final Writer result = new StringWriter();
		final PrintWriter printWriter = new PrintWriter(result);

		// Inject some info about android version and the device, since google
		// can't provide them in the developer console
		StackTraceElement[] trace = ex.getStackTrace();
		StackTraceElement[] trace2 = new StackTraceElement[trace.length + 3];
		System.arraycopy(trace, 0, trace2, 0, trace.length);
		trace2[trace.length + 0] = new StackTraceElement("Android", "MODEL", android.os.Build.MODEL, -1);
		trace2[trace.length + 1] = new StackTraceElement("Android", "VERSION", android.os.Build.VERSION.RELEASE, -1);
		trace2[trace.length + 2] = new StackTraceElement("Android", "FINGERPRINT", android.os.Build.FINGERPRINT, -1);
		ex.setStackTrace(trace2);

		ex.printStackTrace(printWriter);
		String stacktrace = result.toString();
		printWriter.close();
		Log.e(TAG, stacktrace);

		// Save the log on SD card if available
		if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
			String path = Constant.LOG_PATH;
			File f = new File(path);
			if (!f.exists()) {
				f.mkdirs();
			}
			writeLog(stacktrace, path + "/project_crash");
			writeLogcat(path + "/project_logcat");
		}

		// defaultUEH.uncaughtException(thread, ex);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		}
		android.os.Process.killProcess(android.os.Process.myPid());
		System.exit(-1);
	}

	private void writeLog(String log, String name) {
		CharSequence timestamp = DateFormat.format("yyyyMMdd_kkmmss", System.currentTimeMillis());
		String filename = name + "_" + timestamp + ".log";

		try {
			FileOutputStream stream = new FileOutputStream(filename);
			OutputStreamWriter output = new OutputStreamWriter(stream);
			BufferedWriter bw = new BufferedWriter(output);

			bw.write(log);
			bw.newLine();

			bw.close();
			output.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void writeLogcat(String name) {
		CharSequence timestamp = DateFormat.format("yyyyMMdd_kkmmss", System.currentTimeMillis());
		String filename = name + "_" + timestamp + ".log";
		try {
			Logcat.writeLogcat(filename);
		} catch (IOException e) {
			Log.e(TAG, "Cannot write logcat to disk");
		}
	}
}
