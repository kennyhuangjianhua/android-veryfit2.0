package com.veryfit.multi.util;

public class DefaultConstant {

	public static final int SPORT_GOAL = 12000;

	public static final int[] SLEPP_GOAL = { 8, 10 };
}
