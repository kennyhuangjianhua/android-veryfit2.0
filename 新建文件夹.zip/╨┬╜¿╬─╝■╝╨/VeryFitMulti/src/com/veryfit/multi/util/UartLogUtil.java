package com.veryfit.multi.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.os.Environment;

public class UartLogUtil
{
    
    private static FileWriter fw;
    
    public static void open()
    {
        if (fw != null)
        {
            return;
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.CHINESE);
        File file = new File(Environment.getExternalStorageDirectory() + "/log_" + sdf.format(new Date()) + ".txt");
        try
        {
            fw = new FileWriter(file, true);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
    
    public static void write(String content)
    {
        if (fw != null)
        {
            try
            {
                fw.append(content);
                fw.flush();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
    
    public static void close()
    {
        if (fw != null)
        {
            try
            {
                fw.close();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            fw = null;
        }
    }
    
    public static void record(String content)
    {
    	File dir = new File(Constant.LOG_PATH);
		if(!dir.exists()){
			dir.mkdirs();
		}
		
    	deleteOldFile();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.CHINESE);
        File file = new File(Constant.LOG_PATH + "/dataLog_" + sdf.format(new Date()) + ".txt");
        FileWriter fw = null;
        try
        {
            fw = new FileWriter(file, true);
            fw.append(content);
            fw.flush();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (fw != null)
            {
                try
                {
                    fw.close();
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
    }

	private static void deleteOldFile() {
		Date date = new Date();
		date.setTime(date.getTime() - 10 * 24 * 3600 * 1000);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.CHINESE);
        File file = new File(Constant.LOG_PATH + "/dataLog_" + sdf.format(date) + ".txt");
		if(file.exists()){
			file.delete();
		}
	}
    
}
