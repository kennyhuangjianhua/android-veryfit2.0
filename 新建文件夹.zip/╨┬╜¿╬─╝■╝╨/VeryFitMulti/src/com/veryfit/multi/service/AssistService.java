package com.veryfit.multi.service;

import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.device.cmd.notify.IncomingCall;
import com.project.library.device.cmd.notify.NotifyCmd;
import com.project.library.util.DebugLog;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.activity.BaseNotifyBleActivity;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

/**
 * 辅助类service，涉及的功能有：监听来电，播放音乐
 * 
 * @author Administrator
 * 
 */
public class AssistService extends Service {

	private Handler handler = new Handler();
	private boolean hasFirstReigsterPhone;
	CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		DebugLog.d("onCreate ");
			mCore.addListener(mAppListener);
			registerPhoneListener();

	}

	protected APPCoreServiceListener mAppListener = new APPCoreServiceListener() {
		@Override
		public void onSettingsSuccess(byte cmdKey, boolean success) {

		}

		@Override
		public void onDataSendTimeOut(byte[] data) {

		}
	};

	private void registerPhoneListener() {
		TelephonyManager tpm = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
		// 创建一个监听对象，监听电话状态改变事件
		tpm.listen(new PhoneStateListener() {
			
			boolean hasSend;
			
			@Override
			public void onCallStateChanged(int state, String incomingNumber) {
				super.onCallStateChanged(state, incomingNumber);
				DebugLog.d("TelephonyManager   state = " + state + " ---incomingNumber" + incomingNumber);
				// 刚刚注册监听的时候，会调用一次onCallStateChange,需要屏蔽掉
				if (!hasFirstReigsterPhone) {
					hasFirstReigsterPhone = true;
					return;
				}
				
				
				
				
				
				
				
				if (AppSharedPreferences.getInstance().getDeviceRemindPhoneSwitch() && mCore.isDeviceConnected()) {
					switch (state) {
					case TelephonyManager.CALL_STATE_IDLE: // 空闲
						if(hasSend){
							mCore.writeForce(NotifyCmd.getInstance().getIncomingCallStatusCmd(IncomingCall.INCOMING_CALL_STATUS_REFUSE));
							hasSend = false;
						}

						break;
					case TelephonyManager.CALL_STATE_RINGING: // 来电
						handler.postDelayed(new Runnable() {

							@Override
							public void run() {
								IncomingCall message = new IncomingCall();
								mCore.writeForce(NotifyCmd.getInstance().getIncomingCallCmd(message));
								hasSend = true;
							}
						}, AppSharedPreferences.getInstance().getDeviceRemindPhoneDelay() * 1000L);
						break;
					case TelephonyManager.CALL_STATE_OFFHOOK: // 摘机（正在通话中）
						if(hasSend){
							mCore.writeForce(NotifyCmd.getInstance().getIncomingCallStatusCmd(IncomingCall.INCOMING_CALL_STATUS_ACCEPT));
							hasSend = false;
						}
						break;
					}
				}

			}
		}, PhoneStateListener.LISTEN_CALL_STATE);

	}

}
