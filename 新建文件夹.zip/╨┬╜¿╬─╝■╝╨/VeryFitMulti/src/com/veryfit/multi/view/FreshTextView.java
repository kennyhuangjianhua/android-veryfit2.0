package com.veryfit.multi.view;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RotateDrawable;
import android.util.AttributeSet;
import android.widget.TextView;

public class FreshTextView extends TextView {

	private boolean stateHasChange;

	public static final int STATE_PULLING = 1;

	public static final int STATE_FREE = 2;

	public static final int STATE_FRESHING = 3;

	private int state;

	public FreshTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	private static final int[] PULL_FRESH_SET = { R.attr.state_pull_fresh };

	private static final int[] FREE_FRESH_SET = { R.attr.state_free_fresh };

	private static final int[] FRESHING_SET = { R.attr.state_freshing };

	public void setState(int state) {
		stateHasChange = state != this.state;
		this.state = state;
		refreshDrawableState();
	}

	public int getState() {
		return state;
	}

	@Override
	protected int[] onCreateDrawableState(int extraSpace) {
		final int[] drawableState = super.onCreateDrawableState(extraSpace + 3);
		switch (state) {
		case STATE_PULLING:
			mergeDrawableStates(drawableState, PULL_FRESH_SET);
			break;
		case STATE_FREE:
			mergeDrawableStates(drawableState, FREE_FRESH_SET);
			break;
		case STATE_FRESHING:
			mergeDrawableStates(drawableState, FRESHING_SET);
			break;
		}
		// if (true) {
		// mergeDrawableStates(drawableState, OPEN_STATE_SET);
		// }
		return drawableState;
	}

}
