package com.veryfit.multi.view;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.ui.adapter.CirclePagerAdapter;
import com.veryfit.multi.view.DetailChart.PageData;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.LayoutInflater;

public class DetailViewPager extends ViewPager {

	/**
	 * 已经加载的view，可以重复利用的缓存池
	 */
	private ArrayList<DetailChart> cache = new ArrayList<DetailChart>();

	/**
	 * 当前在pager中使用的view，引用自缓存池
	 */
	private ArrayList<DetailChart> adapterView = new ArrayList<DetailChart>();

	private CirclePagerAdapter adapter;

	private PageListener listener;

	private CopyOnWriteArrayList<PageData> datas;

	public DetailViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);

		adapter = new CirclePagerAdapter(adapterView);
		setAdapter(adapter);

		/**
		 * 先默认加载3条数据
		 */
		createViewToCache(3);
		setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				if (listener != null) {
					
					int position = datas.size() - 1 - arg0;
					listener.onPageSelected(datas.get(position), position);
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

			}
		});
	}

	/**
	 * 当cache中的view数目小于data的数目时，就将数目增长到data的数目
	 */
	private void createViewToCache(int extraSpace) {
		if (extraSpace > 0) {
			long time = System.currentTimeMillis();
			LayoutInflater inflater = LayoutInflater.from(getContext());
			for (int i = 0; i < extraSpace; i++) {
				cache.add((DetailChart) inflater.inflate(R.layout.detail_chart, null));
			}
			DebugLog.d("extra = " + extraSpace + "*****" + (System.currentTimeMillis() - time));
		}
	}

	public void setDatas(CopyOnWriteArrayList<PageData> datas , int chartType) {
		setDatas(datas, 0 , chartType);
	}

	/**
	 * 添加的view是往右边添加的，而数据填充是从右往左添加的，所以会定位到最后一个view，显示的数据为第一个数据
	 * @param datas
	 * @param selectIndex
	 */
	public void setDatas(CopyOnWriteArrayList<PageData> datas, int selectIndex , int chartType) {
		this.datas = datas;
		pushData2View(datas , chartType);
		adapter.notifyDataSetChanged();
		setCurrentItem(datas.size() - 1 - selectIndex, false);
		if (listener != null) {
			selectIndex = Math.max(0, Math.min(selectIndex, datas.size() - 1));
			listener.onPageSelected(datas.get(selectIndex), selectIndex);
		}
	}

	/**
	 * 
	 * @param datas
	 */
	private void pushData2View(CopyOnWriteArrayList<PageData> datas , int chartType) {
		if (datas.size() != adapterView.size()) {
			adapterView.clear();
			createViewToCache(datas.size() - cache.size());
			for (int i = 0; i < datas.size(); i++) {
				DetailChart chart = cache.get(i);
				chart.setPageData(datas.get(datas.size() - 1 - i));
				chart.setType(chartType);
				DebugLog.d("type = " + chartType);
				adapterView.add(chart);
			}
			adapter.setAdapterView(adapterView);
		} else {
			for (int i = 0; i < datas.size(); i++) {
				adapterView.get(i).setPageData(datas.get(datas.size() - 1 - i));
				adapterView.get(i).setType(chartType);
			}
		}
	}

	public void setListener(PageListener listener) {
		this.listener = listener;
	}

	public interface PageListener {
		void onPageSelected(PageData selectedData, int index);

		/**
		 * 加载时，必须将睡眠和运动数据同步加载
		 * 
		 * @param pageIndex
		 */
		void needMore(int pageIndex);
	}

}
