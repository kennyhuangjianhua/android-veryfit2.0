package com.veryfit.multi.view;

import com.veryfit.multi.R;
import com.veryfit.multi.util.ViewUtil;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

/**
 * 先写成view，考虑到已经加载了很多view层级了，不想再放到group中了
 * 
 * @author Administrator
 * 
 */
public class DataShowView extends View {

	private int bgColor;

	private DataModel[] datas = {};

	private float w;

	private Paint valuePaint;

	private Paint unitPaint;

	private Paint symbolPaint;

	private float xStep;

	// 数值，单位的baseLine，单位的竖向中心位置
	private float valueBaseLine, unitBaseLine, unitCenterLine;

	private float symbolSize = 20;// 图例方块的尺寸

	private boolean centerY;

	// 测试代码
	// {
	// DataModel data1 = new DataModel();
	// data1.symbolColor = 0xff223355;
	// data1.value = 180 + "";
	// data1.unit = "步";
	// DataModel data2 = new DataModel();
	// data2.value = 55566 + "";
	// data2.unit = "卡路里";
	// setDatas(data1 , data2);
	// }

	public DataShowView(Context context, AttributeSet attrs) {
		super(context, attrs);

		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DataShowView);
		int textColor = a.getColor(R.styleable.DataShowView_android_textColor, getResources().getColor(R.color.theme_text_color_lable));
		int valueTextColor = a.getColor(R.styleable.DataShowView_valueTextColor, textColor);
		float valueSize = a.getDimension(R.styleable.DataShowView_valueTextSize, 28);
		float unitSize = a.getDimension(R.styleable.DataShowView_unitTextSize, 28);
		bgColor = a.getColor(R.styleable.DataShowView_bgColor, getResources().getColor(R.color.dataShowBg));
		centerY = a.getBoolean(R.styleable.DataShowView_centerY, false);
		a.recycle();

		valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		valuePaint.setTextAlign(Align.CENTER);
		valuePaint.setTextSize(valueSize);
		valuePaint.setColor(textColor);

		unitPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		unitPaint.setTextSize(unitSize);
		unitPaint.setTextAlign(Align.CENTER);
		unitPaint.setColor(valueTextColor);

		symbolPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		this.w = w;

		calculateY(h);
		calculateX();
	}

	private void calculateY(int h) {
		if (centerY) {
			float unitPadding = 20;
			float unitH = ViewUtil.getTextHeight(unitPaint);
			float valueH = ViewUtil.getTextHeight(valuePaint);
			float textTotalH = unitH + unitPadding + valueH;
			unitBaseLine = (h - (h - textTotalH) / 2) + (unitPaint.ascent() + unitPaint.descent()) / 2;
			valueBaseLine = ((h - textTotalH) / 2 + valueH) + (valuePaint.ascent() + valuePaint.descent()) / 2;
		} else {
			float valueBottom = ViewUtil.getTextHeight(valuePaint) + getPaddingTop();
			valueBaseLine = valueBottom + (valuePaint.ascent() + valuePaint.descent()) / 2;

			float unitTop = valueBottom + getPaddingTop() * 15f / 62;
			float unitBottom = unitTop + ViewUtil.getTextHeight(unitPaint);
			unitCenterLine = unitTop + (unitBottom - unitTop) / 2;
			// unit的baseLine为数值底部 + 数值与单位的padding + 单位的高度 + baseLine调整
			unitBaseLine = unitBottom + (unitPaint.ascent() + unitPaint.descent()) / 2;
		}
	}

	private void calculateX() {
		if (datas != null) {
			xStep = w / datas.length;
		}
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		canvas.drawColor(bgColor);
		float x;
		float unitWidth;
		for (int i = 0; i < datas.length; i++) {
			DataModel data = datas[i];
			x = xStep * (i + 0.5f);
			canvas.drawText(data.value, x, valueBaseLine, valuePaint);
			// 如果没有图例
			if (data.symbolColor == Color.TRANSPARENT) {
				canvas.drawText(data.unit, x, unitBaseLine, unitPaint);
			} else {
				// 如果有图例，就让图例和文字的水平中心线竖向与value对齐
				x += 4 + symbolSize / 2f;
				canvas.drawText(data.unit, x, unitBaseLine, unitPaint);
				unitWidth = ViewUtil.getTextRectWidth(unitPaint, data.unit);
				x -= unitWidth / 2;
				symbolPaint.setColor(data.symbolColor);
				canvas.drawRect(x - 8 - symbolSize, unitCenterLine - symbolSize / 2f, x - 8, unitCenterLine + symbolSize / 2f, symbolPaint);
			}
		}
	}

	public void initDatas(DataModel... datas) {
		this.datas = datas;
		calculateX();
	}

	public void updateData(int index, String value, String unit) {
		if (value != null)
			datas[index].value = value;
		if (unit != null)
			datas[index].unit = unit;
		invalidate();
	}

	public void setValueTypeface(Typeface typeface) {
		valuePaint.setTypeface(typeface);
	}

	public void setUnitColor(int color) {
		unitPaint.setColor(color);
	}

	public static class DataModel {
		/**
		 * 图例 默认透明的
		 */
		public int symbolColor = Color.TRANSPARENT;

		public String value;

		public String unit;

		public DataModel(int symbolColor, String value, String unit) {
			super();
			this.symbolColor = symbolColor;
			this.value = value;
			this.unit = unit;
		}

		public DataModel(String value, String unit) {
			super();
			this.value = value;
			this.unit = unit;
		}

		public DataModel() {
			super();
		}

		// public void updateValue(String value){
		// this.value = value;
		// invalidate();
		// }

	}

}
