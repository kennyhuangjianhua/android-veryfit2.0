package com.veryfit.multi.view.group;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;

import android.content.Context;
import android.graphics.drawable.RotateDrawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FreshView extends LinearLayout {

	private Context mContext;

	private ImageView img;

	private TextView text;

	public static final int STATE_PULLING = 1;

	public static final int STATE_FREE = 2;

	public static final int STATE_FRESHING = 3;

	private int state;

	public FreshView(Context context, AttributeSet attrs) {
		super(context, attrs);
		LayoutInflater.from(context).inflate(R.layout.refresh_layout, this);
		setOrientation(HORIZONTAL);
		setGravity(Gravity.CENTER);
		setBackgroundColor(getResources().getColor(R.color.sport_pie_bg));
		mContext = context;
		img = (ImageView) findViewById(R.id.fresh_img);
		text = (TextView) findViewById(R.id.fresh_text);

	}

	public int getState() {
		return this.state;
	}

	public void setState(int state) {
		this.state = state;
		img.clearAnimation();
		switch (state) {
		case STATE_PULLING:
			img.setImageResource(R.drawable.fresh_pull);
			text.setText(R.string.fresh_pull);
			break;
		case STATE_FREE:
			img.setImageResource(R.drawable.fresh_free);
			text.setText(R.string.fresh_free);
			break;
		case STATE_FRESHING:
			img.setImageResource(R.drawable.freshing);
			text.setText(R.string.freshing);
			img.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.freshing));
			break;
		}
	}

	/**
	 * @param percent
	 *            正在同步数据的百分比
	 * */
	public void setState(int state, int percent) {
		this.state = state;
		img.clearAnimation();
		switch (state) {
		case STATE_PULLING:
			img.setImageResource(R.drawable.fresh_pull);
			text.setText(R.string.fresh_pull);
			break;
		case STATE_FREE:
			img.setImageResource(R.drawable.fresh_free);
			text.setText(R.string.fresh_free);
			break;
		case STATE_FRESHING:
			img.setImageResource(R.drawable.freshing);
			text.setText(String.format(mContext.getString(R.string.freshing), percent + "%"));
			img.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.freshing));
			break;
		}
	}

}
