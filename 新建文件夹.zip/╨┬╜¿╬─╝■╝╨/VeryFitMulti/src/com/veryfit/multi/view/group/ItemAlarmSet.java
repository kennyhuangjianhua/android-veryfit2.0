package com.veryfit.multi.view.group;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.util.Util;
import com.veryfit.multi.view.ValueStateTextView;
import com.veryfit.multi.view.anim.ExpandAnimation;
import com.veryfit.multi.view.anim.ViewExpandAnimation;
import com.veryfit.multi.view.group.WeekDayCheck.OnWeekCheckedChange;
import com.veryfit.multi.view.wheel.ArrayWheelAdapter;
import com.veryfit.multi.view.wheel.NumericWheelAdapter;
import com.veryfit.multi.view.wheel.OnWheelChangedListener;
import com.veryfit.multi.view.wheel.WheelView;
import com.veryfit.multi.vo.Alarm;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.animation.ScaleAnimation;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ItemAlarmSet extends RelativeLayout {
	public static final int TYPE_ALARM_REMIND = 1;

	public static final int TYPE_ALARM_REPEAT = 2;

	public static final int TYPE_ALARM_TIME = 3;

	public static final int TYPE_ALARM_NAME = 4;

	public int type;

	private TextView lableView;

	private ValueStateTextView valueView;

	private String lable;

	private ViewStub editView;

	private Object[] params;

	private View view;// viewStub加载进来的view

	private String[] alarmTypes;

	public ItemAlarmSet(Context context, AttributeSet attrs) {
		super(context, attrs);
		LayoutInflater.from(context).inflate(R.layout.item_alarm_set, this, true);
		setBackgroundColor(getResources().getColor(R.color.theme_item_bg_color));
		lableView = (TextView) findViewById(R.id.lable);
		valueView = (ValueStateTextView) findViewById(R.id.value);

		alarmTypes = getResources().getStringArray(R.array.alarmType);
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ItemLableValue);

		lable = a.getString(R.styleable.ItemLableValue_lable_text);
		boolean isOpen = a.getBoolean(R.styleable.ItemLableValue_opened, false);
		boolean isEnable = a.getBoolean(R.styleable.ItemLableValue_android_enabled, true);
		int valueTextColor = a.getColor(R.styleable.ItemLableValue_valueTextColor, 0);
		Drawable rightDrawable = a.getDrawable(R.styleable.ItemLableValue_right_arrow);
		a.recycle();

		if (rightDrawable != null) {
			rightDrawable.setBounds(0, 0, rightDrawable.getIntrinsicWidth(), rightDrawable.getIntrinsicHeight());
			valueView.setCompoundDrawables(null, null, rightDrawable, null);
		}
		if (valueTextColor != 0) {
			valueView.setTextColor(valueTextColor);
		}

		lableView.setText(lable);

		valueView.setOpen(isOpen);
		valueView.setEnabled(isEnable);

		valueView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				ViewGroup p = (ViewGroup) getParent();
				for (int i = 0; i < p.getChildCount(); i++) {
					ItemAlarmSet child = (ItemAlarmSet) p.getChildAt(i);
					if (!child.equals(ItemAlarmSet.this) && child.valueView.isOpen()) {
						child.valueView.performClick();
					}
				}
				startExpandAnim();
				valueView.setOpen(!valueView.isOpen());
			}

		});
	}

	// public void setOpen(boolean open){
	// valueView.setOpen(open);
	// }

	protected void startExpandAnim() {
		if (view == null) {
			initStubView(type, params);
		}
		if (valueView.isOpen()) {
			view.setVisibility(View.GONE);
		} else {
			view.setVisibility(View.VISIBLE);
		}
		// this.startAnimation(ExpandAnimation.expand(this, true, 500));
		// view.startAnimation(new ScaleAnimation(1, 1, 0, 1));
		// this.startAnimation(new ViewExpandAnimation(view));

	}

	// @Override
	// protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
	// super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	// if(view != null)
	// DebugLog.d("**************measure***************" +
	// view.getMeasuredHeight() + "*****" + view.getHeight());
	// int h = lableView.getMeasuredHeight() ;
	// if(view != null && view.getVisibility() != View.GONE){
	// h += view.getMeasuredHeight();
	// }
	// setMeasuredDimension(widthMeasureSpec, h);
	// }

	/**
	 * 
	 * @param type
	 *            共四种，remind ,repeat , time , name;
	 * @param params
	 *            当前闹钟的该项值，用来给stub设置默认值 分别为alarmtypeId , repetition, [hour ,
	 *            min],typeName
	 */
	public void setStubType(int type, Object... params) {
		this.type = type;
		this.params = params;
		switch (type) {
		case TYPE_ALARM_NAME:
			valueView.setText(params[0] + "");
			break;
		case TYPE_ALARM_REPEAT:
			valueView.setText(Alarm.getCycle(getResources().getStringArray(R.array.weekDay), (Integer) params[0]));
			break;
		case TYPE_ALARM_REMIND:
			valueView.setText(alarmTypes[(Integer) params[0]]);
			break;
		case TYPE_ALARM_TIME:
			int hour = (Integer) params[0];
			int min = (Integer) params[1];
			String[] amOrpm = getResources().getStringArray(R.array.amOrpm);
			String s = amOrpm[Util.isAM(hour) ? 0 : 1] + " ";
			s += Util.formatTime(Util.format24To12(hour), min);
			valueView.setText(s);
			editView = (ViewStub) findViewById(R.id.viewstub_wheel);
			break;

		default:
			break;
		}
	}

	private void initStubView(int type, Object[] params) {
		switch (type) {
		case TYPE_ALARM_NAME:
			initNameStub((String) params[0]);
			break;
		case TYPE_ALARM_REPEAT:
			initRepeatStub((Integer) params[0]);
			break;
		case TYPE_ALARM_REMIND:
			initRemindStub((Integer) params[0]);
			break;
		case TYPE_ALARM_TIME:
			initTimeStub((Integer) params[0], (Integer) params[1]);
			break;

		default:
			break;
		}

	}

	private void initNameStub(String string) {
		editView = (ViewStub) findViewById(R.id.viewstub_editText);
		view = editView.inflate();
		// EditText

	}

	private void initTimeStub(Integer hour, Integer min) {
		editView = (ViewStub) findViewById(R.id.viewstub_time);
		view = editView.inflate();
		final WheelView wheelAm = (WheelView) view.findViewById(R.id.am);
		final String[] amOrpm = getResources().getStringArray(R.array.amOrpm);
		wheelAm.setAdapter(new ArrayWheelAdapter<String>(amOrpm, 4));
		wheelAm.setCurrentItem(Util.isAM(hour) ? 0 : 1);
		wheelAm.setCyclic(false);

		final WheelView wheelHour = (WheelView) view.findViewById(R.id.hour);
		wheelHour.setAdapter(new NumericWheelAdapter(1, 12));
		wheelHour.setCurrentItem(Util.format24To12(hour) - 1);

		final WheelView wheelMin = (WheelView) view.findViewById(R.id.min);
		wheelMin.setAdapter(new NumericWheelAdapter(0, 59));
		wheelMin.setCurrentItem(min);

		wheelAm.addChangingListener(new OnWheelChangedListener() {

			@Override
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				String am = amOrpm[newValue];
				int hour = wheelHour.getCurrentItem() + 1;
				int min = wheelMin.getCurrentItem();
				valueView.setText(am + " " + hour + ":" + min);
				params[0] = Util.format12To24(hour, newValue == 0);
				params[1] = min;
			}
		});

		wheelHour.addChangingListener(new OnWheelChangedListener() {

			@Override
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				String am = amOrpm[wheelAm.getCurrentItem()];
				int hour = newValue + 1;
				int min = wheelMin.getCurrentItem();
				valueView.setText(am + " " + hour + ":" + min);
				params[0] = Util.format12To24(hour, wheelAm.getCurrentItem() == 0);
				params[1] = min;
			}
		});

		wheelMin.addChangingListener(new OnWheelChangedListener() {

			@Override
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				String am = amOrpm[wheelAm.getCurrentItem()];
				int hour = wheelHour.getCurrentItem() + 1;
				int min = newValue;
				valueView.setText(am + " " + hour + ":" + min);
				params[0] = Util.format12To24(hour, wheelAm.getCurrentItem() == 0);
				params[1] = min;
			}
		});

	}

	private void initRepeatStub(Integer repeat) {
		editView = (ViewStub) findViewById(R.id.viewstub_cycle);
		view = editView.inflate();
		WeekDayCheck dayCheck = (WeekDayCheck) view.findViewById(R.id.cycle_p);
		dayCheck.initAndSetDefault(repeat);
		dayCheck.setOnChangeLinstener(new OnWeekCheckedChange() {

			@Override
			public void onChange(int newRepetitions) {
				params[0] = newRepetitions;
				valueView.setText(Alarm.getCycle(getResources().getStringArray(R.array.weekDay), (Integer) params[0]));
			}
		});
	}

	private void initRemindStub(int alarmTypeId) {
		editView = (ViewStub) findViewById(R.id.viewstub_wheel);
		view = editView.inflate();
		WheelView wheel = (WheelView) view.findViewById(R.id.wheel);
		wheel.setAdapter(new ArrayWheelAdapter<String>(alarmTypes));
		wheel.setCurrentItem(alarmTypeId);
		wheel.addChangingListener(new OnWheelChangedListener() {

			@Override
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				valueView.setText(alarmTypes[newValue]);
				params[0] = newValue;
			}
		});
	}

	public Object[] getValue() {
		return params;
	}
}
