package com.veryfit.multi.view;

import java.util.ArrayList;
import java.util.List;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.util.Util;
import com.veryfit.multi.util.ViewUtil;
import com.veryfit.multi.vo.SleepData;
import com.veryfit.multi.vo.SleepItem;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

public class SleepBarChart extends View {

	private float yZero, xZero, tittleBottom;

	private int h, w;

	// 依次为醒着，浅睡，深睡
	private int[] colors = new int[] { 0xFFFFFFFF, 0x88FFFFFF, Color.BLUE };

	private int textColor = 0xFFFFFFFF;

	// private float x

	/**
	 * 分钟数与x坐标的转换比
	 */
	private float scale;

	/**
	 * 一天当中的分钟数序号，从1开始，结束于1440
	 */
	private int startTime, endTime;
	/**
	 * 睡眠总时长(由外部传入进来，自己不计算)
	 */
	private int total_mins;

	private Paint paint;

	private float xLabelTextSize = 26, tittleTextSize;

	private float xAxisLength;

	private boolean is24 = true;

	private ArrayList<Bar> bars = new ArrayList<Bar>();

	private List<SleepItem> datas;

	private Drawable topDrawable;

	private String tittle;
	/** 从 0 到1 */
	private float progress = 1;

	private boolean anim = true;
	{
		// datas = new ArrayList<SleepItem>();
		// for (int i = 0; i < 7; i++) {
		// SleepItem item = new SleepItem();
		// item.state = (i % 3) + 1;
		// item.time = (int) (520 / 7f);
		// datas.add(item);
		// }
		// startTime = 1350;
		// endTime = 430;
		// total_mins = 520;
	}

	// public SLeepBarChart(Context context) {
	// super(context);
	// init();
	// }

	public SleepBarChart(Context context, AttributeSet attrs) {
		super(context, attrs);
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.SleepBarChart);
		Resources res = getResources();
		colors[2] = a.getColor(R.styleable.SleepBarChart_awake, res.getColor(R.color.sleep_bar_awake));
		colors[1] = a.getColor(R.styleable.SleepBarChart_lightSleep, res.getColor(R.color.sleep_bar_light));
		colors[0] = a.getColor(R.styleable.SleepBarChart_deepSleep, res.getColor(R.color.sleep_bar_deep));
		textColor = a.getColor(R.styleable.SleepBarChart_android_textColor, res.getColor(R.color.theme_text_color_lable));
		tittleTextSize = a.getDimension(R.styleable.SleepBarChart_tittleTextSize, 32);
		xLabelTextSize = a.getDimension(R.styleable.SleepBarChart_tittleTextSize, 26);
		a.recycle();
		topDrawable = res.getDrawable(R.drawable.sleep_bar_top);

		paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextAlign(Align.CENTER);
		init();
	}

	public int[] getBarColors() {
		return colors;
	}

	// public SLeepBarChart(Context context, AttributeSet attrs, int defStyle) {
	// super(context, attrs, defStyle);
	// init();
	// }

	private void init() {

	}

	// /**
	// * 设置睡眠的起止时间，持续时间
	// * @param start
	// * @param end
	// * @param duration 持续时间
	// */
	// public void setTimes(int start , int end , int duration){
	// startTime = start;
	// this.endTime = end;
	// total_mins = duration;
	// }

	private class Bar {

		public float width;

		public int color;

		public Bar(SleepItem item) {
			color = colors[item.state];
			width = scale * item.time;
		}

	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		this.h = h;
		this.w = w;
		paint.setTextSize(xLabelTextSize);
		float textWid = ViewUtil.getTextRectWidth(paint, Util.timeFormatter(startTime, is24));
		xZero = getPaddingLeft() + textWid / 2;

		xAxisLength = w - getPaddingRight() - textWid / 2 - xZero;

		float textHgt = ViewUtil.getTextHeight(paint);
		// 时间文字与bar的底部距离
		int textPadding = 5;
		yZero = h - getPaddingBottom() - textHgt - textPadding;

		topDrawable.setBounds(w / 2 - topDrawable.getIntrinsicWidth() / 2, getPaddingTop(), w / 2 + topDrawable.getIntrinsicWidth() / 2, topDrawable.getIntrinsicHeight() + getPaddingTop());
		paint.setTextSize(tittleTextSize);
		tittleBottom = topDrawable.getBounds().bottom + ViewUtil.getTextHeight(paint) + 20;

		initBars();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		canvas.save();
		if (anim) {
			canvas.clipRect(w / 2 * (1 - progress), 0, w / 2 * (1 + progress), h);
		}
		drawTittle(canvas);
		if( bars.size() == 0 || total_mins == 0){
			drawNoData(canvas);
		}else{
			drawBars(canvas);
			drawText(canvas);
		}
		canvas.restore();
	}
	
	private void drawNoData(Canvas canvas) {
		float step = xAxisLength / 8;
		float x = xZero;
		float top = tittleBottom + 20;
		paint.setAlpha(50);
		for (int i = 0; i < 9; i++) {
			canvas.drawLine(x, yZero, x, top, paint);
			x += step;
		}
		paint.setAlpha(255);
		paint.setTextAlign(Align.CENTER);
		canvas.drawText(getContext().getString(R.string.noData), w / 2, top + (h-top) / 2, paint);
	}
	
	

	public void startOpenAnim(AnimatorListener listener) {
		ObjectAnimator animator = ObjectAnimator.ofFloat(this, "progress", 0, 1).setDuration(800);
		// animator.setInterpolator(new DecelerateInterpolator());
		animator.addListener(new AnimatorListener() {

			@Override
			public void onAnimationStart(Animator animation) {

			}

			@Override
			public void onAnimationRepeat(Animator animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animator animation) {
				anim = false;

			}

			@Override
			public void onAnimationCancel(Animator animation) {
				anim = false;
				invalidate();
			}
		});
		if (listener != null) {
			animator.addListener(listener);
		}
		animator.start();

		anim = true;
	}

	public void startCloseAnim(AnimatorListener listener) {
		ObjectAnimator animator = ObjectAnimator.ofFloat(this, "progress", 1, 0).setDuration(800);
		if (listener != null) {
			animator.addListener(listener);
		}
		animator.start();
		anim = true;
	}

	private void setProgress(float progress) {
		this.progress = progress;
		invalidate();
	}

	private void drawTittle(Canvas canvas) {
		paint.setTextSize(tittleTextSize);
		paint.setColor(textColor);
		canvas.drawText(tittle, w / 2, tittleBottom + (paint.ascent() + paint.descent()) / 2, paint);
		topDrawable.draw(canvas);
	}

	private void drawBars(Canvas canvas) {
		float x = xZero;
		float top = tittleBottom + 20;
		for (Bar bar : bars) {
			paint.setColor(bar.color);
			canvas.drawRect(x, top, x + bar.width, yZero, paint);
			x += bar.width;
		}
	}

	/**
	 * 先根据startTime , endTime绘制出起止时间
	 * 再绘制中间的时间，中间时间绘制逻辑，根据total计算出步长，由start+step依次计算
	 * @param canvas
	 */
	private void drawText(Canvas canvas) {
		paint.setColor(textColor);
		paint.setTextSize(xLabelTextSize);
		float y = h - getPaddingBottom() + (paint.ascent() + paint.descent()) / 2;
		canvas.drawText(Util.timeFormatter(startTime, is24), xZero, y, paint);
		canvas.drawText(Util.timeFormatter(endTime, is24), xZero + xAxisLength, y, paint);
		float textWid = ViewUtil.getTextRectWidth(paint, Util.timeFormatter(startTime, is24));
		float x = xZero;
		// 两个数据的最小间距
		float padding = 20;
		// 确定要绘制的数据间隔，10小时以内，就间隔1小时，20小时就间隔2小时，以此类推
		int step = (total_mins / 60 / 10 + 1) * 60;
		// 找到startTime后的第一个正点时间的分钟数。point做为游标用，初始化为第一个正点数，之后每次移动step
		int point = startTime - startTime % step + step;
		// 如果第一个正点数和起始时间重合，那游标移动一格
		point = (point - startTime) * scale > textWid / 2 + padding ? point : (point + step);
		Log.d(VIEW_LOG_TAG, "step = " + step + "***point = " + point);
		// x为文字的坐标
		x += (point - startTime) * scale;
		// 直到最后一个文字与结束时间有重叠时，就结束绘制
		while (x < xZero + xAxisLength - textWid / 2 - padding) {
			// 如果跨天，就减去1440
			point -= point >= 1440 ? 1440 : 0;
			DebugLog.i("point = " + point);
			canvas.drawText(Util.getHourAndMin(point, is24)[0] + "", x, y, paint);
			point += step;

			x += step * scale;
		}
	}

	// public void setData(List<SleepItem> datas){
	// this.datas = datas;
	// invalidate();
	// }

	public void setData(SleepData data) {
		startTime = data.getStartTimeMins();
		endTime = data.getEndTimeMins();
		total_mins = data.getDurationMins();
		tittle = data.getDurationStr();
		tittle = data.getDuration()[0] + getResources().getString(R.string.unit_hour_en) + data.getDuration()[1] + getResources().getString(R.string.unit_minute_en);
		this.datas = data.getItems();
		initBars();
		invalidate();
	}

	private void initBars() {
		scale = xAxisLength / total_mins;
		bars.clear();
		
		for (SleepItem sleepItem : datas) {
			Bar bar = new Bar(sleepItem);
			bars.add(bar);
		}
	}

}
