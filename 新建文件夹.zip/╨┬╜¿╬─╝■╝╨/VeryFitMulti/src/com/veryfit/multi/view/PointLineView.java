package com.veryfit.multi.view;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import com.project.library.util.DebugLog;
import com.veryfit.multi.util.TempUtil;
import com.veryfit.multi.util.Util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.util.AttributeSet;

public class PointLineView extends HorzionScroll {

	// 满屏时最多显示7个点
	private final int VISIBLE_COUNT = 7;

	// private float textSize;

	// /**
	// * 每次加载时的数量
	// */
	// private final int LOAD_COUNT = 20;

	private Paint paint;

	private int w, h;

	private int color = 0xffef5440;

	// 点到点的距离
	private float pointDis;

	private float radius;

	private float bigRadius;

	private LinkedList<Integer> datas;

	/**
	 * y坐标与data的转换比 y = data * yScale;
	 */
	private float yScale;

	private float yZero;

	private int pointIndex;

	private float yAxisLength;

	private int selectIndex;

	// private String label;

	// private String unit;

	// private float textH;

	// private float textPadding;

	private int lineWidth = 3;

	private onDateScrolling linstener;

	// {
	// // label = "查看这一天";
	// // unit = "步";
	// // textSize = 30;
	// datas = new LinkedList<Integer>();
	// Random random = new Random();
	// for (int i = 0; i < 100; i++) {
	// Calendar c = Calendar.getInstance();
	// c.add(Calendar.DATE, -i);
	// c.set(Calendar.HOUR, random.nextInt(24));
	// Integer data = 0;
	// if(i == 0){
	// data = 10000;
	// }else{
	// data = Math.abs(random.nextInt(10000));
	// }
	// // data.date = c;
	// datas.add(data);
	// }
	// // if(linstener != null){
	// // linstener.onSelectChange(datas.get(0));
	// // }
	//
	// }

	public PointLineView(Context context) {
		super(context);
		init();
	}

	public PointLineView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public PointLineView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	private void init() {
		paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setColor(color);
		paint.setStyle(Style.STROKE);
		setWillNotDraw(false);
	}

	// public void setChosedDate(Calendar c){
	// Calendar current = datas.getFirst().date;
	// long time = current.getTimeInMillis() - c.getTimeInMillis();
	// float millisAllDay = 24f * 60 * 60 * 1000;
	// int index = (int) (time / millisAllDay) ;
	// DebugLog.d("current = " + current.getTimeInMillis() + "******checked = "
	// + c.getTimeInMillis() + "****index = " + index);
	// if(current.getTimeInMillis() % millisAllDay < c.getTimeInMillis() %
	// millisAllDay){
	// index ++;
	// DebugLog.d("***************");
	// }
	// scrollTo((int) (-index* pointDis), 0);
	// }

	public void setCurrentItem(int position) {
		selectIndex = position;
		// invalidate();
		scrollTo((int) (-position * pointDis), 0);
		if (linstener != null) {
			linstener.onScrolling(selectIndex);
		}
	}

	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		super.onScrollChanged(l, t, oldl, oldt);
		selectIndex = getRealScroll(-l) / (int) pointDis;
		if (linstener != null) {
			linstener.onScrolling(selectIndex);
		}
		// getChildAt(0).layout(getScrollX(),h - (int) (textH + textPadding),
		// getScrollX() + w, (int) (h - textPadding));
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		this.w = w;
		this.h = h;

		pointDis = w / VISIBLE_COUNT;
		radius = pointDis / 5;
		bigRadius = radius * 1.3f;

		// paint.setTextSize(textSize);
		// textH = ViewUtil.getTextHeight(paint);
		// textPadding = 30;

		// 1为那条线的宽度
		// yZero = h - textH - lineWidth - bigRadius - 2 * textPadding;
		// yAxisLength = yZero - textH - lineWidth - bigRadius- 2 * textPadding;
		yZero = h - 1 - bigRadius;
		yAxisLength = yZero - 1 - bigRadius;

		setYscale();
		if (selectIndex != 0) {
			scrollTo((int) (-selectIndex * pointDis), 0);
		}
	}

	private void setYscale() {
		float yMax = 0.1f;// 为了防止除0异常
		for (int i = 0; i < datas.size(); i++) {
			yMax = Math.max(yMax, datas.get(i));
		}
		yScale = yAxisLength / yMax;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		paint.setStrokeWidth(1);
		canvas.drawLine(getScrollX(), yZero - yAxisLength - bigRadius, w + getScrollX(), yZero - yAxisLength - bigRadius, paint);
		canvas.drawLine(getScrollX(), yZero + bigRadius, w + getScrollX(), yZero + bigRadius, paint);
		paint.setStrokeWidth(lineWidth);
		drawPoints(canvas);

		drawCenter(canvas);

		// drawText(canvas);

	}

	// private void drawText(Canvas canvas) {
	// paint.setAlpha(255);
	// int scroll = getRealScroll(-getScrollX());
	// //找到最近的点
	// int index = scroll % (int)pointDis > pointDis * 0.5f ? selectIndex + 1 :
	// selectIndex;
	// //不能大于数据个数
	// index = Math.min(index, datas.size()-1);
	// //绘制顶部数据
	// // canvas.drawText(datas.get(index) + unit, w / 2 + getScrollX(), textH +
	// textPadding, paint);
	//
	// //绘制底部提示信息
	// // canvas.drawText(label, w / 2 + getScrollX(), this.h - textPadding* 2 ,
	// paint);
	// }

	private void drawCenter(Canvas canvas) {
		paint.setStyle(Style.FILL);
		// x坐标始终在屏幕中心位置
		float cx = w / 2 + getScrollX();
		// 被选中的数据
		float yData1 = datas.get(selectIndex);
		// 默认选择光点的y位置为选中点的位置
		float cy = yZero - yData1 * yScale;
		// 如果在两点之间，计算他的y坐标
		if (selectIndex < datas.size() - 1) {
			float yData2 = datas.get(selectIndex + 1);
			cy -= (yData1 - yData2) * yScale / -pointDis * (getRealScroll(-getScrollX()) % pointDis);
		}
		canvas.drawCircle(cx, cy, radius, paint);
		paint.setStyle(Style.STROKE);
		canvas.drawCircle(cx, cy, bigRadius, paint);
		paint.setAlpha(125);
		paint.setStyle(Style.FILL);
		paint.setTextAlign(Align.CENTER);
		canvas.drawRect(cx - bigRadius, yZero - yAxisLength - bigRadius, cx + bigRadius, yZero + bigRadius, paint);

	}

	private void drawPoints(Canvas canvas) {
		paint.setAlpha(255);
		paint.setStyle(Style.STROKE);
		ArrayList<Integer> points = getVisiblePoints();
		for (int i = 0; i < points.size(); i++) {
			canvas.save();
			// 该点的y坐标
			float y = yZero - datas.get(pointIndex + i) * yScale;
			// 移动到该点处
			canvas.translate(w / 2 - pointDis * (pointIndex + i), y);
			canvas.drawCircle(0, 0, radius, paint);
			// Log.d(VIEW_LOG_TAG, "index = " + (pointIndex + i) +
			// "**********x = " + (- w / 2 - pointDis * (pointIndex + i)) +
			// "***************y = " + (yZero - datas.get(pointIndex + i) *
			// yScale));
			if (pointIndex + i < datas.size() - 1) {// 如果后面还有点，就要画线
				// 两点的竖向坐标距离
				float yDis = (datas.get(pointIndex + i) - datas.get(pointIndex + i + 1)) * yScale;
				// 两点连线的斜率角度
				float degree = (float) (180 / Math.PI * Math.atan2(yDis, -pointDis));
				canvas.rotate(degree);
				// 旋转后2点连线即为x轴，计算出2点距离
				float dis = (float) Math.sqrt(yDis * yDis + pointDis * pointDis);

				if (getScrollX() % pointDis == 0) {
					if (selectIndex == pointIndex + i) {

						canvas.drawLine(bigRadius, 0, dis - radius, 0, paint);
					} else if (selectIndex - 1 == pointIndex + i) {
						canvas.drawLine(radius, 0, dis - bigRadius, 0, paint);
					} else {
						canvas.drawLine(radius, 0, dis - radius, 0, paint);
					}
				} else {
					canvas.drawLine(radius, 0, dis - radius, 0, paint);
				}

			}
			canvas.restore();
		}

	}

	@Override
	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		if (linstener != null) {
			linstener.onScrolling(selectIndex);
		}
	}

	private ArrayList<Integer> getVisiblePoints() {
		ArrayList<Integer> points = new ArrayList<Integer>();
		pointIndex = (int) ((-getScrollX() - w / 2) / pointDis);
		pointIndex = Math.max(0, Math.min(pointIndex, datas.size()));
		int count = Math.min(VISIBLE_COUNT + pointIndex + 2, datas.size());
		for (int i = pointIndex; i < count; i++) {
			points.add(datas.get(i));
			// Log.d(VIEW_LOG_TAG, "index = " + pointIndex + "****data = " +
			// datas.get(i));
		}/*
		 * if(datas.size() - pointIndex < 20){ addMore(); }
		 */
		return points;
	}

	/*
	 * private void addMore() { ArrayList<Integer> newData =
	 * TempUtil.addMoreData(); if(newData == null){ return; } float yMax =
	 * yAxisLength / yScale; synchronized (datas) { for (Integer data : newData)
	 * { datas.add(data); yMax = Math.max(yMax, data); } } yScale = yAxisLength
	 * / yMax; }
	 */
	protected int getRealScroll(int scroll) {
		int maxOffset = (int) ((datas.size() - 1) * pointDis);
		return Math.min(maxOffset, Math.max(0, scroll));
	}

	@Override
	protected void endScorll() {
		super.endScorll();
		int scroll = getRealScroll(-getScrollX());
		// 找到最近的点
		int index = scroll % (int) pointDis > pointDis * 0.5f ? selectIndex + 1 : selectIndex;
		scrollTo((int) (-index * pointDis), 0);
	}

	public void setGraphColor(int color) {
		this.color = color;
	}

	public interface onDateScrolling {
		void onScrolling(int index);
	}

	public void setDateScrollingLinstener(onDateScrolling linstener) {
		this.linstener = linstener;
	}

	public void setDatas(List<Integer> datas) {
		this.datas = (LinkedList<Integer>) datas;
		setYscale();
		invalidate();
	}

}
