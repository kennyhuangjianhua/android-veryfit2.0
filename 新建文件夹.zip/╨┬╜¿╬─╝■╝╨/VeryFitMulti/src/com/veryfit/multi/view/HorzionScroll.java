package com.veryfit.multi.view;

import com.project.library.util.DebugLog;
import com.veryfit.multi.view.wheel.WheelAdapter;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.widget.Scroller;

public class HorzionScroll extends View {
	// /** Scrolling duration */
	// private static final int SCROLLING_DURATION = 400;
	//
	// /** Minimum delta for scrolling */
	// private static final int MIN_DELTA_FOR_SCROLLING = 1;
	//
	// // Scrolling animation
	// private GestureDetector gestureDetector;
	// private Scroller scroller;
	// private int lastScrollY;
	// // Scrolling
	// private boolean isScrollingPerformed;
	// private int scrollingOffset;
	// // gesture listener
	// private SimpleOnGestureListener gestureListener = new
	// SimpleOnGestureListener() {
	// public boolean onDown(MotionEvent e) {
	// if (isScrollingPerformed) {
	// scroller.forceFinished(true);
	// clearMessages();
	// return true;
	// }
	// return false;
	// }
	//
	// public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
	// float distanceY) {
	// startScrolling();
	// doScroll((int)-distanceY);
	// return true;
	// }
	//
	// public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
	// float velocityY) {
	// lastScrollY = currentItem * getItemHeight() + scrollingOffset;
	// int maxY = isCyclic ? 0x7FFFFFFF : adapter.getItemsCount() *
	// getItemHeight();
	// int minY = isCyclic ? -maxY : 0;
	// scroller.fling(0, lastScrollY, 0, (int) -velocityY / 2, 0, 0, minY,
	// maxY);
	// setNextMessage(MESSAGE_SCROLL);
	// return true;
	// }
	// };
	//
	// // Messages
	// private final int MESSAGE_SCROLL = 0;
	// private final int MESSAGE_JUSTIFY = 1;
	//
	// /**
	// * Set next message to queue. Clears queue before.
	// *
	// * @param message the message to set
	// */
	// private void setNextMessage(int message) {
	// clearMessages();
	// animationHandler.sendEmptyMessage(message);
	// }
	//
	// /**
	// * Clears messages from queue
	// */
	// private void clearMessages() {
	// animationHandler.removeMessages(MESSAGE_SCROLL);
	// animationHandler.removeMessages(MESSAGE_JUSTIFY);
	// }
	//
	// // animation handler
	// private Handler animationHandler = new Handler() {
	// public void handleMessage(Message msg) {
	// scroller.computeScrollOffset();
	// int currY = scroller.getCurrY();
	// int delta = lastScrollY - currY;
	// lastScrollY = currY;
	// if (delta != 0) {
	// doScroll(delta);
	// }
	//
	// // scrolling is not finished when it comes to final Y
	// // so, finish it manually
	// if (Math.abs(currY - scroller.getFinalY()) < MIN_DELTA_FOR_SCROLLING) {
	// currY = scroller.getFinalY();
	// scroller.forceFinished(true);
	// }
	// if (!scroller.isFinished()) {
	// animationHandler.sendEmptyMessage(msg.what);
	// } else if (msg.what == MESSAGE_SCROLL) {
	// justify();
	// } else {
	// finishScrolling();
	// }
	// }
	// };
	//
	// /**
	// * Justifies wheel
	// */
	// private void justify() {
	// if (adapter == null) {
	// return;
	// }
	//
	// lastScrollY = 0;
	// int offset = scrollingOffset;
	// int itemHeight = getItemHeight();
	// boolean needToIncrease = offset > 0 ? currentItem <
	// adapter.getItemsCount() : currentItem > 0;
	// if ((isCyclic || needToIncrease) && Math.abs((float) offset) > (float)
	// itemHeight / 2) {
	// if (offset < 0)
	// offset += itemHeight + MIN_DELTA_FOR_SCROLLING;
	// else
	// offset -= itemHeight + MIN_DELTA_FOR_SCROLLING;
	// }
	// if (Math.abs(offset) > MIN_DELTA_FOR_SCROLLING) {
	// scroller.startScroll(0, 0, 0, offset, SCROLLING_DURATION);
	// setNextMessage(MESSAGE_JUSTIFY);
	// } else {
	// finishScrolling();
	// }
	// }
	//
	// /**
	// * Starts scrolling
	// */
	// private void startScrolling() {
	// if (!isScrollingPerformed) {
	// isScrollingPerformed = true;
	// notifyScrollingListenersAboutStart();
	// }
	// }
	//
	// /**
	// * Finishes scrolling
	// */
	// void finishScrolling() {
	// if (isScrollingPerformed) {
	// notifyScrollingListenersAboutEnd();
	// isScrollingPerformed = false;
	// }
	// invalidateLayouts();
	// invalidate();
	// }
	//
	// /**
	// * Scroll the wheel
	// * @param itemsToSkip items to scroll
	// * @param time scrolling duration
	// */
	// public void scroll(int itemsToScroll, int time) {
	// scroller.forceFinished(true);
	// lastScrollY = scrollingOffset;
	// int offset = itemsToScroll * getItemHeight();
	// scroller.startScroll(0, lastScrollY, 0, offset - lastScrollY, time);
	// setNextMessage(MESSAGE_SCROLL);
	// startScrolling();
	// }
	//
	// @Override
	// public boolean onTouchEvent(MotionEvent event) {
	// WheelAdapter adapter = getAdapter();
	// if (adapter == null) {
	// return true;
	// }
	// if (!gestureDetector.onTouchEvent(event) && event.getAction() ==
	// MotionEvent.ACTION_UP) {
	// justify();
	// }
	// return true;
	// }
	//
	// /**
	// * Scrolls the wheel
	// * @param delta the scrolling value
	// */
	// private void doScroll(int delta) {
	// scrollingOffset += delta;
	//
	// int count = scrollingOffset / getItemHeight();
	// int pos = currentItem - count;
	// if (isCyclic && adapter.getItemsCount() > 0) {
	// // fix position by rotating
	// while (pos < 0) {
	// pos += adapter.getItemsCount();
	// }
	// pos %= adapter.getItemsCount();
	// } else if (isScrollingPerformed) {
	// //
	// if (pos < 0) {
	// count = currentItem;
	// pos = 0;
	// } else if (pos >= adapter.getItemsCount()) {
	// count = currentItem - adapter.getItemsCount() + 1;
	// pos = adapter.getItemsCount() - 1;
	// }
	// } else {
	// // fix position
	// pos = Math.max(pos, 0);
	// pos = Math.min(pos, adapter.getItemsCount() - 1);
	// }
	//
	// int offset = scrollingOffset;
	// if (pos != currentItem) {
	// setCurrentItem(pos, false);
	// } else {
	// invalidate();
	// }
	//
	// // update offset
	// scrollingOffset = offset - count * getItemHeight();
	// if (scrollingOffset > getHeight()) {
	// scrollingOffset = scrollingOffset % getHeight() + getHeight();
	// }
	// }
	//
	//
	//
	//

	public HorzionScroll(Context context) {
		super(context);
	}

	public HorzionScroll(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public HorzionScroll(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	protected float start;
	protected float pre;
	protected VelocityTracker velocityTracker;

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		switch (event.getAction() & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_DOWN:
			getParent().requestDisallowInterceptTouchEvent(true);
			removeCallbacks(goOnDraw);
			drawCount = 1;
			initOrResetVelocityTracker();
			velocityTracker.addMovement(event);
			start = event.getRawX();
			pre = start;
			break;
		case MotionEvent.ACTION_MOVE:
			velocityTracker.addMovement(event);
			// if(Math.abs(start - event.getRawX()) > 100){
			// getParent().requestDisallowInterceptTouchEvent(true);
			// }
			// DebugLog.d("dis = " + (int) (pre - event.getRawX() - 0.5));
			scrollBy((int) (pre - event.getRawX() - 0.5), 0);
			pre = event.getRawX();
			break;
		case MotionEvent.ACTION_UP:
			velocityTracker.addMovement(event);
			velocityTracker.computeCurrentVelocity(1000, ViewConfiguration.get(getContext()).getScaledMaximumFlingVelocity());
			mVelocity = (int) velocityTracker.getXVelocity();
			postDelayed(goOnDraw, 50);
			break;
		case MotionEvent.ACTION_CANCEL:
			DebugLog.e("cancle");
			endScorll();
			break;
		default:
			break;
		}
		return true;
	}

	protected int mVelocity, drawCount;

	protected Runnable goOnDraw = new Runnable() {
		private int REDRAW_COUNT = 20;

		@Override
		public void run() {
			if (drawCount < REDRAW_COUNT && Math.abs(mVelocity) > 5000) {
				int dis = (int) (mVelocity * 1.0f / REDRAW_COUNT * (REDRAW_COUNT - drawCount + 0.5) * 0.1 / (drawCount * 5));
				scrollBy(-dis, 0);
				drawCount++;
				postDelayed(goOnDraw, 500 / REDRAW_COUNT);
			} else {
				endScorll();
			}
		}
	};

	protected void endScorll() {
		recycleVelocityTracker();
		getParent().requestDisallowInterceptTouchEvent(false);
	}

	protected void recycleVelocityTracker() {
		if (velocityTracker != null) {
			velocityTracker.recycle();
			velocityTracker = null;
		}
	}

	protected void initOrResetVelocityTracker() {
		if (velocityTracker == null) {
			velocityTracker = VelocityTracker.obtain();
		} else {
			velocityTracker.clear();
		}
	}

}
