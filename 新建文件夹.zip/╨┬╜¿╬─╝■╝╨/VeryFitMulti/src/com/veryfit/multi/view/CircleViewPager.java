package com.veryfit.multi.view;

import java.util.ArrayList;
import java.util.List;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.ui.adapter.CirclePagerAdapter;
import com.veryfit.multi.view.DetailChart.PageData;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

public class CircleViewPager extends ViewPager {

	public static final int MOVE_TO_LEFT = 0;

	public static final int MOVE_TO_ROGHT = 1;

	public static final int UNMOVE = 2;

	private List<DetailChart> listViews = new ArrayList<DetailChart>();

	private int indexOffset;

	private PageListener onPageMoveListener;

	private int direction;
	private int state;

	private boolean smoothScroll = true;

	/** 依次是nextData , currentData , preData; */
	private PageData[] datas = new PageData[3];

	private ArrayList<PageData> dataList = new ArrayList<DetailChart.PageData>();

	private int pageIndex;

	public CircleViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	// public void initDatas(){
	// if(dataList.)
	// }

	private void init() {

		LayoutInflater mInflater = LayoutInflater.from(getContext());
		listViews.add((DetailChart) mInflater.inflate(R.layout.detail_chart, null));
		listViews.add((DetailChart) mInflater.inflate(R.layout.detail_chart, null));
		listViews.add((DetailChart) mInflater.inflate(R.layout.detail_chart, null));
		listViews.add((DetailChart) mInflater.inflate(R.layout.detail_chart, null));
		listViews.add((DetailChart) mInflater.inflate(R.layout.detail_chart, null));
		setAdapter(new CirclePagerAdapter(listViews));
		setCurrentItem(4);
		setOnPageChangeListener(new OnPageChangeListener() {

			private int lastPosition = 4;

			@Override
			public void onPageSelected(int position) {
				Log.v(VIEW_LOG_TAG, "****lastPosition = " + lastPosition + "**position = " + position + "***indexOffset = " + indexOffset);
				// 这里写的好恶心人，自己都看不下去了
				if (lastPosition == 0 && position == 3) {// 直接换屏
				// toLeft = true;
				} else if (lastPosition == 4 && position == 1) {
					// toLeft = false;
				} else if (position == 0 && indexOffset == dataList.size() - 1) {

				} else if (position == 4 && indexOffset == 0) {

				} else if (lastPosition == 0) {
					indexOffset--;
				} else if (lastPosition == 4) {
					indexOffset++;
				} else {
					indexOffset += lastPosition > position ? 1 : -1;
				}
				lastPosition = position;

			}

			@Override
			public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {

				// 当滑动停止的时候
				if (arg0 == 0) {
					Log.v(VIEW_LOG_TAG, "currentItem = " + getCurrentItem());

					if (indexOffset == 0) {
						setCurrentItem(4, false);
					} else if (indexOffset == dataList.size() - 1) {
						setCurrentItem(0, false);
					} else if (getCurrentItem() == 0) {
						setCurrentItem(3, false);

					} else if (getCurrentItem() == 4) {
						setCurrentItem(1, false);
					}
					update();
				}
				state = arg0;
			}
		});
	}

	/**
	 * 以当前显示的view页为中心，设置紧挨着他的前一条数据和后一条数据，因为viewPager默认自动加载3个view
	 */
	private void update() {
		if (onPageMoveListener != null) {
			onPageMoveListener.onPageSelected(dataList.get(indexOffset));
		}
		Log.v(VIEW_LOG_TAG, "indexOffset = " + indexOffset);
		int currentItem = getCurrentItem();
		// 加载中间页
		listViews.get(currentItem).setPageData(dataList.get(indexOffset));

		// 当前显示第一条数据 , 此时indexOffset = 0 ,只设置他的下一条数据
		if (currentItem == 4) {
			listViews.get(currentItem - 1).setPageData(dataList.get(indexOffset + 1));
			return;
		}

		// 当前显示最后一条数据，此时indexOffset = dataList.size() - 1 ，只设置他的前一条数据
		if (currentItem == 0) {
			listViews.get(currentItem + 1).setPageData(dataList.get(indexOffset - 1));
			return;
		}

		// 当为中间某一条时，就加载前一个和后一个
		listViews.get(currentItem - 1).setPageData(dataList.get(indexOffset + 1));
		listViews.get(currentItem + 1).setPageData(dataList.get(indexOffset - 1));

		if (currentItem == 1) {
			listViews.get(3).setPageData(dataList.get(indexOffset + 1));
		}

		if (currentItem == 3) {
			listViews.get(1).setPageData(dataList.get(indexOffset + 1));
		}

		if (indexOffset == dataList.size() - 2) {
			if (onPageMoveListener != null) {
				onPageMoveListener.needMore(pageIndex + 1);
			}
		}

	}

	@Override
	public void setCurrentItem(int item, boolean smoothScroll) {
		if (item < getCurrentItem()) {
			direction = MOVE_TO_LEFT;
		} else {
			direction = MOVE_TO_ROGHT;
		}
		this.smoothScroll = smoothScroll;

		super.setCurrentItem(item, smoothScroll);
	}

	@Override
	public void setCurrentItem(int item) {
		if (item < getCurrentItem()) {
			direction = MOVE_TO_LEFT;
		} else {
			direction = MOVE_TO_ROGHT;
		}
		this.smoothScroll = true;
		super.setCurrentItem(item);
	}

	public int getState() {
		return state;
	}

	public void setData(ArrayList<PageData> dataList) {
		this.dataList = dataList;

		update();
	}

	public void addData(ArrayList<PageData> dataList) {
		for (PageData pageData : dataList) {
			this.dataList.add(pageData);
		}
		pageIndex++;
	}

	/**
	 * 
	 */
	public void setDatas(PageData[] datas) {
		this.datas = datas;
		update();
	}

	public void setOnPageMoveListener(PageListener onPageMoveListener) {
		this.onPageMoveListener = onPageMoveListener;
	}

	public interface PageListener {
		void onPageSelected(PageData selectedData);

		/**
		 * 加载时，必须将睡眠和运动数据同步加载
		 * 
		 * @param pageIndex
		 */
		void needMore(int pageIndex);
	}

}
