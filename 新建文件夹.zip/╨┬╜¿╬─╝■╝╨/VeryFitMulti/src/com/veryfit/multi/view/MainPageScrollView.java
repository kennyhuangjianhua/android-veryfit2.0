package com.veryfit.multi.view;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.ScrollView;

public class MainPageScrollView extends ScrollView {
	private FreshTextView freshView;

	private int freshHeight;

	public MainPageScrollView(Context context, AttributeSet attrs) {
		super(context, attrs);

	}

	public void init() {
		// freshView = (FreshTextView)
		// (getChildAt(0).findViewById(R.id.fresh_view));
		getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {

			@Override
			public void onGlobalLayout() {
				getViewTreeObserver().removeOnGlobalLayoutListener(this);
				scrollTo(0, getFreshViewHeight());
			}
		});
	}

	public int getFreshViewHeight() {
		if (freshHeight == 0)
			freshHeight = freshView.getMeasuredHeight();
		return freshHeight;
	}

	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		super.onScrollChanged(l, t, oldl, oldt);
		DebugLog.d("t = " + t + "******oldt = " + oldt + "****height = " + getFreshViewHeight());
		if (t < getFreshViewHeight() && oldt >= getFreshViewHeight()) {
			DebugLog.e("*******************");
			freshView.setState(FreshTextView.STATE_PULLING);
		} else if (t == 0 && oldt < getFreshViewHeight()) {
			freshView.setState(FreshTextView.STATE_FREE);
		}
	}

}
