package com.veryfit.multi.view;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.view.group.FreshView;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.widget.LinearLayout;

public class MainPageLinearLayout extends LinearLayout {

	private static final int MIN_SCROLL = 100;

	private static final int DURATION = 500;

	private FreshView freshView;

	private int freshHeight;

	// private Text

	public MainPageLinearLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	/**
	 * 必须调用此方法
	 */
	public void init() {
		freshView = (FreshView) (findViewById(R.id.fresh_view));
		getViewTreeObserver().addOnPreDrawListener(new OnPreDrawListener() {

			@Override
			public boolean onPreDraw() {
				getViewTreeObserver().removeOnPreDrawListener(this);
				setPaddingTop(-getFreshViewHeight());
				return false;
			}
		});
	}

	public int getFreshViewHeight() {
		if (freshHeight == 0)
			freshHeight = freshView.getMeasuredHeight();
		return freshHeight;
	}

	public void setPaddingTop(int paddingTop) {
		setPadding(getPaddingRight(), paddingTop, getPaddingRight(), getPaddingBottom());
		invalidate();
	}

	private boolean isIntercept;

	private float startY;

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		DebugLog.d("isIntercept = " + isIntercept + ev.getAction());
		// if (getPaddingTop() <= 0 && isIntercept) {
		// return true;
		// }
		final int action = ev.getAction();

		switch (action & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_MOVE:
			if (ev.getY() - startY > MIN_SCROLL && getPaddingTop() == -getFreshViewHeight()) {// 下拉动作
				isIntercept = true;
			}
			break;
		case MotionEvent.ACTION_DOWN:
			startY = ev.getY();
			isIntercept = false;
			break;
		case MotionEvent.ACTION_UP:
		case MotionEvent.ACTION_CANCEL:
			startY = 0;
			isIntercept = false;
			break;
		}
		return isIntercept;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		super.onTouchEvent(event);
		if (freshView.getState() == FreshTextView.STATE_FRESHING) {// 如果正在刷新，就不做出理
			return false;
		}
		int currentTop = getPaddingTop();
		switch (event.getAction()) {
		case MotionEvent.ACTION_MOVE:
			int newPadding = Math.max(-getFreshViewHeight(), Math.min(0, (int) (event.getY() - startY) - getFreshViewHeight()));
			// DebugLog.e("onTouchEvent" +"action = " + event.getAction() +
			// "**startY = " + startY + "****y = " + event.getY() +
			// "***newPadding" + newPadding);
			setPaddingTop(newPadding);
			if (currentTop < 0) {
				freshView.setState(FreshTextView.STATE_PULLING);
			} else if (currentTop == 0) {
				freshView.setState(FreshTextView.STATE_FREE);
			}
			break;
		case MotionEvent.ACTION_CANCEL:
		case MotionEvent.ACTION_UP:
			if (currentTop < 0 && currentTop > -getFreshViewHeight()) {// 下拉未到底，滚回去
				ObjectAnimator.ofInt(this, "paddingTop", currentTop, -getFreshViewHeight()).setDuration((long) (DURATION * 1.0f / getFreshViewHeight() * (-currentTop))).start();
			} else if (currentTop == 0) {// 到底了，就显示刷新
				freshView.setState(FreshTextView.STATE_FRESHING);
				// 同步数据接口
				onStartUpdate();
				// 测试代码
				postDelayed(new Runnable() {

					@Override
					public void run() {
						onFinishUpdate();
					}
				}, 2000);
			}
			break;
		}
		return true;
	}

	private void onStartUpdate() {

	}

	public void onFinishUpdate() {
		ObjectAnimator.ofInt(this, "paddingTop", 0, -getFreshViewHeight()).setDuration(DURATION).start();
		freshView.setState(FreshTextView.STATE_PULLING);
	}

}
