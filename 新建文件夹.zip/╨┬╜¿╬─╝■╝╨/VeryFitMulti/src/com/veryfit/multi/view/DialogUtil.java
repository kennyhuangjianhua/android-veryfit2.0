package com.veryfit.multi.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.veryfit.multi.R;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.view.wheel.ArrayWheelAdapter;
import com.veryfit.multi.view.wheel.NumericWheelAdapter;
import com.veryfit.multi.view.wheel.OnWheelChangedListener;
import com.veryfit.multi.view.wheel.WheelView;

public class DialogUtil {

	/* 显示身高的dialog */
//<<<<<<< HEAD
//	public static final int METRIC = 1;
//	public static final int BRITISH = 2;
//	
//	/**
//	 * 选择单位的dialog
//	 * @param context
//	 * @param listener
//	 */
//	public static void showHeightFormatDialog(Context context,
//			final OnHeightFormatSelectListener listener) {
//=======

	public static void showHeightFormatDialog(Context context, final OnHeightFormatSelectListener listener) {
//>>>>>>> branch 'master' of git1906@192.168.2.123:app/gitspace/veryfit2
		final Dialog dialog = new Dialog(context, R.style.dialog);
		dialog.setContentView(R.layout.dialog_height_format);
		dialog.getWindow().setGravity(Gravity.CENTER);
		dialog.setCancelable(false);
		final RadioGroup rg = (RadioGroup) dialog.findViewById(R.id.rg_height_format);
		TextView sure = (TextView) dialog.findViewById(R.id.height_sure);
		rg.check(R.id.height_metric);

		sure.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (listener == null) {
					return;
				}
				if (rg.getCheckedRadioButtonId() == R.id.height_metric) {
					listener.onHeightFormat(Constant.METRIC);
				}

				if (rg.getCheckedRadioButtonId() == R.id.height_british) {
					listener.onHeightFormat(Constant.BRITISH);
				}
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	public interface OnHeightFormatSelectListener {
		public void onHeightFormat(int format);
	}


	public interface OnDialogButtonClick {
		void onCancleClick();

		void onSureClick();
	}

	/* 显示打开蓝牙的dialog */
	public static void showBleEnableDialog(final Context context) {
		final Dialog dialog = new Dialog(context, R.style.dialog);
		dialog.setContentView(R.layout.dialog_ble_enable);
		dialog.getWindow().setGravity(Gravity.CENTER);
		dialog.setCancelable(false);
		Button cancel = (Button) dialog.findViewById(R.id.ble_cancel);
		Button sure = (Button) dialog.findViewById(R.id.ble_sure);
		final BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
		cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		sure.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				dialog.dismiss();
				if (adapter == null) {
					Toast.makeText(context, R.string.ble_not_support, Toast.LENGTH_LONG).show();
				} else {
					if (!adapter.isEnabled()) {
						if (adapter.enable()) {
						}
					}
				}
			}
		});
		dialog.show();
	}

	/************************ WheelView ****************************************/
	/**
	 * 选择生日的dialog
	 */
	private static int START_YEAR = 1950, END_YEAR = 2090;

	public static void showWheelBirthDayDialog(final Context context,final int[] defaultValue, final OnBirthdaySelectListener listener) {
		final Dialog dialog = new Dialog(context, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_wheelviews);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.setCancelable(true);
		dialog.getWindow().getAttributes().width = ((Activity) context).getWindowManager().getDefaultDisplay().getWidth();
		final WheelView wv_year = (WheelView) dialog.findViewById(R.id.wv_1);
		final WheelView wv_month = (WheelView) dialog.findViewById(R.id.wv_2);
		final WheelView wv_day = (WheelView) dialog.findViewById(R.id.wv_3);
		
		wv_year.setVisibility(View.VISIBLE);
		wv_month.setVisibility(View.VISIBLE);
		wv_day.setVisibility(View.VISIBLE);
		initTimePicker(context, defaultValue , wv_year, wv_month, wv_day);
		dialog.findViewById(R.id.cancle).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});
		dialog.findViewById(R.id.set).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					int year = (wv_year.getCurrentItem() + START_YEAR);
					int month = (wv_month.getCurrentItem() + 1);
					int day = (wv_day.getCurrentItem() + 1);
					listener.onBirthdaySelect(year, month, day);
				}
				dialog.dismiss();
			}
		});
		dialog.show();
	}
	/**
	 * 选择时间的dialog
	 * @param context
	 * @param hour
	 * @param mintue
	 * @param listener
	 */
	public static void showWheelTimeDialog(final Context context,int hour,int mintue,
			final OnTimePickerSelectListener listener) {
		final Dialog dialog = new Dialog(context, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_wheelviews);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.setCancelable(true);
		dialog.getWindow().getAttributes().width = ((Activity) context)
				.getWindowManager().getDefaultDisplay().getWidth();
		final WheelView wv_hour = (WheelView) dialog.findViewById(R.id.wv_1);
		final WheelView wv_minute = (WheelView) dialog.findViewById(R.id.wv_2);
		wv_hour.setVisibility(View.VISIBLE);
		wv_minute.setVisibility(View.VISIBLE);
		String strHour=context.getResources().getString(R.string.hour);
		String strMinute=context.getResources().getString(R.string.minute);
		// 年
		wv_hour.setAdapter(new NumericWheelAdapter(0, 23,"%02d"));// 设置"年"的显示数据
		wv_hour.setCyclic(true);// 可循环滚动
		wv_hour.setCurrentItem(hour);// 初始化时显示的数据
		wv_hour.setVisibleItems(3);
		wv_hour.setLabel(strHour);
		// 月
		wv_minute.setAdapter(new NumericWheelAdapter(0, 59,"%02d"));
		wv_minute.setCyclic(true);
		wv_minute.setCurrentItem(mintue);
		wv_minute.setVisibleItems(3);
		wv_minute.setLabel(strMinute);
		dialog.findViewById(R.id.cancle).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});
		dialog.findViewById(R.id.set).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					int hour = (wv_hour.getCurrentItem());
					int minute = (wv_minute.getCurrentItem());
					listener.OnTimePickerSelect(hour, minute);
				}
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	
	public interface OnTimePickerSelectListener {
		public void OnTimePickerSelect(int hour, int minute);
	}


	public interface OnBirthdaySelectListener {
		public void onBirthdaySelect(int year, int month, int day);
	}

	private static void initTimePicker(Context context,
			final int[] defaultValue,
			final WheelView wv_year, final WheelView wv_month,
			final WheelView wv_day) {
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DAY_OF_MONTH);

		String[] months_big = { "1", "3", "5", "7", "8", "10", "12" };
		String[] months_little = { "4", "6", "9", "11" };

		final List<String> list_big = Arrays.asList(months_big);
		final List<String> list_little = Arrays.asList(months_little);
		wv_year.setLabel(context.getResources().getString(R.string.year));
		wv_month.setLabel(context.getResources().getString(R.string.month));
		wv_day.setLabel(context.getResources().getString(R.string.day));
		// 年
		wv_year.setAdapter(new NumericWheelAdapter(START_YEAR, END_YEAR));// 设置"年"的显示数据
		wv_year.setCyclic(true);// 可循环滚动
		wv_year.setCurrentItem(defaultValue[0] - START_YEAR);// 初始化时显示的数据
		wv_year.setVisibleItems(3);
		// 月
		wv_month.setAdapter(new NumericWheelAdapter(1, 12));
		wv_month.setCyclic(true);
		wv_month.setCurrentItem(defaultValue[1] - 1);
		wv_month.setVisibleItems(3);

		// 日
		wv_day.setCyclic(true);
		wv_day.setVisibleItems(3);
		// 判断大小月及是否闰年,用来确定"日"的数据
		if (list_big.contains(String.valueOf(month + 1))) {
			wv_day.setAdapter(new NumericWheelAdapter(1, 31));
		} else if (list_little.contains(String.valueOf(month + 1))) {
			wv_day.setAdapter(new NumericWheelAdapter(1, 30));
		} else {
			// 闰年
			if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
				wv_day.setAdapter(new NumericWheelAdapter(1, 29));
			else
				wv_day.setAdapter(new NumericWheelAdapter(1, 28));
		}
		wv_day.setCurrentItem(defaultValue[2]-1);

		// 添加"年"监听
		OnWheelChangedListener wheelListener_year = new OnWheelChangedListener() {
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				int year_num = newValue + START_YEAR;
				// 判断大小月及是否闰年,用来确定"日"的数据
				if (list_big.contains(String.valueOf(wv_month.getCurrentItem() + 1))) {
					wv_day.setAdapter(new NumericWheelAdapter(1, 31));
				} else if (list_little.contains(String.valueOf(wv_month.getCurrentItem() + 1))) {
					wv_day.setAdapter(new NumericWheelAdapter(1, 30));
				} else {
					if ((year_num % 4 == 0 && year_num % 100 != 0) || year_num % 400 == 0)
						wv_day.setAdapter(new NumericWheelAdapter(1, 29));
					else
						wv_day.setAdapter(new NumericWheelAdapter(1, 28));
				}
			}
		};
		// 添加"月"监听
		OnWheelChangedListener wheelListener_month = new OnWheelChangedListener() {
			public void onChanged(WheelView wheel, int oldValue, int newValue) {
				int month_num = newValue + 1;
				// 判断大小月及是否闰年,用来确定"日"的数据
				if (list_big.contains(String.valueOf(month_num))) {
					wv_day.setAdapter(new NumericWheelAdapter(1, 31));
				} else if (list_little.contains(String.valueOf(month_num))) {
					wv_day.setAdapter(new NumericWheelAdapter(1, 30));
				} else {
					if (((wv_year.getCurrentItem() + START_YEAR) % 4 == 0 && (wv_year.getCurrentItem() + START_YEAR) % 100 != 0) || (wv_year.getCurrentItem() + START_YEAR) % 400 == 0)
						wv_day.setAdapter(new NumericWheelAdapter(1, 29));
					else
						wv_day.setAdapter(new NumericWheelAdapter(1, 28));
				}
			}
		};

		wv_year.addChangingListener(wheelListener_year);
		wv_month.addChangingListener(wheelListener_month);
	}

	/* 性别 */
	public static void showWheelSexDialog(Context context,int defaultValue , 
			final OnWheelSelectorListener listener) {
		final Dialog dialog = new Dialog(context, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_wheelviews);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.setCancelable(true);
		dialog.getWindow().getAttributes().width = ((Activity) context).getWindowManager().getDefaultDisplay().getWidth();
		final WheelView wv_sex = (WheelView) dialog.findViewById(R.id.wv_1);
		wv_sex.setVisibility(View.VISIBLE);
		wv_sex.setVisibleItems(3);
		wv_sex.setCyclic(false);
		final String[] sexs = context.getResources().getStringArray(R.array.unit_sex);
		
		wv_sex.setAdapter(new ArrayWheelAdapter<String>(sexs));
		wv_sex.setCurrentItem(defaultValue);

		dialog.findViewById(R.id.cancle).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});
		dialog.findViewById(R.id.set).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					listener.onWheelSelect(wv_sex.getCurrentItem());
				}
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	/**
	 * 选择单位的dialog
	 * @param context
	 * @param listener
	 */
	public static void showUnitSetDialog(Context context,
			final OnWheelSelectorListener listener) {
		final Dialog dialog = new Dialog(context, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_wheelviews);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.setCancelable(true);
		dialog.getWindow().getAttributes().width = ((Activity) context)
				.getWindowManager().getDefaultDisplay().getWidth();
		final WheelView wv_unit = (WheelView) dialog.findViewById(R.id.wv_1);
		wv_unit.setVisibility(View.VISIBLE);
		wv_unit.setVisibleItems(3);
		wv_unit.setCyclic(false);
		final String[] formats = context.getResources().getStringArray(R.array.unit_format);
		wv_unit.setAdapter(new ArrayWheelAdapter<String>(formats,4));
		

		dialog.findViewById(R.id.cancle).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});
		dialog.findViewById(R.id.set).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					listener.onWheelSelect(formats[wv_unit.getCurrentItem()]);
				}
				dialog.dismiss();
			}
		});
		dialog.show();
	}

	/* 身高 */
	private static int START_HEIGHT = 50, END_HEIGHT = 280;
	/**
	 * 选择身高的dialog
	 * @param context
	 * @param listener
	 */
	public static void showWheelHeightDialog(Context context , int height ,final OnWheelSelectorListener listener) {
		final Dialog dialog = new Dialog(context, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_wheelviews);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.setCancelable(true);
		dialog.getWindow().getAttributes().width = ((Activity) context).getWindowManager().getDefaultDisplay().getWidth();
		final WheelView wv_height = (WheelView) dialog.findViewById(R.id.wv_1);
		wv_height.setVisibility(View.VISIBLE);
		wv_height.setVisibleItems(3);
		wv_height.setAdapter(new NumericWheelAdapter(START_HEIGHT, END_HEIGHT));
		wv_height.setCurrentItem(height - START_HEIGHT);

		dialog.findViewById(R.id.cancle).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});
		dialog.findViewById(R.id.set).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					listener.onWheelSelect(wv_height.getCurrentItem() + START_HEIGHT);
				}
				dialog.dismiss();
			}
		});
		dialog.show();

	}

	/* 体重 */
	private static int START_WEIGHT = 30, END_WEIGHT = 250;
	/**
	 * 选择体重的dialog
	 * @param context
	 * @param listener
	 */
	public static void showWheelWeightDialog(Context context,int defaultValue , final OnWheelSelectorListener listener) {
		final Dialog dialog = new Dialog(context, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_wheelviews);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.setCancelable(true);
		dialog.getWindow().getAttributes().width = ((Activity) context).getWindowManager().getDefaultDisplay().getWidth();
		final WheelView wv_weight = (WheelView) dialog.findViewById(R.id.wv_1);
		wv_weight.setVisibility(View.VISIBLE);
		wv_weight.setVisibleItems(3);
		wv_weight.setAdapter(new NumericWheelAdapter(START_WEIGHT, END_WEIGHT));
		wv_weight.setCurrentItem(defaultValue - START_WEIGHT);

		dialog.findViewById(R.id.cancle).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});
		dialog.findViewById(R.id.set).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (listener != null) {
					listener.onWheelSelect(wv_weight.getCurrentItem() + START_WEIGHT);
				}
				dialog.dismiss();
			}
		});
		dialog.show();

	}

	public interface OnWheelSelectorListener {
		public void onWheelSelect(Object obj);
	}
	
	
	/*拍照*/
	public static String photoTemp =  "/temp.png";
	
	public static String photoPath = "/avatar.jpg";
	
	private static final int NONE = 0;
	
	public static final int CAMERA = 1;
	
	public static final int PHOTOZOOM = 2;
	
	public static final int PHOTORESOULT = 3;
	/**
	 * 拍照的dialog
	 * @param activity
	 * @param fragment
	 */
	public static void showPhotosDaiglog(final Activity activity,final Fragment fragment) {
		final Dialog dialog = new Dialog(activity, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_take_photo);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.setCancelable(true);
		dialog.getWindow().getAttributes().width = (int)(activity.getWindowManager().getDefaultDisplay()
				.getWidth()*0.95f);
		File file = new File(Constant.PIC_PATH);
		if(!file.exists()){
			file.mkdirs();
		}
		dialog.findViewById(R.id.photo_remove).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub

					}
				});
		dialog.findViewById(R.id.photo_select_photos).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(Intent.ACTION_PICK, null);
						intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");
						if(fragment!=null){
							fragment.startActivityForResult(intent, PHOTOZOOM);
						}else{
							activity.startActivityForResult(intent, PHOTOZOOM);						
						}
						dialog.dismiss();
					}
				});
		dialog.findViewById(R.id.photo_take_photos).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
						intent.putExtra(MediaStore.EXTRA_OUTPUT,Uri.fromFile(new File(Constant.PIC_PATH +  photoTemp)));
						Log.v("showPhotosDaiglog", "filePath = " + (Constant.PIC_PATH +  photoTemp));
						if(fragment!=null){
							fragment.startActivityForResult(intent, CAMERA);
						}else{
							activity.startActivityForResult(intent, CAMERA);						
						}
						dialog.dismiss();
					}
				});
		dialog.findViewById(R.id.photo_cancel).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						dialog.dismiss();
					}
				});
		dialog.show();
	}
	
	public static Bitmap chooseFace(int requestCode, int resultCode, 
			Intent data, Activity activity,Fragment frament ) {
		if (resultCode == NONE)
			return null;
		if (requestCode == CAMERA) {
			File picture = new File(Constant.PIC_PATH +  photoTemp);
			startPhotoZoom(Uri.fromFile(picture), activity,frament);
		}
		if (data == null)
			return null;
		if (requestCode == PHOTOZOOM) {
			photoTemp = data.getData().toString()
					.substring(data.getData().toString().lastIndexOf("/") + 1);
			startPhotoZoom(data.getData(), activity,frament);
		}
		if (requestCode == PHOTORESOULT) {
			Bundle extras = data.getExtras();
			if (extras != null) {
				Bitmap photo = extras.getParcelable("data");
				File file = new File(Constant.PIC_PATH +  photoPath);
				try {
					file.createNewFile();
					FileOutputStream out = new FileOutputStream(file);
					if (photo.compress(Bitmap.CompressFormat.JPEG, 100, out)) {
						out.flush();
						out.close();
					}
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
				if (file.exists()) {// 创建好后，将原来的删掉
					File old = new File(Constant.PIC_PATH + photoTemp);
					if (old.exists()) {
						old.delete();
					}
				}
				return photo;
			}
			return null;
		} else {
			return null;
		}
	}

	public static void startPhotoZoom(Uri uri, Activity activity,Fragment fragment) {
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, "image/*");
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		intent.putExtra("outputX", 200);
		intent.putExtra("outputY", 200);
		intent.putExtra("return-data", true);
		Log.d("DialogUtil", "----startPhotoZoom");
		if(fragment!=null){
			fragment.startActivityForResult(intent, PHOTORESOULT);
		}else{
			activity.startActivityForResult(intent, PHOTORESOULT);			
		}
	}
	
	
	/**
	 * 显示解绑的dialog
	 * @param activity
	 */
	public static void showUnbindDialog(Activity activity,final OnUnBoundDeviceListener listener){
		final Dialog dialog = new Dialog(activity, R.style.MyDialog);
		dialog.setContentView(R.layout.dialog_unbound);
		dialog.getWindow().setGravity(Gravity.BOTTOM);
		dialog.setCancelable(true);
		dialog.getWindow().getAttributes().width = (int)(activity.getWindowManager().getDefaultDisplay()
				.getWidth()*0.95f);
		
		dialog.findViewById(R.id.unbund_dialog_delete_device).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if(listener!=null){
							listener.onUnBoundDevice();
						}
						dialog.dismiss();
					}
				});
		
		dialog.findViewById(R.id.unbund_dialog_cancel).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						dialog.dismiss();
					}
				});
		dialog.show();
	}
	
	public interface OnUnBoundDeviceListener{
		public void onUnBoundDevice();
	}
	
	/**
	 * 
	 * @param activity
	 * @param listener
	 */
	public static void showNoPowerDialog(Activity activity){
		final Dialog dialog = new Dialog(activity, R.style.dialog);
		dialog.setContentView(R.layout.dialog_nopower_msg);
		dialog.getWindow().setGravity(Gravity.CENTER);
		dialog.setCancelable(true);
		
		dialog.findViewById(R.id.sure).setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						
						dialog.dismiss();
					}
				});
		
		dialog.show();
	}
	

}
