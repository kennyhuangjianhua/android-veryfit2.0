package com.veryfit.multi.view;

import com.veryfit.multi.R;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * 此类增加一个openState
 * 
 * @author Administrator
 * 
 */
public class ValueStateTextView extends TextView {

	private boolean isOpen = false;

	private Drawable d;

	private static final int[] OPEN_STATE_SET = { R.attr.state_open };

	public ValueStateTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ValueStateTextView);
		d = a.getDrawable(R.styleable.ValueStateTextView_checkBackground);
		a.recycle();
	}

	public boolean isOpen() {
		return isOpen;
	}

	public void setOpen(boolean isOpen) {
		this.isOpen = isOpen;
		refreshDrawableState();

	}

	@Override
	protected int[] onCreateDrawableState(int extraSpace) {
		final int[] drawableState = super.onCreateDrawableState(extraSpace + 1);
		if (isOpen()) {
			mergeDrawableStates(drawableState, OPEN_STATE_SET);
		}
		return drawableState;
	}

	@Override
	protected void drawableStateChanged() {
		super.drawableStateChanged();
		if (d != null && d.isStateful()) {
			d.setState(getDrawableState());
		}
		invalidate();
	}

	@Override
	protected void onDraw(Canvas canvas) {
		if (d != null) {
			int w = getWidth();
			int h = getHeight();
			int size = Math.min(getWidth(), getHeight());
			d.setBounds(w / 2 - size / 2, h / 2 - size / 2, w / 2 + size / 2, h / 2 + size / 2);
			d.draw(canvas);
		}
		super.onDraw(canvas);
	}

}
