package com.veryfit.multi.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Path;
import android.graphics.Shader.TileMode;
import android.util.AttributeSet;
import android.util.Log;
//import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;

import com.veryfit.multi.util.ViewUtil;

public class HorizonRulerView extends View {

	public static final int HORIZONTAL = 0;
	public static final int VERTICAL = 1;

	protected int LINE_WIDTH = 2;

	protected int mShadowColor = 0xFF272727;

	protected int mRulerColor = 0xFFFFFFFF;

	protected int mLightColor = 0xFFA3D347;

	protected int mDevideCount = 5;

	protected int mMinData;

	protected int mMaxData;

	protected int mDataStep;

	protected String[] mUnits;

	protected String title;

	protected int w, h;

	protected int mSpaceSize;

	protected float mLineLength;

	protected Paint paint;

	protected int defaultOffset;// , offset;

	protected float textSize;

	protected int tickMarkStep;// 刻度线的距离

	protected int tickMarkDataStep;

	protected int maxLineCount;// 刻度线条数

	protected int[] data;// 当前选中的data

	{
		mMinData = 80;
		mMaxData = 250;
		mDataStep = 10;
		tickMarkDataStep = 1;
		title = "身高";
		// mUnits = new String[]{"m" ,"cm"};
		mUnits = new String[] { "cm" };
	}

	public HorizonRulerView(Context context) {
		super(context);
		init();
	}

	public HorizonRulerView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public HorizonRulerView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	private void init() {
		paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextAlign(Align.CENTER);
		paint.setStrokeWidth(LINE_WIDTH);
	}

	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		super.onScrollChanged(l, t, oldl, oldt);
		data = getDataByOffset(getRealScroll(getScrollX()));
		// Log.d(VIEW_LOG_TAG, "data = " + Arrays.toString(data));
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		this.w = w - getPaddingLeft() - getPaddingRight();
		this.h = h - getPaddingBottom() - getPaddingTop();
		Log.d("ywx", "onSizeChanged(" + w + "," + h + "," + oldw + "," + oldh + ")");
		Log.d("ywx", "pl:" + getPaddingLeft() + " pr:" + getPaddingRight() + " pb:" + getPaddingBottom() + " pt:" + getPaddingTop());
		mSpaceSize = (this.w - (mDevideCount * 2 * 4 + 1) * LINE_WIDTH) / (mDevideCount * 2 * 4 - 1);
		mLineLength = this.h * 0.28f;
		defaultOffset = w / 2 - LINE_WIDTH / 2;

		tickMarkStep = mSpaceSize + LINE_WIDTH;

		maxLineCount = (mMaxData - mMinData) / mDataStep * mDevideCount * 2 + 1;
		textSize = mLineLength * 0.2f;
		data = getDataByOffset(getRealScroll(getScrollX()));
	}

	@Override
	protected void onDraw(Canvas canvas) {
		drawTickMark(canvas);
		drawShadow(canvas);
		drawLabel(canvas);
	}

	private void drawShadow(Canvas canvas) {
		int x = computeHorizontalScrollOffset();
		paint.setShader(new LinearGradient(x, 0, getWidth() / 3 + x, 0, mShadowColor, 0x00000000, TileMode.CLAMP));
		canvas.drawRect(x, 0, getWidth() / 3 + x, getHeight(), paint);
		paint.setShader(new LinearGradient(getWidth() / 3 * 2 + x, 0, getWidth() + x, 0, 0x00000000, mShadowColor, TileMode.CLAMP));
		canvas.drawRect(getWidth() / 3 * 2 + x, 0, getWidth() + x, getHeight(), paint);
		paint.setShader(null);
	}

	private void drawLabel(Canvas canvas) {
		paint.setColor(mLightColor);
		int x = getWidth() / 2 - LINE_WIDTH / 2 + getScrollX();
		float y = this.h - mLineLength * 1.8f;
		canvas.drawLine(x, this.h, x, y, paint);
		// 画小三角
		float triangleSize = mLineLength * 0.1f;
		Path path = new Path();
		path.moveTo(x + triangleSize, y);
		path.lineTo(x, y - triangleSize * 1.8f);
		path.lineTo(x - triangleSize, y);
		path.close();
		canvas.drawPath(path, paint);
		// 画数值
		y -= mLineLength * 0.3f;

		// 初始化字体大小
		float textSizeBig = textSize * 2;
		float textSizeSmall = textSize * 1.5f;

		if (mUnits.length == 1) {
			paint.setTextSize(textSizeSmall);
			canvas.drawText(mUnits[0], x, y, paint);
			y -= ViewUtil.getTextHeight(paint);
			paint.setTextSize(textSizeBig);
			canvas.drawText((data[0] + data[1]) + "", x, y, paint);
			y -= ViewUtil.getTextHeight(paint);
			paint.setTextSize(textSizeSmall);
			canvas.drawText(title, x, y, paint);
		} else if (mUnits.length == 2) {
			// 计算文字宽度,因为需要文字居中，文字大小不一，故依依算出每个宽度
			// 数字与单位的间距
			float padding = mLineLength * 0.1f;
			// 第一个数字宽度x1 和 第二个数字宽度x3
			paint.setTextSize(textSizeBig);
			float x1 = ViewUtil.getTextRectWidth(paint, data[0] + "");
			float x3 = ViewUtil.getTextRectWidth(paint, data[1] + "");
			// 第一个单位的宽度x2 和 第二个单位宽度x4
			paint.setTextSize(textSizeSmall);
			float x2 = ViewUtil.getTextRectWidth(paint, mUnits[0]);
			float x4 = ViewUtil.getTextRectWidth(paint, mUnits[1]);
			float totalX = x1 + padding + x2 + padding + x3 + padding + x4;

			paint.setTextAlign(Align.LEFT);
			paint.setTextSize(textSizeBig);
			canvas.drawText(data[0] + "", x - totalX / 2, y, paint);
			canvas.drawText(data[1] + "", x - totalX / 2 + x1 + padding + x2 + padding, y, paint);

			paint.setTextSize(textSizeSmall);
			canvas.drawText(mUnits[0], x - totalX / 2 + x1 + padding, y, paint);
			canvas.drawText(mUnits[1], x - totalX / 2 + x1 + padding + x2 + padding + x3 + padding, y, paint);

			paint.setTextAlign(Align.CENTER);
			paint.setTextSize(textSizeBig);
			y -= ViewUtil.getTextHeight(paint);
			paint.setTextSize(textSizeSmall);
			canvas.drawText(title, x, y, paint);
		}
	}

	private void drawTickMark(Canvas canvas) {
		// 计算满屏时，可见刻度线的条数。满屏时有4个大格子，每个大格子有2个中等格子，每个中等格子中有mDevideCount个小格子。线的条数比格子多1
		Log.d("---", "--------------------------");
		int lineCount = mDevideCount * 2 * 4 + 1;
		int scrollX = getScrollX();
		canvas.save();
		/*
		 * 默认的原点在view的中心位置，即defaultOffset,当view移动时，就将原点移动到scrollX 第一个可见的线
		 */
		canvas.translate(defaultOffset - scrollX, 0);
		canvas.clipRect(getPaddingLeft() - defaultOffset + scrollX, 0, w + getPaddingLeft() - defaultOffset + scrollX, getMeasuredHeight());
		Log.d("ywx", "defaultOffset:" + defaultOffset);
		paint.setColor(mRulerColor);
		paint.setTextSize(textSize);
		// 求出刻度线index的偏移值
		// ,如果还未满屏，那第一条线的index始终为0，如果已经满屏，那么出屏的距离除以每个线距+1即为第一个可见线的index
		int i = scrollX < defaultOffset ? 0 : (scrollX - defaultOffset) / tickMarkStep + 1;
		// 可见线的最大index
		lineCount += i;
		// 刻度线最大条数不能大于需要显示的总刻度条数
		lineCount = Math.min(lineCount, maxLineCount);
		Log.d("drawTickMark", "scrollX:" + scrollX + " +lines:" + scrollX / tickMarkStep);
		Log.d("drawTickMark", "i:" + i + " lineCount:" + lineCount + " maxLineCount:" + maxLineCount);
		for (; i < lineCount; i++) {
			int x = i * tickMarkStep + scrollX;// +scroll将坐标移到第一个可见线处
			float yScale = 0;
			if (i % mDevideCount == 0) {
				if (i / mDevideCount % 2 == 0) {// 整数刻度，加上label
					yScale = 1.0f;
					// 文字竖向位置用mLineLength作参考
					// 获取该刻度线所对应的数值，x-scroll是该刻度线的x坐标
					canvas.drawText(getDataByOffset(x - scrollX)[0] + "", x, this.h - mLineLength * 1.1f, paint);
				} else {
					yScale = 0.6f;
				}
			} else {
				yScale = 0.4f;
			}
			canvas.drawLine(x, this.h, x, this.h - mLineLength * yScale, paint);
			Log.d("drawTickMark", "line(" + x + "," + this.h + ")-(" + x + "," + (this.h - mLineLength * yScale) + ")");
		}
		canvas.restore();
	}

	protected int[] getDataByOffset(int offset) {
		int[] data = new int[2];
		data[0] = offset / ((mDevideCount * 2) * tickMarkStep) * mDataStep + mMinData;
		data[1] = (offset % ((mDevideCount * 2) * tickMarkStep)) / tickMarkStep;
		data[1] *= tickMarkDataStep;
		return data;
	}

	protected float start, pre;
	protected VelocityTracker velocityTracker;

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		switch (event.getAction() & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_DOWN:
			removeCallbacks(goOnDraw);
			drawCount = 1;
			initOrResetVelocityTracker();
			velocityTracker.addMovement(event);
			start = event.getRawX();
			pre = start;
			break;
		case MotionEvent.ACTION_MOVE:
			velocityTracker.addMovement(event);
			if (Math.abs(start - event.getRawX()) > 100) {
				getParent().requestDisallowInterceptTouchEvent(true);
			}
			scrollBy((int) (pre - event.getRawX()), 0);
			pre = event.getRawX();
			break;
		case MotionEvent.ACTION_UP:
			velocityTracker.addMovement(event);
			velocityTracker.computeCurrentVelocity(1000, ViewConfiguration.get(getContext()).getScaledMaximumFlingVelocity());
			mVelocity = (int) velocityTracker.getXVelocity();
			// Log.v(VIEW_LOG_TAG, "v = " + mVelocity);
			postDelayed(goOnDraw, 50);
			break;
		case MotionEvent.ACTION_CANCEL:
			endScorll();
			break;
		default:
			break;
		}
		return true;
	}

	protected int mVelocity, drawCount;

	private Runnable goOnDraw = new Runnable() {
		private int MAX_REDRAW_COUNT = 10;

		@Override
		public void run() {
			if (drawCount < MAX_REDRAW_COUNT && Math.abs(mVelocity) > 5000) {
				int dis = (int) (mVelocity * 0.05 / MAX_REDRAW_COUNT * (MAX_REDRAW_COUNT - drawCount + 0.5));
				scrollBy(-dis, 0);
				drawCount++;
				postDelayed(goOnDraw, 20);
			} else {
				endScorll();
			}
		}
	};

	/**
	 * 回收速度记录，父类恢复可拦截.调用scrollTo(x , y)使滚动的最近线位置;
	 * 
	 */
	private void endScorll() {
		int scroll = getScrollX();
		int left = (scroll % tickMarkStep);
		scroll += left > tickMarkStep * 0.5f ? tickMarkStep - left : -left;

		scroll = getRealScroll(scroll);
		scrollTo(scroll, 0);
		recycleVelocityTracker();
		getParent().requestDisallowInterceptTouchEvent(false);
	}

	/**
	 * scroll不能小于0 ， 不能大于最大数值
	 * 
	 * @param scrollX
	 * @return
	 */
	protected int getRealScroll(int scroll) {
		int maxOffset = (((mMaxData - mMinData) / mDataStep) * mDevideCount * 2) * tickMarkStep;
		return Math.min(maxOffset, Math.max(0, scroll));
	}

	protected void recycleVelocityTracker() {
		if (velocityTracker != null) {
			velocityTracker.recycle();
			velocityTracker = null;
		}
	}

	protected void initOrResetVelocityTracker() {
		if (velocityTracker == null) {
			velocityTracker = VelocityTracker.obtain();
		} else {
			velocityTracker.clear();
		}
	}

}
