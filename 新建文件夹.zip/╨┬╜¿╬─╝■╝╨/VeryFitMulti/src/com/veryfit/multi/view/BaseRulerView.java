package com.veryfit.multi.view;

import java.util.Arrays;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Path;
import android.graphics.Shader.TileMode;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ViewConfiguration;

import com.project.library.util.DebugLog;
import com.veryfit.multi.util.ViewUtil;

public class BaseRulerView extends HorizonRulerView {

	private int defaultRulerData;
	private int defaultRulerScrollX;
	private boolean isCalculateFinish = false;

	public BaseRulerView(Context context) {
		super(context);
		init();
	}

	public BaseRulerView(Context context, AttributeSet attrs) {
		super(context, attrs);
		init();
	}

	public BaseRulerView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init();
	}

	private void init() {
		paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextAlign(Align.CENTER);
		paint.setStrokeWidth(LINE_WIDTH);
	}

	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		super.onScrollChanged(l, t, oldl, oldt);
		data = getDataByOffset(-getRealScroll(getScrollY()));
		Log.d(VIEW_LOG_TAG, "data = " + Arrays.toString(data));
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		this.w = w - getPaddingLeft() - getPaddingRight();
		this.h = h - getPaddingBottom() - getPaddingTop();
		calulateData();
		isCalculateFinish = true;
		setData(defaultRulerData);
	}

	public void calulateData() {
		mSpaceSize = (this.h - (mDevideCount * 2 * 4 + 1) * LINE_WIDTH) / (mDevideCount * 2 * 4 - 1);
		mLineLength = this.w * 0.25f;
		defaultOffset = h / 2 - LINE_WIDTH / 2;

		tickMarkStep = mSpaceSize + LINE_WIDTH;

		maxLineCount = (mMaxData - mMinData) / mDataStep * mDevideCount * 2 + 1;
		textSize = mLineLength * 0.15f;
		paint.setTextSize(textSize);
		data = getDataByOffset(-getRealScroll(getScrollY()));
		Log.d(VIEW_LOG_TAG, "calulateData  data = " + Arrays.toString(data));
	}

	public void initData(String[] unit, int maxData, int minData, int devideCount, int dataStep, int tickDataStep) {
		this.mUnits = unit;
		this.mMaxData = maxData;
		this.mMinData = minData;
		this.mDevideCount = devideCount;
		this.mDataStep = dataStep;
		this.tickMarkDataStep = tickDataStep;
		calulateData();
		invalidate();
	}

	public void setData(int index) {
		this.defaultRulerData = index;
		if (isCalculateFinish) {
			this.defaultRulerScrollX = index * tickMarkStep;
			scrollTo(0, -defaultRulerScrollX);
		}
		// this.defaultRulerData=data;
		// int dataOffset=defaultRulerData-(mMinData * (tickMarkDataStep *
		// (mDevideCount *2)));
		// if(dataOffset<0){
		// dataOffset=0;
		// }
		// int steps=dataOffset/tickMarkDataStep;
		// // /mDataStep*(mDevideCount*2);
		// // int steps = dataOffset % ( tickMarkDataStep * (mDevideCount *2))
		// this.defaultRulerScrollX = steps*tickMarkStep;
		// DebugLog.d("defaultRulerScrollX = " + defaultRulerScrollX);
		// if(isCalculateFinish){
		// scrollTo(0,-defaultRulerScrollX);
		// }
	}

	@Override
	protected void onDraw(Canvas canvas) {
		drawTickMark(canvas);
		drawShadow(canvas);
		drawLabel(canvas);
	}

	public int getUnitSize() {
		return mUnits.length;
	}

	private void drawLabel(Canvas canvas) {
		paint.setColor(mLightColor);
		paint.setTextAlign(Align.CENTER);
		int y = defaultOffset + getScrollY();
		float x = this.w - mLineLength * 1.8f;
		canvas.drawLine(x, y, this.w, y, paint);
		// 画小三角
		float triangleSize = mLineLength * 0.1f;
		Path path = new Path();
		path.moveTo(x, y + triangleSize);
		path.lineTo(x - triangleSize * 1.8f, y);
		path.lineTo(x, y - triangleSize);
		path.close();
		canvas.drawPath(path, paint);
		// 画数值
		x -= mLineLength * 0.3f;

		// 初始化字体大小
		float textSizeBig = textSize * 1.8f;
		float textSizeSmall = textSize * 1.3f;
		float padding = mLineLength * 0.1f;
		if (mUnits.length == 1) {
			// 找出标题、单位、数字中的最大宽度，以便确定他们的水平居中线
			paint.setTextSize(textSizeSmall);
			float tittleWid = ViewUtil.getTextRectWidth(paint, title);
			float unitWid = ViewUtil.getTextRectWidth(paint, mUnits[0]);
			paint.setTextSize(textSizeBig);
			float dataWid = ViewUtil.getTextRectWidth(paint, (data[0] + data[1]) + "");
			float maxWid = Math.max(unitWid, Math.max(tittleWid, dataWid));
			// 中心线位置
			x -= maxWid / 2;
			y -= (paint.ascent() + paint.descent()) / 2;
			canvas.drawText((data[0] + data[1]) + "", x, y, paint);
			float dataHeight = ViewUtil.getTextHeight(paint);

			paint.setTextSize(textSizeSmall);
			canvas.drawText(mUnits[0], x, y + dataHeight / 2 + padding, paint);
			canvas.drawText(title, x, y - dataHeight / 2 - padding + (paint.ascent() + paint.descent()), paint);
		} else if (mUnits.length == 2) {
			// 计算文字宽度,因为需要文字居中，文字大小不一，故依依算出每个宽度
			// 数字与单位的间距

			// 第一个数字宽度x1 和 第二个数字宽度x3
			paint.setTextSize(textSizeBig);
			float x1 = ViewUtil.getTextRectWidth(paint, data[0] + "");
			float x3 = ViewUtil.getTextRectWidth(paint, data[1] + "");
			// 第一个单位的宽度x2 和 第二个单位宽度x4
			paint.setTextSize(textSizeSmall);
			float x2 = ViewUtil.getTextRectWidth(paint, mUnits[0]);
			float x4 = ViewUtil.getTextRectWidth(paint, mUnits[1]);
			float totalX = x1 + padding + x2 + padding + x3 + padding + x4;

			paint.setTextAlign(Align.LEFT);
			paint.setTextSize(textSizeBig);

			y -= (paint.descent() + paint.ascent()) / 2;
			canvas.drawText(data[0] + "", x - totalX, y, paint);
			canvas.drawText(data[1] + "", x - totalX + x1 + padding + x2 + padding, y, paint);

			paint.setTextSize(textSizeSmall);
			canvas.drawText(mUnits[0], x - totalX + x1 + padding, y, paint);
			canvas.drawText(mUnits[1], x - totalX + x1 + padding + x2 + padding + x3 + padding, y, paint);

			paint.setTextAlign(Align.CENTER);
			paint.setTextSize(textSizeBig);
			y -= ViewUtil.getTextHeight(paint);
			paint.setTextSize(textSizeSmall);
			canvas.drawText(title, x - totalX / 2, y, paint);
		}
	}

	private void drawShadow(Canvas canvas) {
		int y = getScrollY();
		paint.setShader(new LinearGradient(0, y, 0, getHeight() / 3 + y, mShadowColor, 0x00000000, TileMode.CLAMP));
		canvas.drawRect(0, y, getWidth(), getHeight() / 3 + y, paint);
		paint.setShader(new LinearGradient(0, getHeight() / 3 * 2 + y, 0, getHeight() + y, 0x00000000, mShadowColor, TileMode.CLAMP));
		canvas.drawRect(0, getHeight() / 3 * 2 + y, getWidth(), getHeight() + y, paint);
		paint.setShader(null);
	}

	private void drawTickMark(Canvas canvas) {
		// 计算满屏时，可见刻度线的条数。满屏时有4个大格子，每个大格子有2个中等格子，每个中等格子中有mDevideCount个小格子。线的条数比格子多1
		int lineCount = mDevideCount * 2 * 4 + 1;
		int scrollY = getScrollY();
		// DebugLog.d("scrollY = " + scrollY + "*** defaultOffset = " +
		// defaultOffset + "***h / 2 = " + (h/2) + "lineW = " + LINE_WIDTH);
		canvas.save();
		// 默认的原点在view的中心位置，即defaultOffset,当view移动时，就将原点移动到scrollX
		canvas.translate(0, defaultOffset - scrollY);
		paint.setColor(mRulerColor);
		paint.setTextSize(textSize);
		paint.setTextAlign(Align.RIGHT);
		float yTextOffset = -(paint.ascent() + paint.descent()) / 2;
		// 求出刻度线index的偏移值
		// ,如果还未满屏，那第一条线的index始终为0，如果已经满屏，那么出屏的距离除以每个线距+1即为第一个可见线的index
		int i = -scrollY < defaultOffset ? 0 : (-scrollY - defaultOffset) / tickMarkStep + 2;
		// 可见线的最大index
		lineCount += i;
		// 刻度线最大条数不能大于需要显示的总刻度条数
		lineCount = Math.min(lineCount, maxLineCount);
		for (; i < lineCount; i++) {
			int y = -i * tickMarkStep + scrollY;// +scroll将坐标移到第一个可见线处
			float yScale = 0;
			if (i % mDevideCount == 0) {
				if (i / mDevideCount % 2 == 0) {// 整数刻度，加上label
					yScale = 1.0f;
					// 文字竖向位置用mLineLength作参考
					// 获取该刻度线所对应的数值，x-scroll是该刻度线的x坐标
					canvas.drawText(getDataByOffset(-y + scrollY)[0] + "", this.w - mLineLength * 1.1f, y + yTextOffset, paint);
				} else {
					yScale = 0.6f;
				}
			} else {
				yScale = 0.4f;
			}
			canvas.drawLine(this.w, y, this.w - mLineLength * yScale, y, paint);
		}
		canvas.restore();
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		switch (event.getAction() & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_DOWN:
			removeCallbacks(goOnDraw);
			drawCount = 1;
			initOrResetVelocityTracker();
			velocityTracker.addMovement(event);
			start = event.getRawY();
			pre = start;
			break;
		case MotionEvent.ACTION_MOVE:
			velocityTracker.addMovement(event);
			if (Math.abs(start - event.getRawY()) > 100) {
				getParent().requestDisallowInterceptTouchEvent(true);
			}
			scrollBy(0, (int) (pre - event.getRawY()));
			pre = event.getRawY();
			break;
		case MotionEvent.ACTION_UP:
			velocityTracker.addMovement(event);
			velocityTracker.computeCurrentVelocity(1000, ViewConfiguration.get(getContext()).getScaledMaximumFlingVelocity());
			mVelocity = (int) velocityTracker.getYVelocity();
			// Log.v(VIEW_LOG_TAG, "v = " + mVelocity);
			postDelayed(goOnDraw, 50);
			break;
		case MotionEvent.ACTION_CANCEL:
			endScorll();
			break;
		default:
			break;
		}
		return true;
	}

	public int[] getData() {
		DebugLog.d("sss" + Arrays.toString(data));
		return data;
	}

	private Runnable goOnDraw = new Runnable() {
		private int MAX_REDRAW_COUNT = 10;

		@Override
		public void run() {
			if (drawCount < MAX_REDRAW_COUNT && Math.abs(mVelocity) > 5000) {
				int dis = (int) (mVelocity * 0.05 / MAX_REDRAW_COUNT * (MAX_REDRAW_COUNT - drawCount + 0.5));
				scrollBy(0, -dis);
				drawCount++;
				postDelayed(goOnDraw, 200 / MAX_REDRAW_COUNT);
			} else {
				endScorll();
			}
		}
	};

	/**
	 * 回收速度记录，父类恢复可拦截.调用scrollTo(x , y)使滚动的最近线位置;
	 * 
	 */
	private void endScorll() {
		int scroll = getScrollY();
		int left = Math.abs(scroll % tickMarkStep);
		scroll -= left > tickMarkStep * 0.5f ? tickMarkStep - left : -left;

		scroll = getRealScroll(scroll);
		scrollTo(0, scroll);

		recycleVelocityTracker();
		getParent().requestDisallowInterceptTouchEvent(false);
	}

	protected int getRealScroll(int scroll) {
		int maxOffset = (((mMaxData - mMinData) / mDataStep) * mDevideCount * 2) * tickMarkStep;
		return Math.max(-maxOffset, Math.min(0, scroll));
	}

}
