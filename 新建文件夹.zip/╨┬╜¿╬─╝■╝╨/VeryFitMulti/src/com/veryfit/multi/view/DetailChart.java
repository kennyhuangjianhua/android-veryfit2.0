package com.veryfit.multi.view;

import java.util.ArrayList;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.util.Constant;
import com.veryfit.multi.util.TempUtil;
import com.veryfit.multi.util.Util;
import com.veryfit.multi.util.ViewUtil;
import com.veryfit.multi.view.DetailChart.PageData.LineData;
import com.veryfit.multi.view.DetailChart.PageData.LineData.PointModel;

//import com.aiju.hata.util.TempUtil;
//import com.aiju.hata.util.Util1;
//import com.aiju.hata.util.ViewUtil;
//import com.aiju.hata.view.DetailChart.PageData.LineData;
//import com.aiju.hata.view.DetailChart.PageData.LineData.PointModel;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.NinePatchDrawable;
import android.text.Layout.Alignment;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class DetailChart extends View {
//	public static final int TYPE_WEEK = 0;
//
//	public static final int TYPE_MONRH = 1;
//
//	public static final int TYPE_YEAR = 2;

	public static final int POPUP_LEFT = 1;

	public static final int POPUP_CENTER = 0;

	public static final int POPUP_RIGHT = -1;

	/** 点被点击后，出现的label背景 */
	private NinePatchDrawable popup, popupLeft, popupRight;

	private Paint linePaint, gridPaint;

	private TextPaint textPaint;
	/** 目标的奖杯图片 */
	private Bitmap cup;

	private int textSize;

	private PageData pageData;

	/**
	 * 图表的y向控制点 依次是标题，图例，图表的上限，下限，xLable的y坐标
	 */
	private float[] ys = new float[5];

	/**
	 * 标题到图例的距离
	 */
	private int padding;

	// private GraphicSymbol[] symbols;

	private int textColor;
	/**
	 * 第一条数据的缩进尺寸
	 */
	private int xOffset;

	private int pointRadius;

	private float yScale;

	/** 点中最大值数据 ,用来计算yScale */
	private int maxValue;
	/** 点中最小值数据 ,用来计算yScale */
//	private int minValue;

	// private int goal;

	private int w, h;
	/**
	 * 坐标轴与格子线的颜色，带点透明
	 */
	private int gridColor;

	/** 如果是年数据，就不能绘制目标 */
	private int type;

	private Path path;
	/** 被选中的点在line中的index */
	private int selectPointIndex = 5;
	/** 当点被点击时，出现的label的rect */
	private Rect labelRect, popupRect;
	/** popup 4个方向的padding , 三种popup的padding都是一样的 */
	private Rect popupPadding;

	private StaticLayout valueLayout;

	/** 点到点的距离 这个图中，每条线的点到点距离都是一样的，故提出来 */
	private float pointDis;
	/** 下面的6个数据 ， data0是第一行 */
//	private DataShowView data0, data1;

	public DetailChart(Context context, AttributeSet attrs) {
		super(context, attrs);

		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DetailChart);

		// 需要外界或者XML传进来的
		pointRadius = a.getDimensionPixelSize(R.styleable.DetailChart_pointRadius, 8);
		xOffset = a.getDimensionPixelSize(R.styleable.DetailChart_xOffset, 40);
		textSize = a.getDimensionPixelSize(R.styleable.DetailChart_android_textSize, 24);
		textColor = a.getColor(R.styleable.DetailChart_android_textColor, 0xFFFFFFFF);
		gridColor = a.getColor(R.styleable.DetailChart_gridColor, 0x22ffffff);
		padding = a.getDimensionPixelSize(R.styleable.DetailChart_space, 15);
		float lintWidth = a.getDimension(R.styleable.DetailChart_lineWidth, 2);
		a.recycle();

		// setPageData(TempUtil.getDetailChartPageData(0, type));
		cup = BitmapFactory.decodeResource(getResources(), R.drawable.cup);
		popupLeft = (NinePatchDrawable) getResources().getDrawable(R.drawable.popup_left);
		popupRight = (NinePatchDrawable) getResources().getDrawable(R.drawable.popup_right);
		popup = (NinePatchDrawable) getResources().getDrawable(R.drawable.popup);

		linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		linePaint.setStrokeWidth(lintWidth);

		gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		gridPaint.setColor(gridColor);

		textPaint = new TextPaint();
		textPaint.setTextSize(textSize);
		textPaint.setColor(textColor);
		textPaint.setTextAlign(Align.CENTER);

		path = new Path();
		labelRect = new Rect();
		popupRect = new Rect();
		popupPadding = new Rect();
	}

	public void setPageData(PageData data) {
		this.pageData = data;
		if (w != 0) {
			calculate();
			// initPageData();
			// //初始化转换比
			// initYScale();
			// // 更新渐变色
			// updateGradients();
			invalidate();
		}
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);

		this.w = w;
		this.h = h;

		calculate();
	}

	private void calculate() {
		initPageData();

		calculateY();

		initYScale();
		// 更新渐变色
		updateGradients();
	}

	private void initPageData() {
		if (pageData != null) {
			// 计算每条线中点到点的距离
			pageData.initData(w - 2 * xOffset);
			pointDis = pageData.lines[0].width;
			// 更新最大值和最小值
			initPointFeature();
		}
	}

	/**
	 * 计算y方向控制点的坐标
	 * 
	 * @param h
	 */
	private void calculateY() {
		float textH = ViewUtil.getTextHeight(textPaint);
		float yOffset = (textPaint.ascent() + textPaint.descent()) / 2;
		ys[0] = getPaddingTop() + textH + yOffset;// 标题位置

		ys[1] = ys[0] + padding + textH + yOffset;// 图例位置

		// 图例到y轴上限的距离要能放的下一个popup
		// 计算popup的尺寸

		if (pageData != null) {
			// 获取到最大点所在的线
			PointModel point = initPointFeature();
			calculateValueRect(point);
			// 此处只需计算高度，不涉及偏移，故传null
			calculatePopup();
		}

		ys[2] = ys[1] + padding + popupRect.height() + 4.5f * pointRadius;// y轴上限

		ys[3] = h - textH - padding - getPaddingBottom();// y轴下限

		ys[4] = ys[3] + padding + textH + yOffset;// xLabel位置

	}

	/**
	 * 计算出这个点对应的文字占据的大小
	 * 
	 * rect使用时，需要偏移
	 * 
	 * @param point
	 *            选中的点
	 */
	private void calculateValueRect(PointModel point) {
		// PointModel point = line.datas.get(selectPointIndex);
		textPaint.setTextAlign(Align.CENTER);
		int textW = (int) (ViewUtil.getTextRectWidth(textPaint, point.getMaxLengthLabel()) * 1.2f);// * 1.2f
		valueLayout = new StaticLayout(point.getPopupStr(), textPaint, textW, Alignment.ALIGN_NORMAL, 1.2f, 0, false);
		// 此处偏移时水平以中心为参考，竖直以bottom为参考,offset(pointX , pointY + padding)
		// padding=pointY到popup.bottom的距离 + popuppaddingBottom
		labelRect.top = -valueLayout.getHeight();
		labelRect.bottom = 0;
		labelRect.left = -textW / 2;
		labelRect.right = textW / 2;
	}

	/**
	 * 计算出这个点对应的popup的大小
	 * 
	 * rect使用时，需要偏移
	 * 
	 * @param line
	 *            选中的点所在的线
	 * @return popup的种类，0-->left 1-->center , 2-->right
	 */
	private int calculatePopup() {
		// 先以中心popup计算，如果不符合，就需要重新计算
		popup.getPadding(popupPadding);
		popupRect.top = -(popupPadding.bottom + popupPadding.top + labelRect.height());
		popupRect.bottom = 0;
		popupRect.left = labelRect.left - popupPadding.left;
		popupRect.right = labelRect.right + popupPadding.right;
		// 如果popup的右边超出,重新计算
		if (xOffset + selectPointIndex * pointDis + popupRect.right > w) {
			popupRight.getPadding(popupPadding);
			popupRect.top = -(popupPadding.bottom + popupPadding.top + labelRect.height());
			popupRect.bottom = 0;
			popupRect.left = -(popupPadding.left + popupPadding.right + labelRect.width());
			popupRect.right = 0;
			return POPUP_RIGHT;
		} else if (Math.abs(popupRect.left) > xOffset + selectPointIndex * pointDis) {
			// 如果左边出界
			popupLeft.getPadding(popupPadding);
			popupRect.top = -(popupPadding.bottom + popupPadding.top + labelRect.height());
			popupRect.bottom = 0;
			popupRect.left = 0;
			popupRect.right = popupPadding.left + popupPadding.right + labelRect.width();
			return POPUP_LEFT;
		}
		return POPUP_CENTER;
	}

	/**
	 * 会初始化点中的最大最小值，选中点的index（最大值）
	 * 
	 * @return 返回最大点所在的线
	 */
	private PointModel initPointFeature() {
		int[][] maxValueIndex = pageData.getMaxDataIndexOfLine();
		PointModel maxPoint = pageData.lines[maxValueIndex[0][0]].datas.get(maxValueIndex[0][1]);
		selectPointIndex = maxValueIndex[0][1];
		maxValue = maxPoint.data;

//		PointModel minPoint = pageData.lines[maxValueIndex[1][0]].datas.get(maxValueIndex[1][1]);
//		minValue = minPoint.data;
		return maxPoint;
	}

	// /**
	// * 设置图例，并更新线的渐变
	// * @param graphicSymbols
	// */
	// private void setGraphicSymbols(GraphicSymbol... graphicSymbols){
	// if(graphicSymbols == null || graphicSymbols.length !=
	// pageData.lines.length){
	// Log.w("View: DetailChart", "warning:" +
	// "Invalid arguments , graphicSymbols must not be null " +
	// "and graphicSymbols.length must equal with pageData.lines.length." +
	// "this symbols will use the default");
	// return;
	// }
	// this.symbols = graphicSymbols;
	// for (GraphicSymbol symbol : graphicSymbols) {
	// symbol.gradient = new LinearGradient(0, ys[2],0 , ys[3], symbol.color,
	// 0x00000000, TileMode.CLAMP);
	// }
	// }
	//

	/**
	 * 更新线的渐变
	 */
	private void updateGradients() {
		if (ys[2] == 0 && ys[3] == 0) {
			return;
		}
		for (LineData line : pageData.lines) {
			int endColor = line.color & 0x44FFFFFF;
			line.gradient = new LinearGradient(0, ys[2], 0, ys[3], line.color, endColor, TileMode.CLAMP);
		}
	}

	private void initYScale() {
		float maxValue = pageData.goal * 1.2f;
		if (pageData != null) {
			maxValue = Math.max(maxValue, this.maxValue);
		}
		Log.e(VIEW_LOG_TAG, "maxValue = " + maxValue);
		yScale = (ys[3] - ys[2]) / maxValue;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		// 绘制x轴
		canvas.drawLine(0, ys[3], w, ys[3], gridPaint);

		drawPageData(canvas);

	}

	private void drawGoal(Canvas canvas) {
		// 绘制目标
		float x = this.padding;
		float y = ys[3] - pageData.goal * yScale;
		textPaint.setPathEffect(new DashPathEffect(new float[] { 5, 5, 5, 5 }, 1));
		textPaint.setStyle(Style.STROKE);
		Path path = new Path();
		path.moveTo(0, y);
		path.rLineTo(w, 0);
		canvas.drawPath(path, textPaint);
		textPaint.setPathEffect(null);
		textPaint.setStyle(Style.FILL);
		y -= cup.getHeight() + padding;
		canvas.drawBitmap(cup, x, y, null);

		// 绘制目标文字
		textPaint.setTextAlign(Align.LEFT);
		x += cup.getWidth() + padding;
		y += cup.getHeight() / 2 - (textPaint.ascent() + textPaint.descent()) / 2;
		canvas.drawText(pageData.goalString, x, y, textPaint);

	}

	private void drawPageData(Canvas canvas) {
		// 绘制标题
		textPaint.setTextAlign(Align.CENTER);
		canvas.drawText(pageData.tittle, w / 2, ys[0], textPaint);
		drawLines(canvas);
	}

	private void drawLines(Canvas canvas) {

		// 绘制图例时需要找到图例说明文字的竖向中心
		float yOffset = (textPaint.ascent() + textPaint.descent()) / 2;
		// 绘制过程中，将要绘制的图例的最右端边界
		float symbolX = w - padding;
		// 图例到图例说明的间距
		float padding = pointRadius;
		
		float focusX = 0 , focusY = 0;
		
		PointModel focusPoint = null;
		
		for (int i = 0; i < pageData.lines.length; i++) {
			LineData line = pageData.lines[i];
			linePaint.setColor(line.color);
			// 绘制点的时候填充
			linePaint.setStyle(Style.FILL);

			// 如果折线数目大于1 ，就 需要绘制图例
			if (pageData.lines.length > 1) {
				textPaint.setTextAlign(Align.RIGHT);
				canvas.drawText(line.name, symbolX, ys[1], textPaint);
				symbolX -= padding + pointRadius + ViewUtil.getTextRectWidth(textPaint, line.name);
				canvas.drawCircle(symbolX, ys[1] + yOffset, pointRadius, linePaint);
				symbolX -= pointRadius + 2 * padding;
			}

			// 绘制数据
			int lineSize = line.datas.size();
			path.reset();
			/*
			 * 此处设置路径的起始点位置，后面如果想加入两页连接效果，可将起始点设置为前一页的最后一个点
			 * 两页连接需注意：如果两页的最大值不同，可能会导致两页连接的线出现断层，暂时解决办法如下：
			 * 思路一：最大值，即yMaxData不根据数据数据来动态获取，固定设置一个不可能超过的数值，虽然实现简单，但点将会被压得很矮，不好看
			 * 思路二：起始点，即前一页的最后一个值的y坐标根据前一页的yMaxData计算 起始点代码： path.moveTo(xOffset
			 * , ys[3]);
			 */
			// 每个点中心位置的x向距离：（总宽度 - 两边的空白部分）/ （点的数目 - 1）
			// line.width = (w - xOffset * 2) * 1f / (lineSize - 1);
			// 第一个点的触控区域的右边界，以后的每个点的右边界加上步长 line.width
			// float pointRight = xOffset + line.width / 2;

			for (int j = 0; j < lineSize; j++) {
				PointModel point = line.datas.get(j);
				float x = xOffset + j * line.width;
				float y = ys[3] - point.data * yScale;
				// 如果上面已经设置了path的起始点，就不用moveTo了
				if (j == 0) {
					path.moveTo(x, y);
				} else {
					path.lineTo(x, y);
				}
				// canvas.save();
				// canvas.translate(x, 0);
				// Log.v(VIEW_LOG_TAG, "x = " + (xOffset + j * (line.width + 1))
				// + " ****w = " + w);
				// 绘制点
				canvas.drawCircle(x, y, pointRadius, linePaint);
				// 绘制网格线
				canvas.drawLine(x, ys[2], x, ys[3], gridPaint);
				// 如果是第一条线，就需要1.绘制下方的文字2.点中效果
				if (i == 0) {
					textPaint.setTextAlign(Align.CENTER);
					canvas.drawText(point.dataName, x, ys[4], textPaint);
					if (selectPointIndex == j) {
						focusX = x;
						focusY = y;
						focusPoint = point;
//						drawFoucsPoint(canvas, x, y, point);
					}
				}
				// canvas.restore();
			}
			// 绘制折线
			// 先给折线绘制个描边
			linePaint.setStyle(Style.STROKE);
			canvas.drawPath(path, linePaint);
			// 填充折线下方

			// 闭合该path
			path.lineTo(w - xOffset, ys[3]);
			path.lineTo(xOffset, ys[3]);

			// 绘制下方的渐变
			linePaint.setAlpha(100);
			linePaint.setStyle(Style.FILL_AND_STROKE);// 为什么这个不描边，所以先做了次描边
			linePaint.setShader(line.gradient);
			canvas.drawPath(path, linePaint);
			linePaint.setShader(null);
			linePaint.setAlpha(255);

		}
		

		if (type != Constant.DETAIL_CHART_TYPE_YEAR) {
			drawGoal(canvas);
		}
		DebugLog.d("type = " + type);
		
		drawFoucsPoint(canvas, focusX, focusY, focusPoint);

	}

	/**
	 * 绘制被选中的点
	 * 
	 * @param canvas
	 * @param x
	 * @param y
	 */
	private void drawFoucsPoint(Canvas canvas, float x, float y, PointModel point) {
		// 绘制选中点圆圈
		linePaint.setStyle(Style.STROKE);
		canvas.drawCircle(x, y, pointRadius * 2.5f, linePaint);
		linePaint.setStyle(Style.FILL);

		calculateValueRect(point);
		// 根据类型确定文字的水平偏移距离和popup的类型
		int type = calculatePopup();
		int xOff = 0;
		NinePatchDrawable p = popup;
		switch (type) {
		case POPUP_LEFT:
			xOff = type * (labelRect.width() / 2) + popupPadding.left;
			p = popupLeft;
			break;
		case POPUP_CENTER:
			break;
		case POPUP_RIGHT:
			xOff = type * (labelRect.width() / 2) - popupPadding.right;
			p = popupRight;
			break;
		default:
			break;
		}

		// 定义点中心位置到popup的底部距离
		float drawablePadding = pointRadius * 4.5f;
		canvas.save();
		canvas.translate(x + xOff, y - drawablePadding - popupPadding.bottom - labelRect.height());
		valueLayout.draw(canvas);
		canvas.restore();
		popupRect.offset((int) x, (int) (y - drawablePadding));
		p.setBounds(popupRect);
		p.draw(canvas);

	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		super.onTouchEvent(event);
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			selectPoint(event.getX());
			break;

		default:
			break;
		}
		return false;
	}

	private void selectPoint(float x) {
		int pointX = (int) (x - xOffset - pointDis / 2);
		selectPointIndex = pointX < 0 ? 0 : pointX / (int) pointDis + 1;
		// 如果右边的大于一个pointDis，就会出现越界，所以调整下
		selectPointIndex = Math.min(selectPointIndex, pageData.lines[0].datas.size() - 1);
		calculateValueRect(pageData.lines[0].datas.get(selectPointIndex));
		calculatePopup();
		invalidate();
	}
	
	public void setType(int type){
		this.type = type;
	}

	/**
	 * 折线的页数据模型，之中包含一个折线的数据模型,线数据中包含一个点数据 数据层次：页-->线-->点
	 * 
	 * @author Reb
	 * 
	 */
	public static class PageData {
//		private static final int[] DEFAULT_SYMBOLS_COLOR = { Color.BLUE, Color.RED, Color.YELLOW, Color.LTGRAY };

		/** 页标题 ， 如"6/1-6/7" */
		public String tittle;
		/** 线上点的数据，图表中可能有多条线，故用数组模型 */
		public LineData[] lines;

		/**
		 * 目标文字， 根据07/21赵兹江描述：有历史目标一说，故目标为页数据属性。条件如下：
		 * 1.如果当前页中点的数据对应有多个目标，以最新目标为准 2.年的图表中，因为是月平均数据，就不绘制目标线
		 */
		public String goalString;

		public int goal;

		/** 底下那6个展示数据 */
		public String[] dataShow0 = new String[6];

		/** 获取这一页中的最大数据 */
		public int getMaxData() {
			int max = 0;
			if (lines != null) {
				for (LineData lineData : lines) {
					max = Math.max(max, lineData.getMaxData());
				}
			}
			return max;
		}

		public void initData(int lineWidth) {
			if (lines != null) {
				// 初始化每条线中每个点中心位置的x向距离：线总长度 / （点的数目 - 1）
				for (LineData lineData : lines) {
					lineData.width = lineWidth * 1f / (lineData.datas.size() - 1);
				}
			}
		}

		/**
		 * 获取所有线中的最大值index ,所有线中最小值index
		 * indexs[0]为最大值所在的线的位置indexs[0][0]和点在线中的index[0][1] indexs[1]为最小值的
		 */
		public int[][] getMaxDataIndexOfLine() {
			int[][] indexs = new int[2][2];
			int max = 0, min = Integer.MAX_VALUE;
			if (lines != null) {
				for (int i = 0; i < lines.length; i++) {
					LineData line = lines[i];
					int pointSize = line.datas.size();
					for (int j = 0; j < pointSize; j++) {
						PointModel p = line.datas.get(j);
						if (p.data > max) {
							max = p.data;
							indexs[0][0] = i;
							indexs[0][1] = j;
						}
						if (p.data < min) {
							min = p.data;
							indexs[1][0] = i;
							indexs[1][1] = j;
						}
					}
				}
			}
			return indexs;
		}

		/** 折线的数据模型 */
		public static class LineData {

			/** 每个点的模型 */
			public ArrayList<PointModel> datas;

			/** 每条数据之间的宽度 */
			public float width;

			/** 线的颜色 , 用来绘制图例和线 */
			public int color;
			/** 线的名称 , 用来绘制图例 */
			public String name;
			/** 线下方的渐变效果 */
			public LinearGradient gradient;

			public LineData() {
				super();
			}

			/** 获取这条线中的最大值，用于计算图表可显示的最大值 */
			public int getMaxData() {
				int maxData = 0;
				if (datas != null) {
					for (PointModel point : datas) {
						maxData = Math.max(point.data, maxData);
					}
				}
				return maxData;
			}

			/** 点模型 */
			public static class PointModel {
				/** 点的数据（对应点的高度） */
				public int data;
				/** 点的名称，点对应x轴的文字 .注意：如果一张图里有多条线，只有第一条线的dataName才会被绘制到view中 */
				public String dataName = "";

				// /** 触控区域 */
				// public RectF rectF;
				/**
				 * 点击后出现的popup内容 一行一个字符串，如：0.总睡眠：xxhxxm 1.浅睡:xxhxxm 2.深睡:xxhxxm
				 */
				public String[] dataLabel;

				/**
				 * 获取到最长的字符串，用来计算popup的宽度
				 */
				public String getMaxLengthLabel() {
					return Util.getMaxLenthString(dataLabel);
				}

				/**
				 * 获取有换行的popupString
				 * 
				 * @return 如果label == null ，返回null
				 */
				public String getPopupStr() {
					if (dataLabel != null) {
						StringBuilder sb = new StringBuilder();
						for (int i = 0; i < dataLabel.length; i++) {
							sb.append(dataLabel[i]);
							if (i != dataLabel.length - 1) {
								sb.append("\n");
							}
						}
						return sb.toString();
					}
					return null;
				}
			}
		}
	}

	// /**
	// * 图例模型
	// * @author Reb
	// *
	// */
	// public class GraphicSymbol{
	// /** 图例说明文字*/
	// public String name;
	// /** 图例颜色*/
	// public int color;
	//
	// public LinearGradient gradient;
	//
	// public GraphicSymbol(String name, int color) {
	// super();
	// this.name = name;
	// this.color = color;
	// }
	//
	//
	// }

}
