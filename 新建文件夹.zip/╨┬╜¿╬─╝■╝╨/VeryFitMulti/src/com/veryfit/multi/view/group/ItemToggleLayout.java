package com.veryfit.multi.view.group;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.view.CustomToggleButton;
import com.veryfit.multi.view.CustomToggleButton.OnSwitchListener;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class ItemToggleLayout extends ItemLableValue {

	private TextView lableView;

	private CustomToggleButton toggleBtn;

	private ProgressBar progressBar;

	private OnToggleListener onToggleListener;

	public ItemToggleLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	@Override
	protected void init(Context context, AttributeSet attrs) {
		LayoutInflater.from(context).inflate(R.layout.item_toggle_layout, this, true);
		lableView = (TextView) findViewById(R.id.lable);
		toggleBtn = (CustomToggleButton) findViewById(R.id.toggle);
		progressBar = (ProgressBar) findViewById(R.id.progress_circle);

		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ItemLableValue);
		String lable = a.getString(R.styleable.ItemLableValue_lable_text);
		hasBottomLine = a.getBoolean(R.styleable.ItemLableValue_has_bottom_line, true);
		if (hasBottomLine) {
			bottomLineColor = a.getColor(R.styleable.ItemLableValue_bottom_line_color, getResources().getColor(R.color.driver_color));
			initDraw();
		}
		a.recycle();
		lableView.setText(lable);
		// toggleBtn.setOnSwitchListener(new OnSwitchListener() {
		//
		// @Override
		// public void onSwitched(boolean isSwitchOn) {
		// DebugLog.d("onSwitch");
		// progressBar.setVisibility(View.VISIBLE);
		// if(onToggleListener != null){
		// onToggleListener.onToggle(isSwitchOn);
		// }
		// }
		// });

		progressBar.setVisibility(View.GONE);
	}

	public void showProgressBar() {
		progressBar.setVisibility(View.VISIBLE);
	}

	public void cancelProgressBar() {
		progressBar.setVisibility(View.GONE);
	}

	public boolean isOpen() {
		return toggleBtn.getSwitchState();
	}

	public void setOpen(boolean isOpen) {
		toggleBtn.setSwitchState(isOpen);
	}

	public void setOnToggleListener(OnToggleListener listener) {
		this.onToggleListener = listener;
	}

	public interface OnToggleListener {
		void onToggle(boolean isSwitchOn);
	}

}
