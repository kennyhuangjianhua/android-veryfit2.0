package com.veryfit.multi.view.group;

import java.util.List;

import com.veryfit.multi.R;
import com.veryfit.multi.view.PointLineView;
import com.veryfit.multi.view.PointLineView.onDateScrolling;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class PointLineParent extends LinearLayout {

	public static final int TYPE_SPORT = 0;

	public static final int TYPE_SLEEP = 1;

	private int type = TYPE_SPORT;

	private TextView checkedData;

	private TextView gotoTheDay;

	private PointLineView pointLineView;

	// private String stepUnit;

	private onDateScrolling selectLinstener;

	private List<Integer> datas;

	private int tempIndex;

	public PointLineParent(Context context, AttributeSet attrs) {
		super(context, attrs);
		LayoutInflater.from(context).inflate(R.layout.point_line_chart_main_page, this, true);
		setOrientation(VERTICAL);
		setBackgroundResource(R.drawable.chart_bg);
		checkedData = (TextView) findViewById(R.id.data);
		gotoTheDay = (TextView) findViewById(R.id.gotoTheDay);
		pointLineView = (PointLineView) findViewById(R.id.point);

		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.PointLine);
		int defaultColor = getResources().getColor(R.color.theme_tittle_bg);
		int textColor = a.getColor(R.styleable.PointLine_android_textColor, defaultColor);
//		float textSize = a.getDimension(R.styleable.PointLine_android_textSize, 28);
		int graphColor = a.getColor(R.styleable.PointLine_graphColor, defaultColor);
		a.recycle();

		checkedData.setTextColor(textColor);
		gotoTheDay.setTextColor(textColor);
//		checkedData.setTextSize(textSize);
//		gotoTheDay.setTextSize(textSize);
		pointLineView.setGraphColor(graphColor);
		final String stepUnit = getResources().getString(R.string.unit_step);
		final String hourUnit = getResources().getString(R.string.unit_hour_zh);
		final String minUnit = getResources().getString(R.string.unit_minute_zh);

		pointLineView.setDateScrollingLinstener(new onDateScrolling() {

			@Override
			public void onScrolling(int index) {
				if (datas != null) {
					index = Math.max(0, Math.min(datas.size() - 1, index));
					if (type == TYPE_SPORT) {
						checkedData.setText(datas.get(index) + stepUnit);
					} else if (type == TYPE_SLEEP) {
						int mins = datas.get(index);
						checkedData.setText(mins / 60 + hourUnit + (mins % 60) + minUnit);
					}
				}
				tempIndex = index;
				if (selectLinstener != null) {
					selectLinstener.onScrolling(index);
				}
			}
		});

	}

	public TextView getGoToTheDayView() {
		return gotoTheDay;
	}

	public void setOnDateScrollingLinstener(onDateScrolling linstener) {
		this.selectLinstener = linstener;
	}

	public void setShowingOffset(int index) {
		tempIndex = index;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getShowingOffset() {
		return tempIndex;
	}

	public void toggle(int dateOffset) {
		if (this.getVisibility() == View.VISIBLE) {
			// 收起动画
			setVisibility(View.GONE);
		} else {
			// 展开动画
			setVisibility(View.VISIBLE);
			pointLineView.setCurrentItem(dateOffset);
		}
	}

	public void setDatas(List<Integer> datas) {
		this.datas = datas;
		pointLineView.setDatas(datas);
	}

}
