package com.veryfit.multi.view.anim;

import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ToggleButton;

public class ExpandAnimation {
	private static int maxHeight;// 就是那个initHeight

	/** 展开伸缩动画 */
	public static Animation expand(final View v, final boolean expand, long duration) {
		final int initialHeight;
		if (expand) {
			ViewGroup v1 = (ViewGroup) v;
			if (v1.getChildCount() > 0) {
				initialHeight = maxHeight;
			} else {
				initialHeight = 0;
			}
			maxHeight = 0;
			v.getLayoutParams().height = 0;
		} else {
			maxHeight = v.getMeasuredHeight();
			initialHeight = maxHeight;
			v.getLayoutParams().height = initialHeight;
		}
		v.setVisibility(View.VISIBLE);
		Animation a = new Animation() {
			@Override
			protected void applyTransformation(float interpolatedTime, Transformation t) {
				int newHeight = 0;
				if (expand) {
					newHeight = (int) (initialHeight * interpolatedTime);
				} else {
					newHeight = (int) (initialHeight * (1 - interpolatedTime));
				}
				v.getLayoutParams().height = newHeight;
				v.requestLayout();
			}

			@Override
			public boolean willChangeBounds() {
				return true;
			}

		};
		a.setDuration(duration);
		return a;
	}

}
