package com.veryfit.multi.view.group;

import com.veryfit.multi.R;
import com.veryfit.multi.view.ValueStateTextView;
import com.veryfit.multi.vo.Alarm;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

public class WeekDayCheck extends LinearLayout {

	private int repetitions;

	private OnWeekCheckedChange onChange;

	public WeekDayCheck(Context context, AttributeSet attrs) {
		super(context, attrs);
		LayoutInflater.from(context).inflate(R.layout.weekday_check, this);

	}

	public void initAndSetDefault(int repetitions) {
		this.repetitions = repetitions;
		for (int i = 0; i < getChildCount(); i++) {
			ValueStateTextView child = (ValueStateTextView) getChildAt(i);
			child.setOpen((repetitions >> (i + 1) & 1) == 1);
			child.setOnClickListener(toggle);
			child.setTag(i + 1);
		}
	}

	private OnClickListener toggle = new OnClickListener() {

		@Override
		public void onClick(View v) {
			ValueStateTextView view = (ValueStateTextView) v;
			view.setOpen(!view.isOpen());
			repetitions = Alarm.updateRepeat(repetitions, (Integer) v.getTag(), view.isOpen());

			if (onChange != null) {
				onChange.onChange(repetitions);
			}
		}
	};

	public int getRepetition() {
		return repetitions;
	}

	public void setOnChangeLinstener(OnWeekCheckedChange onChange) {
		this.onChange = onChange;
	}

	public interface OnWeekCheckedChange {
		void onChange(int newRepetitions);
	}
}
