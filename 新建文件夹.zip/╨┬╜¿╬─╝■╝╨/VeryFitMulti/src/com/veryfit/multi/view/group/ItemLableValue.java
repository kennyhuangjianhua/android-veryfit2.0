package com.veryfit.multi.view.group;

import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.view.ValueStateTextView;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ItemLableValue extends RelativeLayout {

	private TextView lableView;

	private ValueStateTextView valueView;

	private String lable, value;

	private String targetActivty;

	protected Paint paint;

	protected boolean hasBottomLine;

	protected int bottomLineColor;

	public ItemLableValue(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public ItemLableValue(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		init(context, attrs);
	}

	protected void init(Context context, AttributeSet attrs) {
		LayoutInflater.from(context).inflate(R.layout.item_lable_value, this, true);
		lableView = (TextView) findViewById(R.id.lable);
		valueView = (ValueStateTextView) findViewById(R.id.value);

		TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ItemLableValue);

		lable = a.getString(R.styleable.ItemLableValue_lable_text);
		value = a.getString(R.styleable.ItemLableValue_value_text);
		targetActivty = a.getString(R.styleable.ItemLableValue_target_activty);
		// boolean isOpen = a.getBoolean(R.styleable.ItemLableValue_opened,
		// true);
		// boolean isEnable =
		// a.getBoolean(R.styleable.ItemLableValue_android_enabled, true);
		int valueTextColor = a.getColor(R.styleable.ItemLableValue_valueTextColor, 0);
		hasBottomLine = a.getBoolean(R.styleable.ItemLableValue_has_bottom_line, true);
		if (hasBottomLine) {
			bottomLineColor = a.getColor(R.styleable.ItemLableValue_bottom_line_color, getResources().getColor(R.color.driver_color));
			initDraw();
		}
		Drawable rightDrawable = a.getDrawable(R.styleable.ItemLableValue_right_arrow);
		a.recycle();

		if (rightDrawable != null) {
			rightDrawable.setBounds(0, 0, rightDrawable.getIntrinsicWidth(), rightDrawable.getIntrinsicHeight());
			valueView.setCompoundDrawables(null, null, rightDrawable, null);
		}
		if (valueTextColor != 0) {
			valueView.setTextColor(valueTextColor);
		}

		lableView.setText(lable);
		valueView.setText(value);

		// valueView.setOpen(isOpen);
		// valueView.setEnabled(isEnable);
		if (targetActivty != null) {
			setOnClickListener(onClick);
		}
	}

	protected void initDraw() {
		setWillNotDraw(false);
		paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setColor(bottomLineColor);
		paint.setStrokeWidth(2);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (hasBottomLine) {
			canvas.drawLine(0, getMeasuredHeight(), getMeasuredWidth(), getMeasuredHeight(), paint);
		}
	}

	private OnClickListener onClick = new OnClickListener() {

		@Override
		public void onClick(View v) {
			DebugLog.e("onClick : targetActivty = " + targetActivty);
			if (targetActivty != null && valueView.isEnabled()) {
				Intent intent = new Intent();
				intent.setClassName(getContext(), targetActivty);
				getContext().startActivity(intent);
			}
		}
	};
	
	

	public void setEnable(boolean enable) {
		valueView.setEnabled(enable);
		if(!enable){
			super.setEnabled(enable);
		}
	}

	public boolean isEnable() {
		return valueView.isEnabled();
	}

	public void setValue(String value) {
		valueView.setText(value);
	}

	public boolean isOpen() {
		return valueView.isOpen();
	}

	public void setOpen(boolean isOpen) {
		valueView.setOpen(isOpen);
		valueView.setText(isOpen ? R.string.remind_state_open : R.string.remind_state_close);
	}

	public void setValueState(boolean isOpen, int strId) {
		setEnable(isOpen);
		setOpen(isOpen);
		valueView.setText(strId);
	}

}
