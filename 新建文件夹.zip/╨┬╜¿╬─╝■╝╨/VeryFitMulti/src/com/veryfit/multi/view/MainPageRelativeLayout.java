package com.veryfit.multi.view;

import java.util.Calendar;

import com.project.library.core.APPCoreServiceListener;
import com.project.library.core.CoreServiceProxy;
import com.project.library.device.cmd.health.HealthSyncRequest;
import com.project.library.device.cmd.health.HealthSyncSuccess;
import com.project.library.share.LibSharedPreferences;
import com.project.library.util.DebugLog;
import com.veryfit.multi.R;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.ui.fragment.inter.NotifyParentFragment;
import com.veryfit.multi.util.Util;
import com.veryfit.multi.view.group.FreshView;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.widget.ImageButton;
//import android.widget.ImageView;
import android.widget.RelativeLayout;
//import android.widget.Toast;

public class MainPageRelativeLayout extends RelativeLayout {

	private static final int MIN_SCROLL = 100;

	private static final int DURATION = 500;

	private FreshView freshView;

	private int freshHeight;

	private CoreServiceProxy mCore = CoreServiceProxy.getInstance();

	private ImageButton link_state;

	private NotifyParentFragment mHealthDataChangedListener = null;

	/** 是否正在同步数据 */
	private boolean isHealthDataSyncing = false;

	// private Text

	public MainPageRelativeLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	/**
	 * 必须调用此方法
	 */
	public void init(NotifyParentFragment listener) {
		mHealthDataChangedListener = listener;
		mCore.addListener(mCoreServiceListener);
		freshView = (FreshView) (findViewById(R.id.fresh_view));
		link_state = (ImageButton) findViewById(R.id.link_state);
		if (mCore.isDeviceConnected()) {
			link_state.setImageResource(R.drawable.link_state);
		} else {
			link_state.setImageResource(R.drawable.unlink_state);
		}
		getViewTreeObserver().addOnPreDrawListener(new OnPreDrawListener() {

			@Override
			public boolean onPreDraw() {
				getViewTreeObserver().removeOnPreDrawListener(this);
				setPaddingTop(-getFreshViewHeight());
				return false;
			}
		});
	}

	public int getFreshViewHeight() {
		if (freshHeight == 0)
			freshHeight = freshView.getMeasuredHeight();
		return freshHeight;
	}

	public void setPaddingTop(int paddingTop) {
		setPadding(getPaddingRight(), paddingTop, getPaddingRight(), getPaddingBottom());
		invalidate();
	}

	private boolean isIntercept;

	private float startY;

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		DebugLog.d("isIntercept = " + isIntercept + ev.getAction());
		// if (getPaddingTop() <= 0 && isIntercept) {
		// return true;
		// }
		final int action = ev.getAction();

		switch (action & MotionEvent.ACTION_MASK) {
		case MotionEvent.ACTION_MOVE:
			if (ev.getY() - startY > MIN_SCROLL && getPaddingTop() == -getFreshViewHeight()) {// 下拉动作
				isIntercept = true;
			}
			break;
		case MotionEvent.ACTION_DOWN:
			startY = ev.getY();
			isIntercept = false;
			break;
		case MotionEvent.ACTION_UP:
		case MotionEvent.ACTION_CANCEL:
			startY = 0;
			isIntercept = false;
			break;
		}
		return isIntercept;
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		super.onTouchEvent(event);
		if (freshView.getState() == FreshTextView.STATE_FRESHING) {// 如果正在刷新，就不做出理
			return false;
		}
		int currentTop = getPaddingTop();
		switch (event.getAction()) {
		case MotionEvent.ACTION_MOVE:
			int newPadding = Math.max(-getFreshViewHeight(), Math.min(0, (int) (event.getY() - startY) - getFreshViewHeight() - MIN_SCROLL));
			// int newPadding = Math.max(-getFreshViewHeight(), (int)
			// (event.getY() - startY) - getFreshViewHeight());
			// if(newPadding > 0){
			// newPadding *= 0.2;
			//
			// }
			// DebugLog.e("onTouchEvent" +"action = " + event.getAction() +
			// "**startY = " + startY + "****y = " + event.getY() +
			// "***newPadding" + newPadding);
			setPaddingTop(newPadding);
			if (currentTop < 0) {
				freshView.setState(FreshTextView.STATE_PULLING);
			} else if (currentTop >= 0) {
				freshView.setState(FreshTextView.STATE_FREE);
			}
			break;
		case MotionEvent.ACTION_CANCEL:
		case MotionEvent.ACTION_UP:
			if (currentTop < 0 && currentTop > -getFreshViewHeight()) {// 下拉未到底，滚回去
				ObjectAnimator.ofInt(this, "paddingTop", currentTop, -getFreshViewHeight()).setDuration((long) (DURATION * 1.0f / getFreshViewHeight() * (-currentTop))).start();
			} else if (currentTop >= 0) {// 到底了，就显示刷新
				freshView.setState(FreshTextView.STATE_FRESHING, 0);
				// 同步数据接口
				onStartUpdate();
			}
			break;
		}
		return true;
	}

	private void onStartUpdate() {
		if (mCore.isDeviceConnected()) {
			isHealthDataSyncing = true;
			LibSharedPreferences.getInstance().setSyncData(true);
			byte safeMode = AppSharedPreferences.getInstance().getSyncHealdataMode() ? HealthSyncSuccess.MODE_SAFE : HealthSyncSuccess.MODE_OTHER;
//			Toast.makeText(getContext(), "" + safeMode, Toast.LENGTH_SHORT).show();
			mCore.writeForce(HealthSyncRequest.getInstance().getHealthSyncRequestCmd(HealthSyncRequest.FLAG_FOREGROUND, safeMode));
		} else {
			DebugLog.d("设备未连接");
			stopAnim();
		}

	}

	private void stopAnim() {
		ObjectAnimator.ofInt(this, "paddingTop", 0, -getFreshViewHeight()).setDuration(DURATION).start();
		freshView.setState(FreshTextView.STATE_PULLING);
	}

	public void onFinishUpdate(boolean isSuccess) {
		stopAnim();
		if (mHealthDataChangedListener != null && isSuccess) {
			mHealthDataChangedListener.onHealthDataChanged();
		}
	}

	private APPCoreServiceListener mCoreServiceListener = new APPCoreServiceListener() {

		@Override
		public void onDataSendTimeOut(byte[] data) {

		}

		@Override
		public void onSyncData(int process) {
			freshView.setState(FreshTextView.STATE_FRESHING, process);
			DebugLog.d("正在同步数据，已完成" + process + "%");

			if (process == 100) {
				// 保存在设置界面显示的同步时间
				String time = Util.getSyncTimeStr(Calendar.getInstance());
				AppSharedPreferences.getInstance().setDeviceSyncEndTime(time);
				onFinishUpdate(true);
			}
		}

		public void onBLEConnected() {
			link_state.setImageResource(R.drawable.link_state);
		};

		public void onBLEDisConnected(String address) {
			link_state.setImageResource(R.drawable.unlink_state);

			if (isHealthDataSyncing) {
				onFinishUpdate(false);
				isHealthDataSyncing = false;
			}
		};

	};
}
