package com.veryfit.multi.share;

import com.project.library.share.CommonPreferences;
import com.project.library.util.DebugLog;

import android.content.Context;

/** 不存数据库的全部放在这里 */
public class AppSharedPreferences extends CommonPreferences {
	private static final String SP_NAME = "veryfit_multi_app";

	/** 用户绑定的设备地址 */
	private static final String BIND_DEVICE_ADDR = "bind_device_addr";

	/* **************************************************
	 * 记录数据是否改变的flag * *************************************************
	 */

	private static final String FLAG_GOAL_CHANGE = "FLAG_GOAL_CHANGE";

	/** 是否为第一次启动app */
	private static final String FIRST_START_APP = "first_start_app";

	/* **************************************************
	 * 用户信息 * *************************************************
	 */
	
	

	/** 用户性别 */
	private static final String USER_SEX = "USER_SEX";

	/** 用户身高 */
	private static final String USER_HEIGHT = "USER_HEIGHT";

	/** 用户体重 */
	private static final String USER_WEIGHT = "USER_WEIGHT";

	/** 用户生日 */
	private static final String USER_BIRTHDAY_YEAR = "USER_BIRTHDAY_YEAR";
	
	/** 用户生日 */
	private static final String USER_BIRTHDAY_MONTH = "USER_BIRTHDAY_MONTH";
	
	/** 用户生日 */
	private static final String USER_BIRTHDAY_DAY = "USER_BIRTHDAY_DAY";
	
	/** 用户昵称 */
	private static final String USER_NICK_NAME = "USER_NICK_NAME";

	/** 运动目标 */
	// private static final String GOAL_SPORT= "GOAL_SPORT";

	/** 睡眠目标 */
	// private static final String GOAL_SLEEP= "GOAL_SLEEP";

	/** 单位制式 */
	private static final String UNIT_TYPE = "UNIT_TYPE";

	/** 切换后主题的包名 */
	private static final String APP_THEME_PACKAGE = "app_theme_package";

	/** 同步数据安全模式 */
	private static final String SYNC_HEALTHDATA_MODE_SAFE = "sync_healthdata_mode_safe";

	/** 同步完成时间 */
	private static final String DEVICE_SYNC_END_TIME = "device_sync_end_time";

	/** 来电提醒开关 */
	private static final String DEVICE_REMIND_PHONE_SWITCH = "device_remind_phone_switch";

	/** 来电提醒延迟时间 */
	private static final String DEVICE_REMIND_PHONE_DELAY = "DEVICE_REMIND_PHONE_DELAY";

	/** 久坐提醒数据是否已经更改 */
	private static final String FLAG_DEVICE_REMIND_SPORT_CHANGE = "FLAG_DEVICE_REMIND_SPORT_CHANGE";

	/** 久坐提醒重复及开关 */
	private static final String DEVICE_REMIND_SPORT_REPETITIONS = "DEVICE_REMIND_SPORT_REPETITIONS";

	/** 久坐提醒间隔 */
	private static final String DEVICE_REMIND_SPORT_INTERVAL = "DEVICE_REMIND_SPORT_INTERVAL";

	/** 久坐提醒开始时间 时 */
	private static final String DEVICE_REMIND_SPORT_START_HOUR = "DEVICE_REMIND_SPORT_START_HOUR";

	/** 久坐提醒开始时间 分 */
	private static final String DEVICE_REMIND_SPORT_START_MIN = "DEVICE_REMIND_SPORT_START_MIN";

	/** 久坐提醒结束时间 时 */
	private static final String DEVICE_REMIND_SPORT_END_HOUR = "DEVICE_REMIND_SPORT_END_HOUR";

	/** 久坐提醒结束时间 分 */
	private static final String DEVICE_REMIND_SPORT_END_MIN = "DEVICE_REMIND_SPORT_END_MIN";
	
	private static final String DEVICE_UPDATE_AUTO = "DEVICE_UPDATE_AUTO";
	
	public void setDeviceUpdateAuto(boolean auto){
		setValue(DEVICE_UPDATE_AUTO, auto);
	}
	
	public boolean getDeviceUpdateAuto(){
		return getValue(DEVICE_UPDATE_AUTO, false);
	}

	//
	// public void setGoalSport(int goal){
	// setValue(GOAL_SPORT, goal);
	// }
	//
	// public int getGoalSport(){
	// return getValue(GOAL_SPORT, 10000);
	// }
	//
	// public void setGoalSleep(int goal){
	// setValue(GOAL_SLEEP, goal);
	// }
	//
	// public int getGoalSleep(){
	// return getValue(GOAL_SLEEP, 480);
	// }

	public void setFlagGoalChange(boolean change) {
		setValue(FLAG_GOAL_CHANGE, change);
	}

	public boolean getFlagGoalChange() {
		return getValue(FLAG_GOAL_CHANGE, false);
	}
	
	public void setUserBirthdayYear(int year) {
		setValue(USER_BIRTHDAY_YEAR, year);
	}

	public int getUserBirthdayYear() {
		return getValue(USER_BIRTHDAY_YEAR, 1990);
	}
	
	
	public void setUserBirthdayMonth(int month) {
		setValue(USER_BIRTHDAY_MONTH, month);
	}

	public int getUserBirthdayMonth() {
		return getValue(USER_BIRTHDAY_MONTH, 1);
	}

	public void setUserBirthdayDay(int day) {
		setValue(USER_BIRTHDAY_DAY, day);
	}
	
	public int getUserBirthdayDay() {
		return getValue(USER_BIRTHDAY_DAY, 1);
	}

	public void setUserWeight(int kg) {
		setValue(USER_WEIGHT, kg);
	}

	public int getUserWeight() {
		return getValue(USER_WEIGHT, getUserSex() ? 70 : 50);
	}
	
	public void setUserName(String name){
		setValue(USER_NICK_NAME, name);
	}
	
	public String getUserName(){
		return getValue(USER_NICK_NAME, "");
	}

	public void setUserHeight(int cm) {
		setValue(USER_HEIGHT, cm);
	}

	public int getUserHeight() {
		return getValue(USER_HEIGHT, getUserSex() ? 170 : 160);
	}

	public void setUnitType(int type) {
		setValue(UNIT_TYPE, type);
	}

	/** 默认公制 METRIC1 , 英制2 */
	public int getUnitType() {
		return getValue(UNIT_TYPE, 1);
	}

	public void setUserSex(boolean male) {
		setValue(USER_SEX, male);
	}

	/** true --> male */
	public boolean getUserSex() {
		return getValue(USER_SEX, true);
	}

	public void setFlagDeviceRemindSportChange(boolean isChange) {
		setValue(FLAG_DEVICE_REMIND_SPORT_CHANGE, isChange);
	}

	public boolean getFlagDeviceRemindSportChane() {
		return getValue(FLAG_DEVICE_REMIND_SPORT_CHANGE, false);
	}

	public void setDeviceRemindSportEndHour(int endHour) {
		setValue(DEVICE_REMIND_SPORT_END_HOUR, endHour);
	}

	public int getDeviceRemindSportEndHour() {
		return getValue(DEVICE_REMIND_SPORT_END_HOUR, 18);
	}

	public void setDeviceRemindSportEndMin(int endMin) {
		setValue(DEVICE_REMIND_SPORT_END_MIN, endMin);
	}

	public int getDeviceRemindSportEndMin() {
		return getValue(DEVICE_REMIND_SPORT_END_MIN, 0);
	}

	public void setDeviceRemindSportStartHour(int startHour) {
		setValue(DEVICE_REMIND_SPORT_START_HOUR, startHour);
	}

	public int getDeviceRemindSportStartHour() {
		return getValue(DEVICE_REMIND_SPORT_START_HOUR, 8);
	}

	public void setDeviceRemindSportStartMin(int startMin) {
		setValue(DEVICE_REMIND_SPORT_START_MIN, startMin);
	}

	public int getDeviceRemindSportStartMin() {
		return getValue(DEVICE_REMIND_SPORT_START_MIN, 0);
	}

	public void setDeviceRemindSportInterval(int interval) {
		setValue(DEVICE_REMIND_SPORT_INTERVAL, interval);
	}

	public int getDeviceRemindSportInterval() {
		return getValue(DEVICE_REMIND_SPORT_INTERVAL, 30);
	}

	public void setDeviceRemindSportRepetitions(int repetitions) {
		setValue(DEVICE_REMIND_SPORT_REPETITIONS, repetitions);
	}

	public int getDeviceRemindSportRepetitions() {
		return getValue(DEVICE_REMIND_SPORT_REPETITIONS, 0x3E);
	}

	public void setDeviceRemindPhoneSwitch(boolean isOpen) {
		setValue(DEVICE_REMIND_PHONE_SWITCH, isOpen);
	}

	public boolean getDeviceRemindPhoneSwitch() {
		return getValue(DEVICE_REMIND_PHONE_SWITCH, false);
	}

	public void setDeviceRemindPhoneDelay(int delay) {
		setValue(DEVICE_REMIND_PHONE_DELAY, delay);
	}

	public int getDeviceRemindPhoneDelay() {
		return getValue(DEVICE_REMIND_PHONE_DELAY, 8);
	}

	public void setDeviceSyncEndTime(String time) {
		setValue(DEVICE_SYNC_END_TIME, time);
	}

	public String getDeviceSyncEndTime() {
		return getValue(DEVICE_SYNC_END_TIME, "");
	}

	public void setSyncHealdataMode(boolean safe) {
		DebugLog.w("set Safe Mode");
		setValue(SYNC_HEALTHDATA_MODE_SAFE, safe);
	}

	public boolean getSyncHealdataMode() {
		return getValue(SYNC_HEALTHDATA_MODE_SAFE, false);
	}

	public void setAppThemePackage(String packageName) {
		setValue(APP_THEME_PACKAGE, packageName);
	}

	public String getAppThemePackage() {
		return getValue(APP_THEME_PACKAGE, "");
	}

	public void setFirstStartApp(boolean isFirst) {
		setValue(FIRST_START_APP, isFirst);
	}

	public boolean isFirstStartApp() {
		return getValue(FIRST_START_APP, true);
	}

	public void setBindDeviceAddr(String addr) {
		setValue(BIND_DEVICE_ADDR, addr);
	}

	public String getBindDeviceAddr() {
		return getValue(BIND_DEVICE_ADDR, "");
	}

	public void init(Context paramContext) {
		super.init(paramContext, SP_NAME);
	}

	private static AppSharedPreferences instance;

	public static final AppSharedPreferences getInstance() {
		if (instance == null) {
			instance = new AppSharedPreferences();
		}
		return instance;
	}

	private AppSharedPreferences() {

	}
}