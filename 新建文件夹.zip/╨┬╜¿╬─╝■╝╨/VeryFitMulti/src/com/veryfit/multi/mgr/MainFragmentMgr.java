package com.veryfit.multi.mgr;

public class MainFragmentMgr {
	
	public MainFragmentMgr(){
		
	}

}
