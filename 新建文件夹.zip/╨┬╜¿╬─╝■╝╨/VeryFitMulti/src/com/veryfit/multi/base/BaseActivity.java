package com.veryfit.multi.base;

import com.project.library.util.BleScanTool;
import com.project.library.util.DebugLog;
import com.veryfit.multi.util.Constant;

//import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

public abstract class BaseActivity extends FragmentActivity {

	/** 目前主题切换，后续可能会加入内部语言切换 */
	private BroadcastReceiver mBaseReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			if (action.equals(Constant.ACTION_THEME_CHANGED)) {
				onThemeChanged();
			}
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		DebugLog.d("create activity : " + getClass().getSimpleName());

		if (!BleScanTool.getInstance().isBluetoothOpen()) {
			DebugLog.d(getClass().getSimpleName() + "plz open bluethooth");
			// other codes
		}

		IntentFilter filter = new IntentFilter();
		filter.addAction(Constant.ACTION_THEME_CHANGED);
		registerReceiver(mBaseReceiver, filter);

		// setContentView(setContentLayout());
		initFirst();
		initView();
		initEvent();
		initData();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		unregisterReceiver(mBaseReceiver);
		mBaseReceiver = null;
		DebugLog.d("destory activity : " + getClass().getSimpleName());
		recreate();
	}

	/** 主题切换,更换新的主题 */
	protected abstract void onThemeChanged();

	/**
	 * 初始化View
	 */
	protected void initView() {
	};

	/**
	 * 初始化监听 在initView后
	 */
	protected void initEvent() {
	};

	/**
	 * 初始化数据 在initView后
	 */
	protected void initData() {
	};

	/**
	 * 初始化工作 在initView前
	 */
	protected void initFirst() {
	};

	protected void release() {
	};
}
