package com.veryfit.multi.base;

import com.project.library.util.DebugLog;
import com.veryfit.multi.ui.OnThemeChangedListener;

//import android.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class BaseFragment extends Fragment implements OnThemeChangedListener {

	protected boolean isVisible;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		DebugLog.e("onCreateView : " + getClass().getSimpleName());
		return super.onCreateView(inflater, container, savedInstanceState);
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) {
		super.setUserVisibleHint(isVisibleToUser);
		if (getUserVisibleHint()) {
			isVisible = true;
			onVisible();
		} else {
			isVisible = false;
			onInVisible();
		}
	}

	/** 视图可见时操作 */
	public void onVisible() {
		DebugLog.e("onVisible : " + getClass().getSimpleName());
		lazyLoad();
	}

	/** 视图不可见时操作 */
	public void onInVisible() {
		DebugLog.e("onInVisible : " + getClass().getSimpleName());
	}

	@Override
	public void onResume() {
		super.onResume();
		DebugLog.e("onResume : " + getClass().getSimpleName());
		onVisible();
	}

	@Override
	public void onPause() {
		super.onPause();
		DebugLog.e("onPause : " + getClass().getSimpleName());
		onInVisible();
	}

	/** 懒加载(可见时加载,不可见时隐藏等),在此时填充数据或者更新view */
	protected abstract void lazyLoad();
}
