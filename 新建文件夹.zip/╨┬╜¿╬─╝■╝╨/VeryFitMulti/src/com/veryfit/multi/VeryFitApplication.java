package com.veryfit.multi;

import com.project.library.core.CoreServiceProxy;
import com.project.library.device.cmd.health.HealthDataDetailsCache;
import com.project.library.share.LibSharedPreferences;
import com.project.library.util.BleScanTool;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.veryfit.multi.service.AssistService;
import com.veryfit.multi.share.AppSharedPreferences;
import com.veryfit.multi.util.CrashHandler;
import com.veryfit.multi.util.LOGThread;
import com.veryfit.multi.util.TempUtil;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.text.TextUtils;

public class VeryFitApplication extends Application {

	private static VeryFitApplication sInstance;
	/** 切换主题上下文 */
	public static Context mUIContext;

	@Override
	public void onCreate() {
		super.onCreate();
		init();
	}

	private void init() {
		sInstance = this;
		new LOGThread("" + android.os.Process.myPid()).start();
		LibSharedPreferences.getInstance().init(this);
		AppSharedPreferences.getInstance().init(this);
		TempUtil.init(this);
		DBTool.getInstance().init(this);
		HealthDataDetailsCache.getInstance();
		BleScanTool.getInstance().init(this);
		CoreServiceProxy.init(this);
		Thread.setDefaultUncaughtExceptionHandler(CrashHandler.getInstance().init(this));
		startService(new Intent(this , AssistService.class));
		try {
			String themePackageName = AppSharedPreferences.getInstance().getAppThemePackage();
			if (!TextUtils.isEmpty(themePackageName)) {
				mUIContext = createPackageContext(themePackageName, Context.CONTEXT_INCLUDE_CODE | Context.CONTEXT_IGNORE_SECURITY);
			}
		} catch (NameNotFoundException e) {
			DebugLog.e("theme package not exist !");
		}
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
		CoreServiceProxy.fini();
	}

	public static VeryFitApplication getInstance() {
		return sInstance;
	}
}
