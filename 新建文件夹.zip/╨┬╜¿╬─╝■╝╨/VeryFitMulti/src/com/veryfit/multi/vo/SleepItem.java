package com.veryfit.multi.vo;

public class SleepItem {
	/**
	 * 0-->深睡 ，1-->浅睡 , 2-->醒着
	 */
	public int state;

	public int time;

	public SleepItem(int state, int time) {
		super();
		this.state = state;
		this.time = time;
	}

	public SleepItem() {
		super();
	}

}
