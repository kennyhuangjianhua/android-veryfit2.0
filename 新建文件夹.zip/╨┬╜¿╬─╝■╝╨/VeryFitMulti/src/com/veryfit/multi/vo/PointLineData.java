package com.veryfit.multi.vo;

import java.util.Calendar;

import com.veryfit.multi.util.Util;

public class PointLineData {

	public Calendar date;

	public int data;

	public boolean isSameDay(Calendar d) {
		return Util.isSameDay(date, d);
	}
}
