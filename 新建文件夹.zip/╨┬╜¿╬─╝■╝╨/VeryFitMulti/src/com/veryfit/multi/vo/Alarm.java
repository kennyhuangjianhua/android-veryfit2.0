package com.veryfit.multi.vo;

import java.io.Serializable;

import com.veryfit.multi.R;

import android.content.res.Resources;

public class Alarm implements Serializable {

	public int id;

	/**
	 * 可设置的闹钟最大数
	 */
	public static int MAX_ALARM_COUNT = 5;

	/**
	 * 默认07：10
	 */
	public int hour, min;

	public int repetitions;

	// public String typeName;

	public AlarmType type;
	/**
	 * 默认新增
	 */
	public int status;

	public int snooze;

	public void setDefault() {
		hour = 7;
		min = 10;
		repetitions = 0x3F;
		type = AlarmType.WEAK_UP;
	}

	public boolean isOpen() {
		return (repetitions & 1) == 1;
	}

	public void setOpen(boolean isOpen) {
		if (isOpen)
			repetitions |= 1;
		else
			repetitions &= ~1;
	}

	public String getCycle(String[] weeks) {
		return getCycle(weeks, repetitions);
	}

	/**
	 * 
	 * @param res
	 * @return 返回读友好的周期，如"周一，周二，周五"
	 */
	public static String getCycle(String[] weeks, int repetitions) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < 7; i++) {
			// 第二位到第八位为周一到周日
			int mask = 1 << (i + 1);
			if ((repetitions & mask) == mask)
				sb.append(weeks[i] + ",");
		}
		return sb.substring(0, sb.length() > 0 ? sb.length() - 1 : 0);
	}

	// /**
	// *
	// * @param cycle
	// * 会将原来的清空，然后再将新的响铃周期，如周一周五周日响铃，int[]{1 , 5 , 7}加入进去
	// */
	// public void setCycle(int... cycle) {
	// repetitions = 0;
	// for (int i : cycle) {
	// repetitions |= (1 << i);
	// }
	// }

	/**
	 * 更新闹钟重复周期
	 * 
	 * @param index
	 *            index [1,7]对应[周一 , 周日]
	 * @param open
	 *            true闹钟在index对应的星期重复
	 */
	public void updateRepeat(int index, boolean open) {
		repetitions = updateRepeat(repetitions, index, open);
	}

	public static int updateRepeat(int repetitions, int index, boolean open) {
		if (open)
			repetitions |= (1 << index);
		else
			repetitions &= ~(1 << index);
		return repetitions;
	}

	@Override
	public String toString() {
		return " alarm : {" + " time: " + hour + ":" + min + " repeat: " + repetitions + " type :" + type.getTypeId() + "}";
	}

	public enum AlarmType {
		WEAK_UP(0), SLEPP(1), TRAINING(2), PILL(3), DATE(4), PARTY(5), MEETING(6), CUSTOM(7);

		private int id;

		AlarmType(int id) {
			this.id = id;
		}

		public int getTypeId() {
			return this.id;
		}

		public static AlarmType getTypeById(int id) {
			switch (id) {
			case 0:
				return WEAK_UP;
			case 1:

				return SLEPP;
			case 2:

				return TRAINING;
			case 3:

				return PILL;
			case 4:

				return DATE;
			case 5:

				return PARTY;
			case 6:

				return MEETING;
			case 7:

				return CUSTOM;

			default:
				return WEAK_UP;
			}
		}

		public String getTypeName(Resources res) {
			String[] names = res.getStringArray(R.array.alarmType);
			return names[this.id];
		}

	}

}
