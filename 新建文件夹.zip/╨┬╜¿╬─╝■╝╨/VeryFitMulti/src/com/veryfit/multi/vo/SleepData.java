package com.veryfit.multi.vo;

import java.util.Calendar;
import java.util.List;

import com.veryfit.multi.util.Util;

public class SleepData {

	/**
	 * {小时 ， 分钟}
	 */
	public int[] endTime;

	/**
	 * 睡眠持续时长，以分钟为单位
	 */
	public int durationMins;

	public int[] duration;

	public int deepTotal, lightTotal, awakeTotal;

	public Calendar date;

	private List<SleepItem> items;

	/**
	 * 入睡时间,{小时，分}
	 */
	public int[] startTime;

	private int startTimeMins = -1;

	private String unitHour = "h", unitMin = "m";

	public String getStartTimeStr() {
		return Util.getTimeStr(getStartTime());
	}

	public String getEndTimeStr() {
		return Util.getTimeStr(endTime);
	}

	/**
	 * 此处是为了模拟一个数据
	 * 
	 * @return
	 */
	public int getDurationMins() {
		durationMins = getEndTimeMins() - getStartTimeMins();
		return durationMins < 0 ? durationMins + 1440 : durationMins;
	}

	public List<SleepItem> getItems() {
		return items;
	}

	public int getEndTimeMins() {
		return endTime[0] * 60 + endTime[1];
	}

	public int getStartTimeMins() {
		if (startTimeMins == -1) {
			startTimeMins = endTime[0] * 60 + endTime[1] - durationMins;
			// 为防止这个人睡眠超过24小时，做一次循环
			while (startTimeMins < 0) {
				startTimeMins += 1440;
			}
		}
		return startTimeMins;
	}

	public void setItems(List<SleepItem> items) {
		// deepTotal = lightTotal = awakeTotal;
		this.items = items;
		// for (SleepItem item : items) {
		// switch (item.state) {
		// case 0:
		// deepTotal += item.time;
		// break;
		// case 1:
		// lightTotal += item.time;
		// break;
		// case 2:
		// awakeTotal += item.time;
		// break;
		// }
		// }
	}

	public int[] getStartTime() {
		if (startTime == null) {
			startTime = new int[2];

			startTime = Util.getHourAndMin(getStartTimeMins(), true);
		}
		return startTime;
	}

	public int[] getDuration() {
		if (duration == null) {
			duration = new int[2];
			duration = Util.getHourAndMin(durationMins, true);
		}
		return duration;
	}

	public String getDurationStr() {
		return formatDurationStr(durationMins);
	}

	public String getDeeptotalStr() {
		return formatDurationStr(deepTotal);
	}

	public String getLightTotalStr() {
		return formatDurationStr(lightTotal);
	}

	private String formatDurationStr(int mins) {
		return mins >= 60 ? (mins / 60) + unitHour + (mins % 60) + unitMin : mins + unitMin;
	}
}
