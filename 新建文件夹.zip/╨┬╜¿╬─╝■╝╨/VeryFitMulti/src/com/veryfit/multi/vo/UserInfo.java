package com.veryfit.multi.vo;

import com.project.library.device.cmd.settings.Userinfos;
import com.veryfit.multi.share.AppSharedPreferences;

public class UserInfo extends com.project.library.device.cmd.settings.Userinfos{
    
    public String name;
    
    
    public void init(){
    	AppSharedPreferences share = AppSharedPreferences.getInstance();
    	name = share.getUserName();
    	gender = share.getUserSex() ? MALE : FEMALE;
    	year = share.getUserBirthdayYear();
    	month = share.getUserBirthdayMonth();
    	day = share.getUserBirthdayDay();
    	height = share.getUserHeight();
    	weight = share.getUserWeight();
    }
    
    public void save(){
    	AppSharedPreferences share = AppSharedPreferences.getInstance();
    	share.setUserName(name);
    	share.setUserSex(gender == MALE);
    	share.setUserBirthdayYear(year);
    	share.setUserBirthdayMonth(month);
    	share.setUserBirthdayDay(day);
    	share.setUserHeight(height);
    	share.setUserWeight(weight);
    }
    
//    public Userinfos getCmdVo(){
//    	Userinfos userinfos = new Userinfos();
//    	userinfos.day = day;
//    	userinfos.month = month;
//    	userinfos.year = year;
//    	userinfos.gender = gender;
//    	userinfos.height = height;
//    	userinfos.weight = weight;
//    	return userinfos;
//    }

}
