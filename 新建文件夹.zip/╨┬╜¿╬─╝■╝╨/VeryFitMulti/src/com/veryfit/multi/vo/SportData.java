package com.veryfit.multi.vo;

import java.util.ArrayList;
import java.util.Calendar;

public class SportData {

	public Calendar date;

	public int steps;

	public int calorie;

	public float distance;

	/**
	 * 每15分钟数据
	 */
	public ArrayList<Integer> details;

}
