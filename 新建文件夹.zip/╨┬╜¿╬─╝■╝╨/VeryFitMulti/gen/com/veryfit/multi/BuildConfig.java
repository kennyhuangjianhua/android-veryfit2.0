/** Automatically generated file. DO NOT MODIFY */
package com.veryfit.multi;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}