/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: E:\\gittest\\localGit\\veryfit2\\ProjectLibrary\\src\\com\\project\\library\\core\\ICoreServiceCallback.aidl
 */
package com.project.library.core;
public interface ICoreServiceCallback extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.project.library.core.ICoreServiceCallback
{
private static final java.lang.String DESCRIPTOR = "com.project.library.core.ICoreServiceCallback";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.project.library.core.ICoreServiceCallback interface,
 * generating a proxy if needed.
 */
public static com.project.library.core.ICoreServiceCallback asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.project.library.core.ICoreServiceCallback))) {
return ((com.project.library.core.ICoreServiceCallback)iin);
}
return new com.project.library.core.ICoreServiceCallback.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onBlueToothError:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onBlueToothError(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onBLEConnecting:
{
data.enforceInterface(DESCRIPTOR);
this.onBLEConnecting();
reply.writeNoException();
return true;
}
case TRANSACTION_onBLEConnected:
{
data.enforceInterface(DESCRIPTOR);
this.onBLEConnected();
reply.writeNoException();
return true;
}
case TRANSACTION_onBLEDisConnected:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
this.onBLEDisConnected(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onBLEConnectTimeOut:
{
data.enforceInterface(DESCRIPTOR);
this.onBLEConnectTimeOut();
reply.writeNoException();
return true;
}
case TRANSACTION_onDataSendTimeOut:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
this.onDataSendTimeOut(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onDataReceived:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
this.onDataReceived(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onDataChanged:
{
data.enforceInterface(DESCRIPTOR);
java.util.List<com.project.library.database.SportDataDay> _arg0;
_arg0 = data.createTypedArrayList(com.project.library.database.SportDataDay.CREATOR);
this.onDataChanged(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onWareUpdate:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
this.onWareUpdate(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onBindUnbind:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
this.onBindUnbind(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onSettingsSuccess:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
boolean _arg1;
_arg1 = (0!=data.readInt());
this.onSettingsSuccess(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_onGetInfo:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
this.onGetInfo(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onSyncData:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.onSyncData(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.project.library.core.ICoreServiceCallback
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void onBlueToothError(int error) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(error);
mRemote.transact(Stub.TRANSACTION_onBlueToothError, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onBLEConnecting() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onBLEConnecting, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onBLEConnected() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onBLEConnected, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onBLEDisConnected(java.lang.String address) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(address);
mRemote.transact(Stub.TRANSACTION_onBLEDisConnected, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onBLEConnectTimeOut() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onBLEConnectTimeOut, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onDataSendTimeOut(byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_onDataSendTimeOut, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onDataReceived(byte[] data) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(data);
mRemote.transact(Stub.TRANSACTION_onDataReceived, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onDataChanged(java.util.List<com.project.library.database.SportDataDay> list) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeTypedList(list);
mRemote.transact(Stub.TRANSACTION_onDataChanged, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onWareUpdate(byte status) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(status);
mRemote.transact(Stub.TRANSACTION_onWareUpdate, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
@Override public void onBindUnbind(byte status) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(status);
mRemote.transact(Stub.TRANSACTION_onBindUnbind, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * @param cmdKey
     *            设置命令里面对应的key
     * @param success
     *            成功失败标志
     */
@Override public void onSettingsSuccess(byte cmdKey, boolean success) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(cmdKey);
_data.writeInt(((success)?(1):(0)));
mRemote.transact(Stub.TRANSACTION_onSettingsSuccess, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
     * @param cmdKey
     *            获取命令里面对应的key
     */
@Override public void onGetInfo(byte cmdKey) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(cmdKey);
mRemote.transact(Stub.TRANSACTION_onGetInfo, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**同步数据进度*/
@Override public void onSyncData(int process) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(process);
mRemote.transact(Stub.TRANSACTION_onSyncData, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_onBlueToothError = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onBLEConnecting = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onBLEConnected = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_onBLEDisConnected = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_onBLEConnectTimeOut = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_onDataSendTimeOut = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_onDataReceived = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_onDataChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_onWareUpdate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_onBindUnbind = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_onSettingsSuccess = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_onGetInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_onSyncData = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
}
public void onBlueToothError(int error) throws android.os.RemoteException;
public void onBLEConnecting() throws android.os.RemoteException;
public void onBLEConnected() throws android.os.RemoteException;
public void onBLEDisConnected(java.lang.String address) throws android.os.RemoteException;
public void onBLEConnectTimeOut() throws android.os.RemoteException;
public void onDataSendTimeOut(byte[] data) throws android.os.RemoteException;
public void onDataReceived(byte[] data) throws android.os.RemoteException;
public void onDataChanged(java.util.List<com.project.library.database.SportDataDay> list) throws android.os.RemoteException;
public void onWareUpdate(byte status) throws android.os.RemoteException;
public void onBindUnbind(byte status) throws android.os.RemoteException;
/**
     * @param cmdKey
     *            设置命令里面对应的key
     * @param success
     *            成功失败标志
     */
public void onSettingsSuccess(byte cmdKey, boolean success) throws android.os.RemoteException;
/**
     * @param cmdKey
     *            获取命令里面对应的key
     */
public void onGetInfo(byte cmdKey) throws android.os.RemoteException;
/**同步数据进度*/
public void onSyncData(int process) throws android.os.RemoteException;
}
