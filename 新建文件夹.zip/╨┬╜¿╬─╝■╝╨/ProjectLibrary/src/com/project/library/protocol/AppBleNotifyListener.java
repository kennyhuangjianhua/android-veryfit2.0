package com.project.library.protocol;

import java.util.List;
import com.project.library.database.SportDataDay;
import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.WareUpdateCmd;

public interface AppBleNotifyListener {
    public void onBlueToothError(int error);

    public void onBLEConnecting();

    public void onBLEConnected();

    public void onBLEDisConnected(String address);

    public void onBLEConnectTimeOut();

    public void onDataSendTimeOut(byte[] data);

    /**
     * 移动设备收到数据，并且检查当前命令是否已完成
     * 
     * @param cmd
     *            最后一条发往设备的指令
     * @param recv
     *            收到的数据
     * @return true 允许发送下一条指令
     * */
    public boolean onDataReceived(byte[] cmd, byte[] recv);

    public void onDataChanged(List<SportDataDay> list);

    /**
     * 固件升级指令的返回
     * 
     * @param statusSuccess
     *            状态
     * @see WareUpdateCmd#STATUS_SUCCESS
     * @see WareUpdateCmd#STATUS_LOW_BATTERY
     * @see WareUpdateCmd#STATUS_NOT_SUPPORT
     * */
    public void onWareUpdate(byte statusSuccess);

    /**
     * 绑定解绑的回调
     * 
     * @param statusUnbindSuccess
     *            状态
     * @see BindUnbindCmd#STATUS_BIND_SUCCESS
     * @see BindUnbindCmd#STATUS_BIND_FAILED
     * @see BindUnbindCmd#STATUS_UNBIND_SUCCESS
     * @see BindUnbindCmd#STATUS_BIND_FAILED
     * */
    public void onBindUnbind(byte statusUnbindSuccess);

    /**
     * @param cmdKey
     *            设置命令里面对应的key
     * @param success
     *            成功失败标志
     */
    public void onSettingsSuccess(byte cmdKey, boolean success);

    /**
     * @param cmdKey
     *            获取命令里面对应的key
     */
    public void onGetInfo(byte cmdKey);
    
    
    /** 同步数据进度 */
    public void onSyncData(int process);
}
