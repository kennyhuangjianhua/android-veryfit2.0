package com.project.library.protocol;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import com.project.library.ble.BleGattAttributes;
import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.DeviceBaseCommand;
import com.project.library.device.cmd.WareUpdateCmd;
import com.project.library.device.datamanager.HealthDataManager;
import com.project.library.device.datamanager.NormalDataCallback;
import com.project.library.device.datamanager.NormalDataManager;
import com.project.library.util.BleScanTool;
import com.project.library.util.BleStatus;
import com.project.library.util.ByteDataConvertUtil;
import com.project.library.util.DebugLog;
import com.project.library.util.UartLogUtil;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;

public class BleProxy {
    /** 10秒连接超时 */
    private static final long CONNECT_TIMEOUT_PEROID = 10000L;// 10s
    /** 延时连接以及小米华为等连接之前扫描时间 */
    private static final long CONNECT_DELAY_PEROID = 2000L;// 2s

    private Context mContext;
    private AppBleNotifyListener mAppBleNotifyListener;
    private BleScanTool mBleScanTool = BleScanTool.getInstance();
    private BluetoothAdapter mBluetoothAdapter;

    private boolean isInit = false;

    private boolean isFirstConnect = true;
    private Handler mConnectingHandler = new Handler();
    private String mBleAddress;
    /** 是否需要设置超时。自动断开的时候，不要设置超时 */
    private boolean isNeedSetTimeOut = true;
    private GattCallback mGattCallback = new GattCallback();
    private Handler mErrorHandler = new Handler();
    private BluetoothGatt mBluetoothGatt;
    private static int mConnectionState = BleStatus.DEVICE_DISCONNECTED;
    private boolean bluetoothON = true;

    private HealthDataManager mHealthDataManager = null;
    private NormalDataManager mNormalDataManager = null;

    private boolean isHandlerDisconnect = false;
    /** 固件升级 */
    private boolean isWareUpdate = false;
    /** 解绑标志 */
    private boolean isUnbind = false;
    
    private StringBuilder sb = new StringBuilder();
    
    private SimpleDateFormat sdf3 = new SimpleDateFormat("HH:mm:ss", Locale.CHINESE);

    public BleProxy(Context context, AppBleNotifyListener listener) {
        mContext = context;
        mAppBleNotifyListener = listener;
        mBluetoothAdapter = mBleScanTool.getBluetoothAdapter();
    }

    /**
     * 每次切换设备须重新初始化
     * 
     * @return true init success
     * */
    public boolean initBLE(byte devicesId) {
        if (!isBluetoothAvailable()) {
            return false;
        }

        if (mHealthDataManager == null) {
            mHealthDataManager = new HealthDataManager();
        }
        mHealthDataManager.init(mAppBleNotifyListener);

        if (mNormalDataManager == null) {
            mNormalDataManager = new NormalDataManager();
        }
        mNormalDataManager.init(mAppBleNotifyListener, mNormalDataCallback);

        isInit = true;
        return isInit;
    }

    private void cleanDataManager() {
        if (mHealthDataManager != null) {
            mHealthDataManager.clear();
            mHealthDataManager.close();
            mHealthDataManager.setDeviceConnectedWritten(false);
            mHealthDataManager = null;
        }
        if (mNormalDataManager != null) {
            mNormalDataManager.setDeviceConnectedWritten(false);
            mNormalDataManager.close();
            mNormalDataManager = null;
        }
    }

    public void close() {
        isInit = false;
        isWareUpdate = false;
        isUnbind = false;
        
        closeDevice(true);
    }

    private void closeDevice(boolean handlerDisconnect) {
        if (!isDeviceDisconnected()) {
            isInit = false;
            cleanDataManager();
            mConnectionState = BleStatus.DEVICE_DISCONNECTED;
            SetOrCancelTimeOut(false);
            isHandlerDisconnect = handlerDisconnect;
            if (mBluetoothGatt != null) {
                refreshDeviceCache(mBluetoothGatt);
                mBluetoothGatt.close();
                mBluetoothGatt = null;
            }
            if (isHandlerDisconnect) {
                // 固件升级和解绑定义为手动断开
                if (isWareUpdate) {
                    if (mAppBleNotifyListener != null) {
                        mAppBleNotifyListener.onWareUpdate(WareUpdateCmd.STATUS_SUCCESS);
                    }
                    isWareUpdate = false;
                } else if (isUnbind) {
                    if (mAppBleNotifyListener != null) {
                        mAppBleNotifyListener.onBindUnbind(BindUnbindCmd.STATUS_UNBIND_SUCCESS);
                    }
                    isUnbind = false;
                } else {
                    // 手动断开上报APP并清除address
                    if (mAppBleNotifyListener != null) {
                        mAppBleNotifyListener.onBLEDisConnected(mBleAddress);
                    }
                    mBleAddress = null;
                }
            } else {
                if (mAppBleNotifyListener != null) {
                    mAppBleNotifyListener.onBLEDisConnected(mBleAddress);
                }
                // 蓝牙为打开状态则自动连接
                if (bluetoothON) {
                    delayConnect();
                }
            }
            
            //还原标志位
            isHandlerDisconnect = false;
        }
    }

    public boolean connect(String address) {
        if (!isInit) {
            // DebugLog.e("proxy not init yet !");
            // return false;
            initBLE((byte) 0);
        }
        if (!isDeviceDisconnected()) {
            DebugLog.e("device connected or connecting..");
            return false;
        }
        if (!isBluetoothAvailable()) {
            return false;
        }
        if (TextUtils.isEmpty(address)) {
            DebugLog.e("address is null");
            return false;
        }

        mBleAddress = address;
        boolean needScanBeforeConnect = BleScanTool.getInstance().isNeedScanDevice();
        if (isFirstConnect && needScanBeforeConnect) {
            isFirstConnect = false;
            scanAndAutoConnect();
            return true;
        }

        isFirstConnect = false;
        return connect();
    }

    private boolean connect() {
        final BluetoothDevice localBluetoothDevice = mBluetoothAdapter.getRemoteDevice(mBleAddress);
        if (localBluetoothDevice == null) {
            return false;
        }

        if (mAppBleNotifyListener != null) {
            mAppBleNotifyListener.onBLEConnecting();
        }
        mConnectionState = BleStatus.DEVICE_CONNECTING;
        String manufacturer = android.os.Build.MANUFACTURER;
        if (manufacturer.equalsIgnoreCase("samsung") && mBluetoothGatt != null) {
            DebugLog.e("connect<samsung>connect>>>>>" + mBleAddress);
            mBluetoothGatt.connect();
            setGatt();
        } else {
            connectGatt(localBluetoothDevice);
        }

        if (isNeedSetTimeOut) {
            SetOrCancelTimeOut(true);
        } else {
            isNeedSetTimeOut = true;
        }

        return true;
    }

    private void connectGatt(BluetoothDevice localBluetoothDevice) {
        if (mBluetoothGatt != null) {
            mBluetoothGatt.close();
        }
        DebugLog.e("connect<!samsung or nullgatt>connectGatt>>>>>" + mBleAddress);
        mBluetoothGatt = localBluetoothDevice.connectGatt(mContext, false, mGattCallback);
        setGatt();
    }

    /** 延时连接 */
    public void delayConnect() {
        // address为空(说明上次没有设备连接)、蓝牙不可用或者扫描工具正在扫描则不进行任何操作
        if ((mBleAddress == null) || (!isBluetoothAvailable()) || mBleScanTool.isScanning()) {
            return;
        }
        mConnectingHandler.removeCallbacksAndMessages(null);
        mConnectingHandler.postDelayed(new Runnable() {

            @Override
            public void run() {
                connect(mBleAddress);
            }
        }, CONNECT_DELAY_PEROID);
    }

    private void setGatt() {
        if (mHealthDataManager != null) {
            mHealthDataManager.setGatt(mBluetoothGatt);
        }
        if (mNormalDataManager != null) {
            mNormalDataManager.setGatt(mBluetoothGatt);
        }
    }

    public boolean isDeviceConnected() {
        return mConnectionState == BleStatus.DEVICE_CONNECTED;
    }

    public boolean isDeviceDisconnected() {
        return mConnectionState == BleStatus.DEVICE_DISCONNECTED;
    }

    private class GattCallback extends BluetoothGattCallback {
        private GattCallback() {
        }

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            DebugLog.e("onConnectionStateChange[" + status + "->" + newState + "]");
            if (status == 133 || status == 141 || status == 129) {
                BleGattAttributes.enablePeerDeviceNotifyNormal(gatt, false);
                BleGattAttributes.enablePeerDeviceNotifyHealth(gatt, false);
                closeDevice(false);
                return;
            }
            if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                BleGattAttributes.enablePeerDeviceNotifyNormal(gatt, false);
                BleGattAttributes.enablePeerDeviceNotifyHealth(gatt, false);

                if (isHandlerDisconnect) {
                    // 手动断开则close
                    // 发送解绑命令之后，没有手动调用close(),设备断开也算手动断开.(升级和解绑算手动断开，重启不算手动断开.根据接收到指令来判断)
                    // 根据不同设备协议做不同处理，有可能需要在解绑命令成功之后设置isHandlerDisconnect为true
                    closeDevice(true);
                } else {
                    closeDevice(false);
                }
            } else if ((newState == BluetoothProfile.STATE_CONNECTED)) {
                SetOrCancelTimeOut(false);
                if (gatt.discoverServices()) {
                    SetOrCancelTimeOut(true);
                } else {
                    closeDevice(false);
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            DebugLog.e("onServicesDiscovered : " + (status == BluetoothGatt.GATT_SUCCESS));
            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (!BleGattAttributes.enablePeerDeviceNotifyNormal(gatt, true)) {
                    closeDevice(false);
                }
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                byte[] value = characteristic.getValue();
                if (value != null) {
                	
                    DebugLog.e("onCharacteristicWrite:" + gatt.getDevice().getAddress() + "[" + ByteDataConvertUtil.bytesToHexString(value) + "]");
                    sb.append(sdf3.format(new Date()))
                    .append(" : write > ")
                    .append( "[" + ByteDataConvertUtil.bytesToHexString(value) + "]")
                    .append("\r\n");
                    UartLogUtil.record(sb.toString());
                    sb.replace(0, sb.length() - 1, "");
                    
                    if (BleGattAttributes.WRITE_UUID_HEALTH.equals(characteristic.getUuid())) {
                        mHealthDataManager.onCommandWriteSuccess(value);
                    } else if (BleGattAttributes.WRITE_UUID_NORMAL.equals(characteristic.getUuid())) {
                        mNormalDataManager.onCommandWriteSuccess(value);
                    }
                } else {
                    DebugLog.e("onCharacteristicWrite error, value == null");
                }
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            boolean success = (BluetoothGatt.GATT_SUCCESS == status);
            if (success) {
                if (BleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG_UUID.equals(descriptor.getUuid())) {
                    // enabled or disabled characteristic.
                    boolean enabled = descriptor.getValue()[0] == 1;
                    if (BleGattAttributes.NOTIFY_UUID_HEALTH.equals(descriptor.getCharacteristic().getUuid())) {
                        if (enabled) {
                            mHealthDataManager.clear();
                            mHealthDataManager.setDeviceConnectedWritten(true);
                            mNormalDataManager.setDeviceConnectedWritten(true);
                            mHealthDataManager.setCanWriteNext(true);
                            mNormalDataManager.setCanWriteNext(true);
                            DebugLog.e("onDescriptorWrite:" + gatt.getDevice().getAddress());
                            if (mAppBleNotifyListener != null) {
                                mAppBleNotifyListener.onBLEConnected();
                            }
                            mConnectionState = BleStatus.DEVICE_CONNECTED;
                        }
                    } else if (BleGattAttributes.NOTIFY_UUID_NORMAL.equals(descriptor.getCharacteristic().getUuid())) {
                        if (enabled) {
                            SetOrCancelTimeOut(false);
                            if (!BleGattAttributes.enablePeerDeviceNotifyHealth(gatt, true)) {
                                closeDevice(false);
                            }
                        }
                    }
                }
            } else {
                closeDevice(false);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            UUID uuid = characteristic.getUuid();
            byte[] to = new byte[DeviceBaseCommand.BYTE_LEN_TOTAL];
            DeviceBaseCommand.copy(characteristic.getValue(), to);
            
            sb.append(sdf3.format(new Date()))
            .append(" : receive > ")
            .append("[" + ByteDataConvertUtil.bytesToHexString(to) + "]")
            .append("\r\n\r\n");
            if (uuid.equals(BleGattAttributes.NOTIFY_UUID_HEALTH)) {
                mHealthDataManager.receive(to, gatt.getDevice().getAddress());
            } else if (uuid.equals(BleGattAttributes.NOTIFY_UUID_NORMAL)) {
                mNormalDataManager.receive(to, gatt.getDevice().getAddress());
            }
        }
    }

    public void writeForce(final byte[] value) {
        if (isDeviceConnectedWritten(value)) {
            if (DeviceBaseCommand.isHealthCmd(value)) {
                mHealthDataManager.setCanWriteNext(true);
            } else {
                mNormalDataManager.setCanWriteNext(true);
            }
            write(value);
        }
    }

    /** 向设备发送指令 */
    public void write(final byte[] value) {
        if (isDeviceConnectedWritten(value)) {
            if (DeviceBaseCommand.isHealthCmd(value)) {
                if (mHealthDataManager.isCanWriteNext()) {
                    mHealthDataManager.write(value);
                }
            } else {
                if (mNormalDataManager.isCanWriteNext()) {
                    mNormalDataManager.write(value);
                }
            }
        }
    }

    public boolean isDeviceConnectedWritten(byte[] cmd) {

        return DeviceBaseCommand.isHealthCmd(cmd) ? mHealthDataManager.isDeviceConnectedWritten() : mNormalDataManager.isDeviceConnectedWritten();
    }

    public boolean canWriteNext(byte[] cmd) {

        return DeviceBaseCommand.isHealthCmd(cmd) ? mHealthDataManager.isCanWriteNext() : mNormalDataManager.isCanWriteNext();
    }

    private final NormalDataCallback mNormalDataCallback = new NormalDataCallback() {

        @Override
        public void onWareUpdate(byte status) {
            if (status == WareUpdateCmd.STATUS_SUCCESS) {
                // 此时设备会自动断开，等待设备断开后会收到断开连接的通知
                // 然后在closeDevice(boolean)方法里面通知设备立刻固件升级
                isWareUpdate = true;
                isHandlerDisconnect = true;
            } else if (mAppBleNotifyListener != null) {
                mAppBleNotifyListener.onWareUpdate(status);
                isWareUpdate = false;
                mNormalDataManager.setCanWriteNext(true);
            }
        }

        @Override
        public void onUnbinded() {
            // 收到解绑成功的回复，不能再次发送任何指令，需要断开连接
            // 在这里和升级时不一样，设备不会自动断开，所以不用等待，直接关闭连接，
            // 然后在closeDevice(boolean)方法里面通知app
            isUnbind = true;
            mNormalDataManager.setCanWriteNext(false);
            isHandlerDisconnect = true;
            closeDevice(isHandlerDisconnect);
        }
    };

    /**
     * set or cancel timeout task
     * */
    private void SetOrCancelTimeOut(boolean set) {
        mErrorHandler.removeCallbacksAndMessages(null);
        if (set) {
            mErrorHandler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    closeDevice(false);
                }
            }, CONNECT_TIMEOUT_PEROID);
        }
    }

    private boolean isScaning = false;
    private Handler mTempHandler;

    /** 扫描并自动连接(包括蓝牙断开之后又打开),小米、华为需要扫描一下再自动连接 */
    public void scanAndAutoConnect() {
        // address为空(说明上次没有设备连接)、蓝牙不可用或者扫描工具正在扫描则不进行任何操作
        if ((mBleAddress == null) || (!isBluetoothAvailable()) || mBleScanTool.isScanning()) {
            return;
        }
        final LeScanCallback callback = new LeScanCallback() {

            @Override
            public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {

            }
        };
        if (mTempHandler == null) {
            mTempHandler = new Handler();
        }

        mTempHandler.removeCallbacksAndMessages(null);
        mTempHandler.postDelayed(new Runnable() {
            public void run() {
                mBluetoothAdapter.stopLeScan(callback);
                isScaning = false;
                delayConnect();
            }
        }, CONNECT_DELAY_PEROID);

        if (isScaning) {
            mBluetoothAdapter.stopLeScan(callback);
        }
        isScaning = true;
        mBluetoothAdapter.startLeScan(callback);
        // 这种方式在某些手机上不行。
        // mBluetoothAdapter.startLeScan(BleGattAttributes.SERVICE_UUIDS,
        // callback);
    }

    public void notifyBluetoothStateChanged(boolean enable) {
        bluetoothON = enable;
    }

    private void refreshDeviceCache(final BluetoothGatt gatt) {
        try {
            Method refresh = gatt.getClass().getMethod("refresh");
            if (refresh != null) {
                refresh.invoke(gatt);
            }
        } catch (Exception e) {
            DebugLog.e(e.getMessage());
        }
    }

    /** 检查蓝牙可用 */
    private boolean isBluetoothAvailable() {
        if (!mBleScanTool.isSupportBLE()) {
            if (mAppBleNotifyListener != null) {
                mAppBleNotifyListener.onBlueToothError(BleStatus.NOT_SUPPORT);
            }
            return false;
        }
        if (!mBleScanTool.isBluetoothOpen()) {
            if (mAppBleNotifyListener != null) {
                mAppBleNotifyListener.onBlueToothError(BleStatus.NOT_OPEN);
            }
            return false;
        }
        return true;
    }
}
