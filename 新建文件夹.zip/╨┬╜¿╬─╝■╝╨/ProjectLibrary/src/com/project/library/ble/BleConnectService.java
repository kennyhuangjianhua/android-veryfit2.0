package com.project.library.ble;

import com.project.library.util.BleScanTool;
import com.project.library.util.DebugLog;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;

public class BleConnectService extends Service {

    private CoreServiceImpl mCore;

    @Override
    public void onCreate() {
        DebugLog.e("onCreate");
        mCore = new CoreServiceImpl(this);
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        registerReceiver(mBluetoothStatusReceiver, filter);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mCore;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        close();
        return false;
    }

    @Override
    public void onDestroy() {
        DebugLog.e("onDestroy");
        close();
        unregisterReceiver(mBluetoothStatusReceiver);
    }

    private void close() {
        if (mCore != null) {
            mCore.close();
            mCore = null;
        }
    }

    private BroadcastReceiver mBluetoothStatusReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.STATE_OFF);
                if (state == BluetoothAdapter.STATE_OFF) {
                    DebugLog.e("蓝牙已断开");
                    if (mCore != null) {
                        mCore.notifyBluetoothStateChanged(false);
                    }
                } else if (state == BluetoothAdapter.STATE_ON) {
                    DebugLog.e("蓝牙已连接");
                    if (mCore != null) {
                        mCore.notifyBluetoothStateChanged(true);
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                    }
                    // 手机蓝牙关闭之后又开启则自动连接设备
                    boolean needScanBeforeConnect = BleScanTool.getInstance().isNeedScanDevice();
                    if (mCore != null) {
                        mCore.autoConnect(needScanBeforeConnect);
                    }
                }
            }
        }
    };
}
