package com.project.library.ble;

import java.util.UUID;

import com.project.library.util.DebugLog;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;

public class BleGattAttributes {
    public static final UUID SERVICE_UUID = UUID.fromString("00000aF0-0000-1000-8000-00805f9b34fb");

    /** write data except health data */
    public static final UUID WRITE_UUID_NORMAL = UUID.fromString("00000aF6-0000-1000-8000-00805f9b34fb");
    /** notify data except health data */
    public static final UUID NOTIFY_UUID_NORMAL = UUID.fromString("00000aF7-0000-1000-8000-00805f9b34fb");

    /** write health data */
    public static final UUID WRITE_UUID_HEALTH = UUID.fromString("00000aF1-0000-1000-8000-00805f9b34fb");
    /** notify health data */
    public static final UUID NOTIFY_UUID_HEALTH = UUID.fromString("00000aF2-0000-1000-8000-00805f9b34fb");

    public static final UUID CLIENT_CHARACTERISTIC_CONFIG_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    public static final UUID[] SERVICE_UUIDS = new UUID[] { SERVICE_UUID };

    /** write normal BluetoothGattCharacteristic except health data */
    public static BluetoothGattCharacteristic getNormalWriteCharacteristic(BluetoothGatt gatt) {

        return getCharacteristic(gatt, BleGattAttributes.SERVICE_UUID, BleGattAttributes.WRITE_UUID_NORMAL);
    }

    /** write health BluetoothGattCharacteristic */
    public static BluetoothGattCharacteristic getHealthWriteCharacteristic(BluetoothGatt gatt) {

        return getCharacteristic(gatt, BleGattAttributes.SERVICE_UUID, BleGattAttributes.WRITE_UUID_HEALTH);
    }

    /** enable/disable notify normal BluetoothGattDescriptor */
    public static boolean enablePeerDeviceNotifyNormal(BluetoothGatt gatt, boolean enable) {
        DebugLog.e("enablePeerDeviceNotifyNormal: " + enable);
        return enablePeerDeviceNotifyMe(gatt, NOTIFY_UUID_NORMAL, enable);
    }

    /** enable/disable notify health BluetoothGattDescriptor */
    public static boolean enablePeerDeviceNotifyHealth(BluetoothGatt gatt, boolean enable) {
        DebugLog.e("enablePeerDeviceNotifyHealth:" + enable);
        return enablePeerDeviceNotifyMe(gatt, NOTIFY_UUID_HEALTH, enable);
    }

    /** enable/disable notify BluetoothGattDescriptor */
    private static boolean enablePeerDeviceNotifyMe(BluetoothGatt gatt, UUID uuid, boolean enable) {
        BluetoothGattCharacteristic gattCharacteristic = getCharacteristic(gatt, BleGattAttributes.SERVICE_UUID, uuid);
        if ((gattCharacteristic != null) && ((BluetoothGattCharacteristic.PROPERTY_NOTIFY | gattCharacteristic.getProperties()) > 0)) {
            gatt.setCharacteristicNotification(gattCharacteristic, enable);
            if (uuid.equals(gattCharacteristic.getUuid())) {
                BluetoothGattDescriptor localBluetoothGattDescriptor = gattCharacteristic.getDescriptor(BleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG_UUID);
                localBluetoothGattDescriptor.setValue(enable ? BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE : BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
                return gatt.writeDescriptor(localBluetoothGattDescriptor);
            }
        }

        return false;
    }

    private static BluetoothGattCharacteristic getCharacteristic(BluetoothGatt gatt, UUID serviceId, UUID characteristicId) {
        if (gatt == null) {
            return null;
        }
        BluetoothGattService service = gatt.getService(serviceId);
        if (service != null) {
            BluetoothGattCharacteristic c = service.getCharacteristic(characteristicId);
            return c;
        }
        return null;
    }
}