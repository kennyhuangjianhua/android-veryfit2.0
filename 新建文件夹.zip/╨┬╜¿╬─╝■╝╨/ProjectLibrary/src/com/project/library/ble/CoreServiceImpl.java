package com.project.library.ble;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import com.project.library.core.ICoreService;
import com.project.library.core.ICoreServiceCallback;
import com.project.library.database.SportDataDay;
import com.project.library.protocol.AppBleNotifyListener;
import com.project.library.protocol.BleProxy;
import com.project.library.util.BleStatus;
import com.project.library.util.DebugLog;
import com.project.library.util.PendingHandler;

public class CoreServiceImpl extends ICoreService.Stub {
    private Context mContext;
    private HandlerThread mHandlerThread;
    /** 向设置写数据专用 */
    private PendingHandler mWriteHandler;
    private BleProxy mProxy;
    private RemoteCallbackList<ICoreServiceCallback> mCallbacks;

    private HandlerThread mOperationHandlerThread;
    /** 设备操作 */
    private Handler mOperationHandler;
    private boolean isClose = false;

    public CoreServiceImpl(Context context) {
        isClose = false;
        mContext = context;

        mHandlerThread = new HandlerThread("BLECore_PendingHandler");
        mHandlerThread.start();
        mWriteHandler = new PendingHandler(mHandlerThread.getLooper());

        mOperationHandlerThread = new HandlerThread("OperationHandlerThread");
        mOperationHandlerThread.start();
        mOperationHandler = new Handler(mOperationHandlerThread.getLooper());

        mProxy = new BleProxy(mContext, mAppBleNotifyListener);
        mCallbacks = new RemoteCallbackList<ICoreServiceCallback>();
    }

    public void close() {
        DebugLog.e("closed.");
        isClose = true;
        mHandlerThread.quit();
        mOperationHandlerThread.quit();
        mCallbacks.kill();
        mProxy.close();
    }

    /** 手机蓝牙关闭之后再开启,自动连接设备。先扫描再连接(部分手机),其他手机则自动连接 */
    public void autoConnect(final boolean needScanBeforeConnect) {
        mOperationHandler.post(new Runnable() {

            @Override
            public void run() {
                DebugLog.e("自动连接设备。。。");
                if (needScanBeforeConnect) {
                    mProxy.scanAndAutoConnect();
                } else {
                    mProxy.delayConnect();
                }
            }
        });
    }

    /**
     * 设置更新蓝牙状态
     * */
    public void notifyBluetoothStateChanged(boolean enable) {
        mProxy.notifyBluetoothStateChanged(enable);
        broadcast(BLUE_TOOTH_ERROR_METHOD, INT_SIGNATURE, enable ? BleStatus.STATE_ON : BleStatus.STATE_OFF);
    }

    @Override
    public void registerCallback(ICoreServiceCallback callback) throws RemoteException {
        mCallbacks.register(callback);
    }

    @Override
    public void unregisterCallback(ICoreServiceCallback callback) throws RemoteException {
        mCallbacks.unregister(callback);
    }

    @Override
    public boolean initBLE(byte deviceId) throws RemoteException {

        return mProxy.initBLE(deviceId);
    }

    @Override
    public synchronized boolean connect(final String address) throws RemoteException {
        mOperationHandler.post(new Runnable() {

            @Override
            public void run() {
                mProxy.connect(address);
            }
        });

        return true;
    }

    @Override
    public synchronized boolean disconnect() throws RemoteException {
        mOperationHandler.post(new Runnable() {

            @Override
            public void run() {
                mProxy.close();
            }
        });

        return true;
    }

    @Override
    public synchronized boolean write(final byte[] cmd) throws RemoteException {
        if (isClose || (!mProxy.isDeviceConnectedWritten(cmd)) || (!mProxy.canWriteNext(cmd))) {
            DebugLog.e("device closed or can not send next command.");
            return false;
        }
        boolean success = false;
        if (!mWriteHandler.pending()) {
            success = mWriteHandler.postT(new Runnable() {

                @Override
                public void run() {

                    mProxy.write(cmd);
                }
            });
        } else {
            DebugLog.e("invalid state.(write)");
        }

        return success;
    }

    @Override
    public synchronized boolean writeForce(final byte[] cmd) throws RemoteException {
        if (isClose || (!mProxy.isDeviceConnectedWritten(cmd))) {
            DebugLog.e("device closed.");
            return false;
        }
        boolean success = false;
        success = mWriteHandler.postF(new Runnable() {

            @Override
            public void run() {

                mProxy.writeForce(cmd);
            }
        });

        return success;
    }

    @Override
    public boolean isDeviceConnected() throws RemoteException {

        return mProxy.isDeviceConnected();
    }

	// method
	private static final String BLUE_TOOTH_ERROR_METHOD = "onBlueToothError";
	private static final String BLE_CONNECTING_METHOD = "onBLEConnecting";
	private static final String BLE_CONNECTED_METHOD = "onBLEConnected";
	private static final String BLE_DISCONNECTED_METHOD = "onBLEDisConnected";
	private static final String BLE_CONNECT_TIMEOUT_METHOD = "onBLEConnectTimeOut";
	private static final String DATA_SEND_TIMEOUT_METHOD = "onDataSendTimeOut";
	private static final String DATA_RECEIVE_METHOD = "onDataReceived";
	private static final String DATA_CHANGED_METHOD = "onDataChanged";
	private static final String ON_WARE_UPDATE_METHOD = "onWareUpdate";
	private static final String ON_BIND_UNBIND_METHOD = "onBindUnbind";
	private static final String ON_SETTINGS_SUCCESS = "onSettingsSuccess";
	private static final String ON_GET_INFO = "onGetInfo";
	private static final String ON_SYNC_DATA = "onSyncData";

    // signature
    private static final Class<?>[] VIOD_SIGNATURE = new Class<?>[] {};
    private static final Class<?>[] INT_SIGNATURE = new Class<?>[] { int.class };
    private static final Class<?>[] STRING_SIGNATURE = new Class<?>[] { String.class };
    private static final Class<?>[] BYTE_SIGNATURE = new Class<?>[] { byte.class };
    private static final Class<?>[] BYTE_ARRAY_SIGNATURE = new Class<?>[] { byte[].class };
    private static final Class<?>[] BYTE_BOOLEAN_SIGNATURE = new Class<?>[] { byte.class, boolean.class };
    private static final Class<?>[] LIST_SIGNATURE = new Class<?>[] { List.class };

    private AppBleNotifyListener mAppBleNotifyListener = new AppBleNotifyListener() {

        @Override
        public void onBlueToothError(int error) {

            broadcast(BLUE_TOOTH_ERROR_METHOD, INT_SIGNATURE, error);
        }

        @Override
        public void onBLEConnecting() {

            broadcast(BLE_CONNECTING_METHOD, VIOD_SIGNATURE);
        }

        @Override
        public void onBLEConnected() {
            isClose = false;

            broadcast(BLE_CONNECTED_METHOD, VIOD_SIGNATURE);
        }

        @Override
        public void onBLEDisConnected(String address) {

            broadcast(BLE_DISCONNECTED_METHOD, STRING_SIGNATURE, address);
            isClose = true;
        }

        @Override
        public void onBLEConnectTimeOut() {

            broadcast(BLE_CONNECT_TIMEOUT_METHOD, VIOD_SIGNATURE);
            isClose = true;
        }

        @Override
        public void onDataSendTimeOut(byte[] data) {

            broadcast(DATA_SEND_TIMEOUT_METHOD, BYTE_ARRAY_SIGNATURE, data);
        }

        @Override
        public boolean onDataReceived(byte[] cmd, byte[] recv) {
            broadcast(DATA_RECEIVE_METHOD, BYTE_ARRAY_SIGNATURE, recv);
            return true;// canSendNextCommand =
                        // mBaseCmd.checkCommandSuccess(cmd, recv);
        }

        @Override
        public void onDataChanged(List<SportDataDay> list) {
            broadcast(DATA_CHANGED_METHOD, LIST_SIGNATURE, list);
        }

        @Override
        public void onWareUpdate(byte statusSuccess) {
            broadcast(ON_WARE_UPDATE_METHOD, BYTE_SIGNATURE, statusSuccess);
        }

        @Override
        public void onBindUnbind(byte statusUnbindSuccess) {
            broadcast(ON_BIND_UNBIND_METHOD, BYTE_SIGNATURE, statusUnbindSuccess);
        }

        @Override
        public void onSettingsSuccess(byte cmdKey, boolean success) {
            broadcast(ON_SETTINGS_SUCCESS, BYTE_BOOLEAN_SIGNATURE, cmdKey, success);
		}

		@Override
		public void onGetInfo(byte cmdKey) {
			broadcast(ON_GET_INFO, BYTE_SIGNATURE, cmdKey);
		}

        @Override
        public void onSyncData(int process) {
            broadcast(ON_SYNC_DATA, INT_SIGNATURE, process);
        }
    };

    private void broadcast(String name, Class<?>[] parameterTypes, Object... args) {
        if (isClose) {
            return;
        }
        synchronized (mCallbacks) {
            DebugLog.e("broadcast [" + name + "] begin.");
            Method method = null;
            try {
                method = ICoreServiceCallback.class.getMethod(name, parameterTypes);
            } catch (SecurityException e) {
            } catch (NoSuchMethodException e) {
            }

            int size = mCallbacks.beginBroadcast();
            for (int i = 0; i < size; i++) {
                try {
                    method.invoke(mCallbacks.getBroadcastItem(i), args);
                } catch (IllegalArgumentException e) {
                } catch (IllegalAccessException e) {
                } catch (InvocationTargetException e) {
                }
            }
            mCallbacks.finishBroadcast();
            DebugLog.e("broadcast end.");
        }
    }
}
