package com.project.library.share;

import android.content.Context;

/** lib与app共享，不存数据库的全部放在这里 */
public class LibSharedPreferences extends CommonPreferences {
	private static final String SP_NAME = "veryfit_multi_app_lib";

	/** 调速 */
	private static final String DEVICE_SYNC_DATA = "device_need_sync_data";
	/** 设备id */
	private static final String DEVICE_ID = "device_id";
	/** 固件版本 */
	private static final String DEVICE_FIRM_WARE_VERSION = "device_firm_ware_version";
	/** 电池电量 */
	private static final String DEVICE_ENERGE = "device_energe";
	/** 支持闹钟最大个数 */
	private static final String DEVICE_ALARM_MAX_COUNT = "device_alarm_max_count";

	public void setDeviceAlarmMaxCount(int alarmMaxCount) {
		setValue(DEVICE_ALARM_MAX_COUNT, alarmMaxCount);
	}

	public int getDeviceAlarmMaxCount() {
		return getValue(DEVICE_ALARM_MAX_COUNT, 10);
	}

	public void setDeviceEnerge(int energe) {
		setValue(DEVICE_ENERGE, energe);
	}

	public int getDeviceEnerge() {
		return getValue(DEVICE_ENERGE, 0);
	}

	public void setDeviceFirmwareVersion(int version) {
		setValue(DEVICE_FIRM_WARE_VERSION, version);
	}

	public int getDeviceFirmwareVersion() {
		return getValue(DEVICE_FIRM_WARE_VERSION, 0);
	}

	public void setDeviceId(int deviceId) {
		setValue(DEVICE_ID, deviceId);
	}

	public int getDeviceId() {
		return getValue(DEVICE_ID, 0);
	}

	/** lib调试用,是否同步数据。不同步数据则只发送总开关请求，不发送正式同步数据请求。默认同步数据 */
	public void setSyncData(boolean isSync) {
		setValue(DEVICE_SYNC_DATA, isSync);
	}

	/** lib调试用,是否同步数据。不同步数据则只发送总开关请求，不发送正式同步数据请求。默认同步数据 */
	public boolean isSyncData() {
		return getValue(DEVICE_SYNC_DATA, true);
	}

	public void init(Context context) {
		super.init(context, SP_NAME);
	}

	private static LibSharedPreferences instance;

	public static final LibSharedPreferences getInstance() {
		if (instance == null) {
			instance = new LibSharedPreferences();
		}
		return instance;
	}

	private LibSharedPreferences() {
	}
}