package com.project.library.entity;

import java.io.Serializable;

public class BleDevice implements Serializable ,Comparable<BleDevice>{
    private static final long serialVersionUID = -5217710157640312976L;
    public String mDeviceName;
    public String mDeviceAddress;// mac addr
    public int mRssi;
    
	@Override
	public int compareTo(BleDevice another) {
		if(mRssi > another.mRssi){
			return -1;
		}else if(mRssi < another.mRssi){
			return 1;
		}else{
			return 0;
		}
	}
}
