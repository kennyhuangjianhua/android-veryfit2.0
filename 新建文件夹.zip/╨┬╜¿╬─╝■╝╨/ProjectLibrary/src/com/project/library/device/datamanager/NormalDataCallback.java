package com.project.library.device.datamanager;

import com.project.library.device.cmd.WareUpdateCmd;

/** 除了健康数据之外，其他数据用到的回调 */
public interface NormalDataCallback {

    /**
     * 固件升级回复
     * 
     * @see WareUpdateCmd#STATUS_SUCCESS
     * @see WareUpdateCmd#STATUS_LOW_BATTERY
     * @see WareUpdateCmd#STATUS_NOT_SUPPORT
     * */
    void onWareUpdate(byte status);

    /** 解绑成功回复 */
    void onUnbinded();
}
