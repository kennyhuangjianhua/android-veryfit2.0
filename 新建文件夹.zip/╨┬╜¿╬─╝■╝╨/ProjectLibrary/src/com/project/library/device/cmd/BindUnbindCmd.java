package com.project.library.device.cmd;

import android.os.Build;

/** 绑定解绑 */
public class BindUnbindCmd extends DeviceBaseCommand {

    private static final byte KEY_BIND = 0x01;
    private static final byte KEY_UNBIND = 0x02;

    private static final byte[] VALUE_BIND = new byte[] { 0x02, (byte) Build.VERSION.SDK_INT, 0x55, (byte) 0xAA };
    private static final byte[] VALUE_UNBIND = new byte[] { 0x55, (byte) 0xAA, 0x55, (byte) 0xAA };

    private static final byte STATUS_SUCCESS = 0x00;

    public static final byte STATUS_BIND_SUCCESS = 0x12;
    public static final byte STATUS_BIND_FAILED = 0x13;
    public static final byte STATUS_UNBIND_SUCCESS = 0x14;
    public static final byte STATUS_UNBIND_FAILED = 0x15;

    /**
     * 绑定命令
     * 
     * @param version
     *            android系统版本号 4.3为18
     * 
     * */
    public byte[] getBindCmd() {

        return createCmd(ID_CMD_BIND_UNBIND, KEY_BIND, VALUE_BIND);
    }

    /**
     * 解除绑定命令
     * */
    public byte[] getUnbindCmd() {

        return createCmd(ID_CMD_BIND_UNBIND, KEY_UNBIND, VALUE_UNBIND);
    }

    /**
     * @return 绑定/解绑成功失败 ,one of {@link #STATUS_BIND_SUCCESS} ,
     *         {@link#STATUS_BIND_FAILED} ,{@link #STATUS_UNBIND_SUCCESS} ,
     *         {@link #STATUS_UNBIND_FAILED}
     * 
     * */
    public byte parse(byte[] data) {
        // byte0 cmd_id
        // byte1 key
        byte key = getCmdKey(data);
        // byte2 status
        byte status = data[2];
        if (key == KEY_BIND) {
            return status == STATUS_SUCCESS ? STATUS_BIND_SUCCESS : STATUS_BIND_FAILED;
        } else /* if (key == KEY_UNBIND) */{
            return status == STATUS_SUCCESS ? STATUS_UNBIND_SUCCESS : STATUS_UNBIND_FAILED;
        }
    }

    public static synchronized BindUnbindCmd getInstance() {
        if (mInstance == null) {
            mInstance = new BindUnbindCmd();
        }
        return mInstance;
    }

    private BindUnbindCmd() {

    }

    private static BindUnbindCmd mInstance = null;
}
