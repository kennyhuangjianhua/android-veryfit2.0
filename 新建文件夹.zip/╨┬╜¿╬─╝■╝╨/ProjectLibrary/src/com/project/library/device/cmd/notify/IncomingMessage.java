package com.project.library.device.cmd.notify;

/** 信息[暂时不做] */
public class IncomingMessage {
    public String phoneNumber;
    public String contactName;
}
