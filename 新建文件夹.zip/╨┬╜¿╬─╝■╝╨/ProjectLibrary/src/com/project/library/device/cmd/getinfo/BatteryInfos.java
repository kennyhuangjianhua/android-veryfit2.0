package com.project.library.device.cmd.getinfo;

/** 电池信息 */
public class BatteryInfos {

    /** 电池类型 */
    public int type;
    /** 电池电压 */
    public int voltage;
    /** 电池状态 */
    public int status;
    /** 电量 等级*/
    public int level;
    /** 距离上次充电使用时长 */
    public int cur_use_time;
    /** 手环使用寿命 */
    public int total_use_time;
}
