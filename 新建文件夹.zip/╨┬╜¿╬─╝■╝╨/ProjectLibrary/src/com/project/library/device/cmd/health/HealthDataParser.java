package com.project.library.device.cmd.health;

import com.project.library.util.ByteDataConvertUtil;

public class HealthDataParser {
	/** 准备接收数据 */
	private boolean isPrepared = false;
	/** 包的总数量(暂不支持) */
	@SuppressWarnings("unused")
	private int packageAllTotal = 0;
	/** 运动数据总天数 */
	private int activeDays = 0;
	/** 睡眠数据总天数 */
	private int sleepDays = 0;
	/** 同步数据百分比 */
	private int mPercent = 0;

	/** 健康数据key */
	private byte mKey = HealthDataCmd.KEY_ERROR;

	private HealthDataCmd mHealthDataCmd = HealthDataCmd.getInstance(HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_TODAY);

	/** 解析开始同步数据返回的数据 */
	public void parseStartData(byte[] receive) {
		// 0 1 cmd_id key
		int index_start = 2;
		// value:byte0 byte1
		packageAllTotal = ByteDataConvertUtil.toRevInt(receive, index_start + 0, 2);
		// value:byte2
		activeDays = ByteDataConvertUtil.Byte2Int(receive[index_start + 2]);
		// value:byte3
		sleepDays = ByteDataConvertUtil.Byte2Int(receive[index_start + 3]);

		isPrepared = true;
	}

	public void changeParser(byte key) {
		if (mKey != key) {
			if (key == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_TODAY || key == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_HISTORY || key == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_TODAY || key == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_HISTORY) {
				mHealthDataCmd = HealthDataCmd.getInstance(key);
				mKey = key;
			}
		}
	}

	/** 接收数据准备工作是否已准备好(是否收到app请求同步数据的返回) */
	public boolean isPrepared() {
		return isPrepared;
	}

	/** 是否接收到当天数据的头部信息 */
	public boolean isHeadReceived() {
		return mHealthDataCmd.isHeadReceived();
	}

	/**
	 * @param receive
	 * @return 是否为头部
	 */
	public boolean isHeader(byte[] receive) {
		return mHealthDataCmd.isHeader(receive);
	}

	/**
	 * 解析头部
	 */
	public void parseHeader(byte[] header) {
		mHealthDataCmd.parseHeader(header);
	}

	/**
	 * 接收健康数据。解析数据头部，并保存待解析的数据
	 * 
	 * @return 整体数据百分比
	 * */
	public int receiveHealthData(byte[] receiveData) {
		if (!isPrepared) {
			return 0;
		}

		int percent = mHealthDataCmd.receiveHealthData(receiveData);
		if (percent == 100) {
			mPercent += 100;
			percent = 0;
		}

		// 天数加一是因为是历史数据天数，需要加上当天的。睡眠数据可能没有，所以百分比可能会跳跃，后面最好是算上全部数据天数比较好
		float total = (activeDays + 1) + (sleepDays + 1);
		return (int) Math.min((mPercent + percent) / total, 98);// 最大百分之98,防止错误。在百分比100的时候有结束指令
	}

	/** 当前这一天的运动数据或者睡眠数据是否接收完成 ,大于0则为丢包的序列号 */
	public int checkDataSuccess() {
		if (mHealthDataCmd != null) {
			return mHealthDataCmd.checkDataSuccess();
		}
		return 0;
	}

	/** 数据接收完整后解析数据 */
	public void parse() {
		if (mHealthDataCmd != null) {
			mHealthDataCmd.parse();
		}
	}

	/** 清除数据等 */
	public void clear() {
		mKey = HealthDataCmd.KEY_ERROR;
		isPrepared = false;
		activeDays = 0;
		sleepDays = 0;
		mPercent = 0;
	}

	/**
	 * 头部全部为0，没数据了
	 */
	public boolean checkHeaderWithoutData(byte[] receive) {
		if (mHealthDataCmd != null) {
			return mHealthDataCmd.checkHeaderWithoutData(receive);
		}
		return false;
	}

	/** 判断当前数据是否有正常数据(头部全部为不为0) */
	public boolean headerWithoutData() {
		if (mHealthDataCmd != null) {
			return mHealthDataCmd.headerWithoutData();
		}
		return false;
	}
}
