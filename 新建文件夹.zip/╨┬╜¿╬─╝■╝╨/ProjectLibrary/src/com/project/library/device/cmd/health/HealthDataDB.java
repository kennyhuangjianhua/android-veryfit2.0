package com.project.library.device.cmd.health;

import java.util.ArrayList;
import java.util.List;
import com.project.library.database.DaoSession;
import com.project.library.database.SleepDataDay;
import com.project.library.database.SleepDataDayDao;
import com.project.library.database.SleepDataItem;
import com.project.library.database.SleepDataItemDao;
import com.project.library.database.SportDataDay;
import com.project.library.database.SportDataDayDao;
import com.project.library.database.SportDataItem;
import com.project.library.database.SportDataItemDao;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;

/** 模拟加载1年数据进数据库 */
public class HealthDataDB {

	public void addHealthDBs() {
		long date = 20150728;
		for (int i = 0; i < 366; i++) {
			date = LongDateUtil.sub(20150728, i);
			addSportDB(date);
			addSleepDB(date);
		}
		DebugLog.e("数据添加完成");
	}

	private void addSportDB(long date) {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		SportDataItemDao itemDao = daoSession.getSportDataItemDao();

		List<SportDataItem> entities = new ArrayList<SportDataItem>();

		int hour = 0;
		int minute = 0;
		for (int serial = 1; serial <= 96; serial++) {
			if (minute >= 60) {
				hour += 1;
				minute = 0;
			}

			SportDataItem entity = new SportDataItem();

			entity.setDate(date);
			entity.setHour(hour);
			entity.setMinute(minute);
			entity.setMode(1);
			entity.setStepCount(11);
			entity.setActiveTime(11);
			entity.setCalory(11);
			entity.setDistance(11);

			entities.add(entity);

			minute += 15;
		}

		itemDao.insertInTx(entities);

		// 更新或插入每天总数据
		SportDataDayDao sportDao = daoSession.getSportDataDayDao();
		SportDataDay sport = new SportDataDay();
		sport.setDate(date);
		sport.setTotalstepCount(111);
		sport.setTotalCalory(111);
		sport.setTotalDistance(111);
		sport.setTotalActiveTime(111);
		sportDao.insert(sport);
	}

	private void addSleepDB(long date) {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		SleepDataItemDao itemDao = daoSession.getSleepDataItemDao();

		List<SleepDataItem> entities = new ArrayList<SleepDataItem>();

		for (int serial = 1; serial <= 24; serial++) {
			SleepDataItem entity = new SleepDataItem();
			entity.setDate(date);
			entity.setSleepStatus(1);
			entity.setSleepMinutes(2);
			entities.add(entity);
		}
		itemDao.insertInTx(entities);

		SleepDataDayDao sleepDao = daoSession.getSleepDataDayDao();
		SleepDataDay sleep = new SleepDataDay();
		sleep.setDate(date);
		sleep.setEndTimeHour(1);
		sleep.setEndTimeMinute(2);
		sleep.setTotalSleepMinutes(3);
		sleep.setLightSleepCount(4);
		sleep.setDeepSleepCount(5);
		sleep.setAwakeCount(6);
		sleep.setLightSleepMinutes(7);
		sleep.setDeepSleepMinutes(8);
		sleepDao.insert(sleep);

	}
}
