package com.project.library.device.cmd.health;

/** 同步数据结束 */
public class HealthSyncSuccess extends HealthDataCmd {

    /**
     * @param flag
     *            前后台同步 {@link #FLAG_FOREGROUND} ,{@link #FLAG_BACKGROUND}
     * @param modesafe
     *            同步数据模式 {@link #MODE_SAFE} ,{@link #MODE_OTHER}
     * 
     * */
    public byte[] getHealthSyncSuccessCmd(byte flag, byte modesafe) {
        byte[] value = new byte[] { flag, modesafe };
        return createCmd(KEY_SYNC_SUCCESS, value);
    }

    public static synchronized HealthSyncSuccess getInstance() {
        if (mInstance == null) {
            mInstance = new HealthSyncSuccess();
        }
        return mInstance;
    }

    private HealthSyncSuccess() {

    }

    private static HealthSyncSuccess mInstance = null;
}
