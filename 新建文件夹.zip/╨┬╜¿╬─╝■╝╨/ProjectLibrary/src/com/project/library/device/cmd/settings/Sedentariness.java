package com.project.library.device.cmd.settings;

/** 久坐提醒 */
public class Sedentariness {

    public int startHour;
    public int startMinute;

    public int endHour;
    public int endMinute;
    /** 时间间隔 */
    public int interval;
    /** 重复和开关 */
    public int repetitions;
}
