package com.project.library.device.cmd.getinfo;

/** mac地址 */
public class MacAddressInfos {

    public String mac;

}
