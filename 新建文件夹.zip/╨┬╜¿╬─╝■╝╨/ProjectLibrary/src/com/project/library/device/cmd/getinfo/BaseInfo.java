package com.project.library.device.cmd.getinfo;

public class BaseInfo {
    /** 设备运行模式,运动 */
    public static final int MODE_SPORT = 0x00;
    /** 设备运行模式,睡眠 */
    public static final int MODE_SLEEP = 0x01;

    /** 设备电池状态，正常 */
    public static final int STATUS_BATTERY_NORMAL = 0x00;
    /** 设备电池状态，充电 */
    public static final int STATUS_BATTERY_CHARGE = 0x01;
    /** 设备电池状态，充满 */
    public static final int STATUS_BATTERY_FULL = 0x02;
    /** 设备电池状态，低电量 */
    public static final int STATUS_BATTERY_LOW = 0x03;

    /** 绑定标志，绑定 */
    public static final int PAIR_FLAG_BIND = 0x01;
    /** 绑定标志，解绑 */
    public static final int PAIR_FLAG_UNBIND = 0x00;

    /** 不支持功能 */
    public static final int FUNCTION_NO = 0x00;
    /** 支持功能 */
    public static final int FUNCTION_OK = 0x01;

    /** 锂电池 */
    public static final int TYPE_BATTERY_LI = 0x00;
    /** 纽扣电池 */
    public static final int TYPE_BATTERY_OTHER = 0x01;
}
