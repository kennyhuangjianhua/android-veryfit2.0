package com.project.library.device.cmd.getinfo;

/** 时间信息 */
public class TimeInfos {

    public int year;
    public int month;
    public int day;
    public int hour;
    public int minute;
    public int second;
    public int weekday;

}
