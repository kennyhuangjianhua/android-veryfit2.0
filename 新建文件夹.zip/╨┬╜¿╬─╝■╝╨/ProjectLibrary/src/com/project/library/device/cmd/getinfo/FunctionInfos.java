package com.project.library.device.cmd.getinfo;

/** 设备支持功能列表 */
public class FunctionInfos {

    // 主要功能
    /** 计步 */
    public boolean stepCalculation;
    /** 睡眠监测 */
    public boolean sleepMonitor;
    /** 单次运动 */
    public boolean singleSport;
    /** 实时数据 */
    public boolean realtimeData;
    /** 设备更新 */
    public boolean deviceUpdate;

    // 闹钟个数
    /** 闹钟个数 */
    public int alarmCount;

    // 闹钟提醒支持类型
    /** 起床 */
    public boolean wakeUp;
    /** 睡觉 */
    public boolean sleep;
    /** 锻炼 */
    public boolean sport;
    /** 吃药 */
    public boolean medicine;
    /** 约会 */
    public boolean dating;
    /** 聚会 */
    public boolean party;
    /** 会议 */
    public boolean metting;
    /** 自定义 */
    public boolean custom;

    // 控制功能
    /** 拍照 */
    public boolean takePhoto;
    /** 音乐 */
    public boolean music;

    // 来电提醒功能
    /** 来电提醒 */
    public boolean calling;
    /** 来电联系人 */
    public boolean callingContact;
    /** 来电号码 */
    public boolean callingNum;

    // 信息提醒功能
    /** 短信 */
    public boolean message;
    /** 邮件 */
    public boolean email;
    /** QQ */
    public boolean qq;
    /** 微信 */
    public boolean weixin;
    /** 新浪微博 */
    public boolean sinaWeibo;
    /** facebook */
    public boolean facebook;
    /** twitter */
    public boolean twitter;

    // 其他功能
    /** 久坐提醒 */
    public boolean sedentariness;
    /** 防丢提醒 */
    public boolean antilost;
    /** 一键呼叫 */
    public boolean onetouchCalling;
    /** 寻找手机 */
    public boolean findPhone;
    /** 寻找手环 */
    public boolean findDevice;

}
