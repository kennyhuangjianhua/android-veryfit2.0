package com.project.library.device.cmd;

/** 固件升级 */
public class WareUpdateCmd extends DeviceBaseCommand {

    public static final byte KEY = 0x01;
    public static final byte[] VALUE = new byte[] { 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA };

    public static final byte STATUS_SUCCESS = 0x00;
    public static final byte STATUS_LOW_BATTERY = 0x01;
    public static final byte STATUS_NOT_SUPPORT = 0x02;

    /** 升级状态码在数据中的位置 */
    private static final int STATUS_INDEX = 2;

    private static final byte[] BYTES_CMD = new byte[] { ID_CMD_WARE_UPDATE, KEY, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0, 0, 0, 0, 0, 0 };

    public byte[] getWareUpdateCmd() {

        return BYTES_CMD;
    }

    /**
     * @return 升级状态码 ,one of {@link #STATUS_SUCCESS} ,
     *         {@link#STATUS_LOW_BATTERY} ,{@link #STATUS_NOT_SUPPORT}
     * 
     * */
    public byte parse(byte[] data) {
        return data[STATUS_INDEX];
    }

    public static synchronized WareUpdateCmd getInstance() {
        if (mInstance == null) {
            mInstance = new WareUpdateCmd();
        }
        return mInstance;
    }

    private WareUpdateCmd() {

    }

    private static WareUpdateCmd mInstance = null;
}
