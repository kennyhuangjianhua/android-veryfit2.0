package com.project.library.device.cmd.notify;

import com.project.library.device.cmd.DeviceBaseCommand;

/** 提醒命令 */
public class NotifyCmd extends DeviceBaseCommand {

    public static final byte KEY_INCOMING_CALLING = 0x01;
    public static final byte KEY_INCOMING_CALLING_STATUS = 0x02;
    public static final byte KEY_INCOMING_MESSAGE = 0x03;

    /** 来电提醒 */
    public byte[] getIncomingCallCmd(IncomingCall message) {
        // byte[] value = new byte[BYTE_LEN_DATA];
        byte[] value = new byte[] { 1, 1, 1, 1, 1, 1 };
        return createCmd(ID_CMD_NOTIFY, KEY_INCOMING_CALLING, value);
    }

    /**
     * 来电状态提醒
     * 
     * @param status
     *            {@link IncomingCall#INCOMING_CALL_STATUS_ACCEPT},
     *            {@link IncomingCall#INCOMING_CALL_STATUS_REFUSE}
     * */
    public byte[] getIncomingCallStatusCmd(byte status) {
        return createCmd(ID_CMD_NOTIFY, KEY_INCOMING_CALLING_STATUS, status);
    }

    /** 信息提醒 */
    public byte[] getIncomingMessageCmd() {
        byte[] value = new byte[BYTE_LEN_DATA];
        return createCmd(ID_CMD_NOTIFY, KEY_INCOMING_MESSAGE, value);
    }

    public static synchronized NotifyCmd getInstance() {
        if (mInstance == null) {
            mInstance = new NotifyCmd();
        }
        return mInstance;
    }

    private NotifyCmd() {

    }

    private static NotifyCmd mInstance = null;
}
