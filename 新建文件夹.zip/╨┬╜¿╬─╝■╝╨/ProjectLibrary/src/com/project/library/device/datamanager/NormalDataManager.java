package com.project.library.device.datamanager;

import com.project.library.device.cmd.BindUnbindCmd;
import com.project.library.device.cmd.DeviceBaseCommand;
import com.project.library.device.cmd.DeviceRestartCmd;
import com.project.library.device.cmd.WareUpdateCmd;
import com.project.library.device.cmd.getinfo.GetInfoCmd;
import com.project.library.device.cmd.settings.SettingsCmd;
import com.project.library.protocol.AppBleNotifyListener;
import com.project.library.util.ByteDataConvertUtil;
import com.project.library.util.DebugLog;

public class NormalDataManager extends BaseDataManager {
    private NormalDataCallback mNormalDataCallback = null;
    /** 最后接收到的设备操作app指令 */
    protected byte[] mDeviceCtrolLastReceive = new byte[DeviceBaseCommand.BYTE_LEN_TOTAL];

    public void init(AppBleNotifyListener listener, NormalDataCallback callBack) {
        super.init(listener);
        mNormalDataCallback = callBack;
    }

    @Override
    public boolean isNeedReply(byte[] cmd) {
        return DeviceBaseCommand.isNeedReply(cmd);
    }

    @Override
    public void onCommandWriteSuccess(byte[] data) {
        super.onCommandWriteSuccess(data);
        // 假如当前是回复设备主动向app发送的指令，则允许下一条指令发送
        if (DeviceBaseCommand.isDeciveCtrol(data)) {
            mWriteHandler.removeCallbacks(mWriteRunnable);
            canWriteNext = true;
        }
    }

    @Override
    public void receive(byte[] data, String address) {
        dealNormal(data, address);
    }

    /** 接收除了健康数据之外的正常数据 */
    private synchronized void dealNormal(final byte[] value, final String address) {
        mReceiveHandler.post(new Runnable() {

            @Override
            public void run() {
                String str = ByteDataConvertUtil.bytesToHexString(value);
                DebugLog.e("收到普通数据\n" + str);
                if (DeviceBaseCommand.isDeciveCtrol(value)) {
                    switch (DeviceBaseCommand.getCmdId(value)) {
                        case DeviceBaseCommand.ID_CMD_BLE_CONTROL: {
                            System.out.println("XXXXXXXXXXXXID_CMD_BLE_CONTROL");
                            // 有可能需要优先级判断
                            // 收到ble发过来的指令，通知app相应的操作；然后回复ble
                            // 这里有可能需要判读比如单双击指令是否重复[有可能需要单独的属性来保存]
                            canWriteNext = true;
                            write(value);

                            DeviceBaseCommand.copy(value, mDeviceCtrolLastReceive);
                        }
                            break;
                        default:
                            break;
                    }
                } else if (DeviceBaseCommand.isNeedReply(mLastCommand)) {
                    // 返回数据正确，取消数据重发机制
                    byte cmdId = DeviceBaseCommand.getCmdId(value);
                    if (DeviceBaseCommand.getCmdId(mLastCommand) == cmdId) {
                        mWriteHandler.removeCallbacks(mWriteRunnable);
                    }
                    switch (cmdId) {
                        case DeviceBaseCommand.ID_CMD_WARE_UPDATE: {
                            receivedWareUpdateData(value);
                        }
                            break;
                        case DeviceBaseCommand.ID_CMD_GET_INFO: {
                            receivedGetInfoData(value);
                        }
                            break;
                        case DeviceBaseCommand.ID_CMD_SETTINGS: {
                            receivedSettingsData(value);
                        }
                            break;
                        case DeviceBaseCommand.ID_CMD_BIND_UNBIND: {
                            receivedBindUnbindData(value);
                        }
                            break;
                        case DeviceBaseCommand.ID_CMD_NOTIFY: {
                            receivedNotifyData(value);
                        }
                            break;
                        case DeviceBaseCommand.ID_CMD_DEVICE_RESTART: {
                            receivedRestartData(value);
                        }
                            break;
                        default:
                            break;
                    }
                } else {
                    DebugLog.e("other command/value");
                }

                DeviceBaseCommand.copy(value, mLastReceive);
            }
        });
    }

    /** 收到固件升级命令的返回 */
    private void receivedWareUpdateData(byte[] value) {
        DebugLog.e("收到升级指令的返回");
        WareUpdateCmd cmd = WareUpdateCmd.getInstance();
        byte status = cmd.parse(value);
        if (mNormalDataCallback != null) {
            mNormalDataCallback.onWareUpdate(status);
        }
    }

    /** 收到获取命令命令的返回 */
    private void receivedGetInfoData(byte[] value) {
        GetInfoCmd cmd = GetInfoCmd.getInstance();
        cmd.parse(value);
        canWriteNext = true;
        if (mAppBleNotifyListener != null) {
             mAppBleNotifyListener.onGetInfo(DeviceBaseCommand.getCmdKey(value));
        }
    }

    /** 收到设置命令的返回 */
    private void receivedSettingsData(byte[] receive) {
        canWriteNext = true;
        SettingsCmd cmd = SettingsCmd.getInstance();
        if (mAppBleNotifyListener != null) {
            mAppBleNotifyListener.onSettingsSuccess(DeviceBaseCommand.getCmdKey(receive), cmd.parse(receive));
        }
    }

    private void receivedBindUnbindData(byte[] value) {
        BindUnbindCmd cmd = BindUnbindCmd.getInstance();
        byte status_code = cmd.parse(value);

        canWriteNext = true;

        if (status_code == BindUnbindCmd.STATUS_UNBIND_SUCCESS) {
            if (mNormalDataCallback != null) {
                mNormalDataCallback.onUnbinded();
            }
        } else {
            if (mAppBleNotifyListener != null) {
                mAppBleNotifyListener.onBindUnbind(status_code);
            }
        }
    }

    /** 提醒命令 */
    private void receivedNotifyData(byte[] value) {

    }

    /** 设备重启 */
    private void receivedRestartData(byte[] value) {
        DeviceRestartCmd cmd = DeviceRestartCmd.getInstance();
        byte status_code = cmd.parse(value);

        canWriteNext = true;

        // 要通知APP
        if (status_code == DeviceRestartCmd.STATUS_SUCCESS) {
            DebugLog.d("设备马上重启。");
        } else {
            DebugLog.d("设备重启不了哦。");
        }
    }
}
