package com.project.library.device.cmd.settings;

/** 运动目标 、睡眠目标等 */
public class MultiTarget {

    /** 步数 */
    public static final byte TYPE_STEP = 0x00;
    /** 卡路里 */
    public static final byte TYPE_CAL = 0x01;
    /** 距离 */
    public static final byte TYPE_DIS = 0x02;

    /**
     * 运动目标类型 {@link #TYPE_STEP},{@link #TYPE_CAL},{@link #TYPE_DIS}
     * */
    public byte sportType;
    /** 运动目标 */
    public int sportTarget;

    /** 有睡眠 */
    public static final byte FLAG_SLEEP_NORMAL = 0x00;
    /** 无睡眠 */
    public static final byte FLAG_SLEEP_OTHER = 0x01;

    /**
     * 有无睡眠标志位 {@link #FLAG_SLEEP_NORMAL},{@link #FLAG_SLEEP_OTHER}
     * */
    public byte sleepFlag;
    /** 睡眠目标小时 */
    public int sleepHour;
    /** 睡眠目标分钟 */
    public int sleepMinute;

}
