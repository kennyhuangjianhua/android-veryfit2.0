package com.project.library.device.cmd.health;

/** 同步数据开始 */
public class HealthSyncRequest extends HealthDataCmd {

    /**
     * @param flag
     *            前后台同步 {@link #FLAG_FOREGROUND} ,{@link #FLAG_BACKGROUND}
     * @param modesafe
     *            同步数据模式 {@link #MODE_SAFE} ,{@link #MODE_OTHER}
     * 
     * */
    public byte[] getHealthSyncRequestCmd(byte flag, byte modesafe) {
        byte[] value = new byte[] { flag, modesafe };
        return createCmd(KEY_SYNC_REQUEST, value);
    }

    public static synchronized HealthSyncRequest getInstance() {
        if (mInstance == null) {
            mInstance = new HealthSyncRequest();
        }
        return mInstance;
    }

    private HealthSyncRequest() {

    }

    private static HealthSyncRequest mInstance = null;
}
