package com.project.library.device.cmd.health;

import java.util.ArrayList;
import java.util.List;
import com.project.library.database.StatisticalData;
import com.project.library.database.StatisticalDataFactory;
import com.project.library.device.cmd.DeviceBaseCommand;
import com.project.library.util.ByteDataConvertUtil;

/** 健康数据(运动数据，睡眠数据、其他数据) */
public abstract class HealthDataCmd extends DeviceBaseCommand {

	public static final byte KEY_ERROR = (byte) 0xFF;
	/** 同步数据请求 */
	public static final byte KEY_SYNC_REQUEST = 0x01;
	/** 同步数据结束 */
	public static final byte KEY_SYNC_SUCCESS = 0x02;
	/** 同步当前的运动详情 */
	public static final byte KEY_SYNC_SPORTS_DETAILS_TODAY = 0x03;
	/** 同步当天的睡眠数据 */
	public static final byte KEY_SYNC_SLEEP_DETAILS_TODAY = 0x04;
	/** 同步历史的运动详情 */
	public static final byte KEY_SYNC_SPORTS_DETAILS_HISTORY = 0x05;
	/** 同步历史的睡眠数据 */
	public static final byte KEY_SYNC_SLEEP_DETAILS_HISTORY = 0x06;
	/** 一次发送完成(设备向app发送某天的某类型数据结束) */
	public static final byte KEY_DATA_SEND_FINISHED = (byte) 0xEE;

	// 同步健康数据状态
	/** 开始 */
	public static final byte SYNC_STATUS_START = 0x01;
	/** 结束 */
	public static final byte SYNC_STATUS_END = 0x02;
	/** 重发 */
	public static final byte SYNC_STATUS_RESEND = 0x03;

	// 同步类型
	/** 手动同步 */
	public static final byte FLAG_FOREGROUND = 0x01;
	/** 后台同步 */
	public static final byte FLAG_BACKGROUND = 0x02;

	// 同步数据模式
	/** 安全模式 */
	public static final byte MODE_SAFE = 0x01;
	/** 其他模式 */
	public static final byte MODE_OTHER = 0x00;

	/**
	 * @param key
	 * @return
	 */
	public static HealthDataCmd getInstance(int key) {
		if (key == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_TODAY || key == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_HISTORY) {
			return Sports.getInstance();
		} else if (key == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_TODAY || key == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_HISTORY) {
			return Sleep.getInstance();
		}
		return null;
	}

	protected byte[] createCmd(byte key, byte value) {
		return createCmd(ID_CMD_HEALTH_DATA, key, value);
	}

	protected byte[] createCmd(byte key, byte[] value) {
		return createCmd(ID_CMD_HEALTH_DATA, key, value);
	}

	public boolean isHeadReceived() {
		return false;
	}

	/**
	 * @param receive
	 * @return 是否为头部[都有两个头部]
	 */
	public boolean isHeader(byte[] receive) {
		return false;
	}

	/**
	 * 解析头部
	 */
	public void parseHeader(byte[] header) {

	}

	/**
	 * 接收健康数据。处理非头部数据，并保存待解析的数据
	 * 
	 * @return 当前数据百分比
	 * */
	public int receiveHealthData(byte[] receiveData) {
		return 0;
	}

	/** 当前这一天的运动数据或者睡眠数据是否接收完成 ,大于0则为丢包的序列号 */
	public int checkDataSuccess() {
		return 0;
	}

	/** 数据接收完整后解析数据 */
	public void parse() {
	}

	/** 头部全部为0，没数据了 */
	public boolean checkHeaderWithoutData(byte[] bytes) {
		int headerLen = getHeaderLen();
		byte[] header = new byte[headerLen];
		// 跳过4个字节
		int index = 4;
		ByteDataConvertUtil.BinnCat(bytes, header, index, headerLen);
		for (byte b : header) {
			if (b != 0x00) {
				return false;
			}
		}

		return true;
	}

	/** 判断当前数据是否有正常数据(头部全部为不为0) */
	public boolean headerWithoutData() {
		return true;
	}

	/**
	 * 获取头部长度
	 * */
	public int getHeaderLen() {
		return 0;
	}

	/**
	 * @param update
	 *            true更新数据，false插入。update时总天数不能加1
	 * 
	 *            更新周月年的总数据,主要为运动
	 */
	protected void makeUpdateSportStatisticalDatas(boolean update, long date, float totalDistance, long totalStep, long totalCalory) {
		List<StatisticalData> newData = new ArrayList<StatisticalData>();
		for (int i = 0; i < 3; i++) {
			StatisticalData data = StatisticalDataFactory.createData(date, i);
			data.setHealthType(StatisticalData.HEALTH_TYPE_SPORT);
			data.setTotalDistance(totalDistance);
			data.setTotalStep(totalStep);
			data.setTotalCalory(totalCalory);
			newData.add(data);
		}

		StatisticalDataFactory.update(update, date, StatisticalData.HEALTH_TYPE_SPORT, newData);
	}

	/**
	 * @param update
	 *            true更新数据，false插入。update时总天数不能加1
	 * 
	 *            更新周月年的总数据，主要为睡眠
	 */
	protected void makeUpdateSleepStatisticalDatas(boolean update, long date, long totalSleep, long totalDeepSleep, long totalLightSleep, long totalFallSleep, long totalAwakeTime, long totalAwakeDuration) {
		List<StatisticalData> newData = new ArrayList<StatisticalData>();
		for (int i = 0; i < 3; i++) {
			StatisticalData data = StatisticalDataFactory.createData(date, i);
			data.setHealthType(StatisticalData.HEALTH_TYPE_SLEEP);
			data.setTotalSleep(totalSleep);
			data.setTotalDeepSleep(totalDeepSleep);
			data.setTotalLightSleep(totalLightSleep);
			data.setTotalFallSleep(totalFallSleep);
			data.setTotalAwakeTime(totalAwakeTime);
			data.setTotalAwakeDuration(totalAwakeDuration);
			newData.add(data);
		}

		StatisticalDataFactory.update(update, date, StatisticalData.HEALTH_TYPE_SLEEP, newData);
	}
}
