package com.project.library.device.cmd.getinfo;

/** 设备基本信息 */
public class BasicInfos {

    public int deivceId;
    public int firmwareVersion;
    /** 运行模式。运动、睡眠 */
    public int mode;
    /** 电池状态 */
    public int battStatus;
    /** 电量 */
    public int energe;
    /** 绑定标志 */
    public int pairFlag;

}
