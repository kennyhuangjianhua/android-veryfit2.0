package com.project.library.device.cmd;

import com.project.library.util.ArrayUtils;

public abstract class DeviceBaseCommand {
    private static final byte ERROR = -1;

    public static final int BYTE_LEN_TOTAL = 20;
    public static final int BYTE_LEN_DATA = 18;

    public static final byte ID_CMD_WARE_UPDATE = 0x01;// 固件升级命令
    public static final byte ID_CMD_GET_INFO = 0x02;// 获取命令
    public static final byte ID_CMD_SETTINGS = 0x03;// 设置命令
    public static final byte ID_CMD_BIND_UNBIND = 0x04;// 绑定解绑命令
    public static final byte ID_CMD_NOTIFY = 0x05;// 提醒命令
    public static final byte ID_CMD_APP_CONTROL = 0x06;// app控制命令
    public static final byte ID_CMD_BLE_CONTROL = 0x07;// ble控制命令
    public static final byte ID_CMD_HEALTH_DATA = 0x08;// 健康数据命令
    public static final byte ID_CMD_DUMP_STACK = 0x20;// 数据发生错误(dump stack)
    public static final byte ID_CMD_LOG = 0x21;// 日志命令
    public static final byte ID_CMD_FACTORY = (byte) 0xAA;// 工厂测试命令
    public static final byte ID_CMD_DEVICE_RESTART = (byte) 0xF0;// 设备重启命令

    protected static final int INDEX_COMMAND_ID = 0;// commandId在命令中的位置
    protected static final int INDEX_KEY = INDEX_COMMAND_ID + 1;// commandId下各种key在命令中的位置

    private static final byte[] REPLYS = new byte[] { ID_CMD_WARE_UPDATE, ID_CMD_GET_INFO, ID_CMD_SETTINGS, ID_CMD_BIND_UNBIND, ID_CMD_NOTIFY, ID_CMD_APP_CONTROL, ID_CMD_HEALTH_DATA, ID_CMD_DUMP_STACK, ID_CMD_LOG, ID_CMD_FACTORY, ID_CMD_DEVICE_RESTART };
    private static final byte[] DEVICE_CTROLS = new byte[] { ID_CMD_BLE_CONTROL };

    protected byte[] createCmd(byte cmdId, byte key, byte value) {
        byte[] cmd = createNullCmd();
        cmd[INDEX_COMMAND_ID] = cmdId;
        cmd[INDEX_KEY] = key;
        cmd[INDEX_KEY + 1] = value;

        return cmd;
    }

    protected byte[] createCmd(byte cmdId, byte key, byte[] value) {
        byte[] cmd = createNullCmd();
        cmd[INDEX_COMMAND_ID] = cmdId;
        cmd[INDEX_KEY] = key;
        int index = INDEX_KEY + 1;
        for (byte b : value) {
            cmd[index++] = b;
            if (index >= BYTE_LEN_TOTAL) {
                break;
            }
        }

        return cmd;
    }

    private byte[] createNullCmd() {
        byte[] cmd = new byte[BYTE_LEN_TOTAL];
        for (int i = 0; i < BYTE_LEN_TOTAL; i++) {
            cmd[i] = 0x00;
        }
        return cmd;
    }

    public static boolean isHealthCmd(byte[] cmd) {

        return getCmdId(cmd) == ID_CMD_HEALTH_DATA;
    }

    /** app向设备发送命令，当前命令是否需要回复 */
    public static boolean isNeedReply(byte[] cmd) {
        boolean b = false;
        if (cmd != null && ArrayUtils.contains(REPLYS, getCmdId(cmd))) {
            b = true;
        }
        return b;
    }

    /** 是否为设备向APP主动发送的命令 */
    public static boolean isDeciveCtrol(byte[] cmd) {
        boolean b = false;
        if (cmd != null && ArrayUtils.contains(DEVICE_CTROLS, getCmdId(cmd))) {
            b = true;
        }

        return b;
    }

    public static byte getCmdId(byte[] cmd) {
        byte id = ERROR;
        if (cmd != null && cmd.length == BYTE_LEN_TOTAL) {
            id = cmd[INDEX_COMMAND_ID];
        }

        return id;
    }

    public static byte getCmdKey(byte[] cmd) {
        byte key = ERROR;
        if (cmd != null && cmd.length == BYTE_LEN_TOTAL) {
            key = cmd[INDEX_KEY];
        }

        return key;
    }

    public static boolean isCmdEquals(byte[] cmd, byte[] rcmd) {
        if (cmd == null || rcmd == null) {
            return false;
        }

        for (int i = 0; i < BYTE_LEN_TOTAL; i++) {
            if (cmd[i] != rcmd[i]) {
                return false;
            }
        }

        return true;
    }

    public static void copy(byte[] from, byte[] to) {
        if (from == null || to == null) {
            return;
        }

        int lenFrom = from.length;
        int lenTo = to.length;

        lenFrom = lenFrom < lenTo ? lenFrom : lenTo;

        for (int i = 0; i < lenFrom; i++) {
            to[i] = from[i];
        }
    }
}
