package com.project.library.device.cmd.health;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import com.project.library.database.DaoSession;
import com.project.library.database.SleepDataDay;
import com.project.library.database.SleepDataDayDao;
import com.project.library.database.SportDataDay;
import com.project.library.database.SportDataDayDao;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;

import de.greenrobot.dao.query.QueryBuilder;

import android.os.Handler;
import android.os.HandlerThread;

/** 详情数据缓存 */
public class HealthDataDetailsCache {

	private Handler mHandler = null;
	private HandlerThread mHandlerThread = null;

	private HashMap<Long, SportDataDay> mSportMap = new HashMap<Long, SportDataDay>();
	private HashMap<Long, SleepDataDay> mSleepMap = new HashMap<Long, SleepDataDay>();
	private long minDate = LongDateUtil.Calendar2LongDate(Calendar.getInstance());

	private Runnable mRunnable = new Runnable() {

		@Override
		public void run() {
			get();
		}
	};

	private void get() {
		List<SportDataDay> sportList = getSportDataDayAllList();
		for (SportDataDay sportDataDay : sportList) {
			updateHealthDataDay(sportDataDay.getDate(), sportDataDay);
		}
		List<SleepDataDay> sleepList = getSleepDataDayAllList();
		for (SleepDataDay sleepDataDay : sleepList) {
			updateHealthDataDay(sleepDataDay.getDate(), sleepDataDay);
		}
		DebugLog.e("全部数据缓存完毕");
		// 这里有可能需要一个判断加载完成标志之类的
	}

	/** 全部运动整天总数据 */
	public HashMap<Long, SportDataDay> getSportMap() {
		return mSportMap;
	}

	/** 全部睡眠整天总数据 */
	public HashMap<Long, SleepDataDay> getSleepMap() {
		return mSleepMap;
	}

	/**
	 * 数据库最小时间
	 * 
	 * @param 20150101
	 * */
	public long getMinDate() {
		return minDate;
	}

	/**
	 * @param date
	 *            20150101
	 * 
	 * */
	public void updateHealthDataDay(long date, SportDataDay data) {
		updateMinDate(date);
		mSportMap.put(date, data);
	}

	/**
	 * @param date
	 *            20150101
	 * 
	 * */
	public void updateHealthDataDay(long date, SleepDataDay data) {
		updateMinDate(date);
		mSleepMap.put(date, data);
	}

	private void updateMinDate(long date) {
		minDate = Math.min(minDate, date);
	}

	/** 获取数据库里面全部每天运动总数据 */
	private List<SportDataDay> getSportDataDayAllList() {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		SportDataDayDao sportDao = daoSession.getSportDataDayDao();
		QueryBuilder<SportDataDay> sportDaoQb = sportDao.queryBuilder();
		sportDaoQb.orderDesc(com.project.library.database.SportDataDayDao.Properties.Date);
		return sportDaoQb.list();
	}

	/** 获取数据库里面全部每天睡眠总数据 */
	private List<SleepDataDay> getSleepDataDayAllList() {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		SleepDataDayDao sleepDao = daoSession.getSleepDataDayDao();
		QueryBuilder<SleepDataDay> sleepDaoQb = sleepDao.queryBuilder();
		sleepDaoQb.orderDesc(com.project.library.database.SleepDataDayDao.Properties.Date);
		return sleepDaoQb.list();
	}

	public static synchronized HealthDataDetailsCache getInstance() {
		if (mInstance == null) {
			mInstance = new HealthDataDetailsCache();
		}
		return mInstance;
	}

	private HealthDataDetailsCache() {
		mHandlerThread = new HandlerThread(getClass().getSimpleName());
		mHandlerThread.start();
		mHandler = new Handler(mHandlerThread.getLooper());
		mHandler.post(mRunnable);
	}

	private static HealthDataDetailsCache mInstance = null;
}
