package com.project.library.device.cmd.getinfo;

import com.project.library.device.cmd.DeviceBaseCommand;
import com.project.library.share.LibSharedPreferences;
import com.project.library.util.ByteDataConvertUtil;
import com.project.library.util.DebugLog;

/** 获取信息 */
public class GetInfoCmd extends DeviceBaseCommand {

	/** 获得设备基本信息 */
	public static final byte KEY_BASIC = 0x01;
	/** 获得设备支持的功能列表 */
	public static final byte KEY_FUNCTION = 0x02;
	/** 获得设备时间 */
	public static final byte KEY_TIME = 0x03;
	/** 获得设备mac地址 */
	public static final byte KEY_MAC = 0x04;
	/** 获得设备电池信息 */
	public static final byte KEY_BATTERY = 0x05;

	public static final byte[] VALUE = new byte[BYTE_LEN_DATA];

	/**
	 * @param key
	 *            获取不同类型数据对应key
	 * */
	public byte[] getGetInfoCmd(byte key) {

		return createCmd(ID_CMD_GET_INFO, key, VALUE);
	}

	public void parse(byte[] data) {
		int key = getCmdKey(data);
		byte[] to = new byte[DeviceBaseCommand.BYTE_LEN_DATA];
		/** 跳过cmdid,key */
		int index = 2;
		ByteDataConvertUtil.BinnCat(data, to, index, DeviceBaseCommand.BYTE_LEN_DATA);
		switch (key) {
		case KEY_BASIC:
			parseBasicInfos(to);
			break;
		case KEY_FUNCTION:
			parseFunctionInfos(to);
			break;
		case KEY_TIME:
			parseTimeInfos(to);
			break;
		case KEY_MAC:
			parseMacInfos(to);
			break;
		case KEY_BATTERY:
			parseBatteryInfos(to);
			break;
		default:
			break;
		}

	}

	private void parseBasicInfos(byte[] value) {
		BasicInfos info = new BasicInfos();
		info.deivceId = ByteDataConvertUtil.toRevInt(value, 0, 2);
		info.firmwareVersion = ByteDataConvertUtil.Byte2Int(value[2]);
		info.mode = ByteDataConvertUtil.Byte2Int(value[3]);
		info.battStatus = ByteDataConvertUtil.Byte2Int(value[4]);
		info.energe = ByteDataConvertUtil.Byte2Int(value[5]);
		info.pairFlag = ByteDataConvertUtil.Byte2Int(value[6]);

		LibSharedPreferences.getInstance().setDeviceId(info.deivceId);
		LibSharedPreferences.getInstance().setDeviceFirmwareVersion(info.firmwareVersion);
		LibSharedPreferences.getInstance().setDeviceEnerge(info.energe);
		DebugLog.d("设备Id：" + info.deivceId);
		DebugLog.d("固件版本号：" + info.firmwareVersion);
		DebugLog.d("电池电量：" + info.energe);

	}

	private void parseFunctionInfos(byte[] value) {
		FunctionInfos info = new FunctionInfos();
		// 主要功能
		info.stepCalculation = (value[0] & 0x01) == BaseInfo.FUNCTION_OK ? true : false;
		info.sleepMonitor = ((value[0] & 0x02) >> 1) == BaseInfo.FUNCTION_OK ? true : false;
		info.singleSport = ((value[0] & 0x04) >> 2) == BaseInfo.FUNCTION_OK ? true : false;
		info.realtimeData = ((value[0] & 0x08) >> 3) == BaseInfo.FUNCTION_OK ? true : false;
		info.deviceUpdate = ((value[0] & 0x10) >> 4) == BaseInfo.FUNCTION_OK ? true : false;

		// 闹钟个数
		info.alarmCount = ByteDataConvertUtil.Byte2Int(value[1]);

		// 闹钟提醒支持类型
		info.wakeUp = (value[2] & 0x01) == BaseInfo.FUNCTION_OK ? true : false;
		info.sleep = ((value[2] & 0x02) >> 1) == BaseInfo.FUNCTION_OK ? true : false;
		info.sport = ((value[2] & 0x04) >> 2) == BaseInfo.FUNCTION_OK ? true : false;
		info.medicine = ((value[2] & 0x08) >> 3) == BaseInfo.FUNCTION_OK ? true : false;
		info.dating = ((value[2] & 0x10) >> 4) == BaseInfo.FUNCTION_OK ? true : false;
		info.party = ((value[2] & 0x20) >> 5) == BaseInfo.FUNCTION_OK ? true : false;
		info.metting = ((value[2] & 0x40) >> 6) == BaseInfo.FUNCTION_OK ? true : false;
		info.custom = ((value[2] & 0x80) >> 7) == BaseInfo.FUNCTION_OK ? true : false;

		// 控制功能
		info.takePhoto = (value[3] & 0x01) == BaseInfo.FUNCTION_OK ? true : false;
		info.music = ((value[3] & 0x02) >> 1) == BaseInfo.FUNCTION_OK ? true : false;

		// 来电提醒功能
		info.calling = (value[4] & 0x01) == BaseInfo.FUNCTION_OK ? true : false;
		info.callingContact = ((value[4] & 0x02) >> 1) == BaseInfo.FUNCTION_OK ? true : false;
		info.callingNum = ((value[4] & 0x04) >> 2) == BaseInfo.FUNCTION_OK ? true : false;

		// 信息提醒功能
		info.message = (value[5] & 0x01) == BaseInfo.FUNCTION_OK ? true : false;
		info.email = ((value[5] & 0x02) >> 1) == BaseInfo.FUNCTION_OK ? true : false;
		info.qq = ((value[5] & 0x04) >> 2) == BaseInfo.FUNCTION_OK ? true : false;
		info.weixin = ((value[5] & 0x08) >> 3) == BaseInfo.FUNCTION_OK ? true : false;
		info.sinaWeibo = ((value[5] & 0x10) >> 4) == BaseInfo.FUNCTION_OK ? true : false;
		info.facebook = ((value[5] & 0x20) >> 5) == BaseInfo.FUNCTION_OK ? true : false;
		info.twitter = ((value[5] & 0x40) >> 6) == BaseInfo.FUNCTION_OK ? true : false;

		// 其他功能
		info.sedentariness = (value[6] & 0x01) == BaseInfo.FUNCTION_OK ? true : false;
		info.antilost = ((value[6] & 0x02) >> 1) == BaseInfo.FUNCTION_OK ? true : false;
		info.onetouchCalling = ((value[6] & 0x04) >> 2) == BaseInfo.FUNCTION_OK ? true : false;
		info.findPhone = ((value[6] & 0x08) >> 3) == BaseInfo.FUNCTION_OK ? true : false;
		info.findDevice = ((value[6] & 0x10) >> 4) == BaseInfo.FUNCTION_OK ? true : false;

		LibSharedPreferences.getInstance().setDeviceAlarmMaxCount(info.alarmCount);
		DebugLog.d("支持闹钟最大个数:" + info.alarmCount);
		DebugLog.d("支持闹钟起床" + info.wakeUp);
		DebugLog.d("支持闹钟睡觉" + info.sleep);
		DebugLog.d("支持闹钟运动" + info.sport);
	}

	/**
	 * @param to
	 */
	private void parseTimeInfos(byte[] to) {
		TimeInfos info = new TimeInfos();
		info.year = ByteDataConvertUtil.toRevInt(to, 0, 2);
		info.month = ByteDataConvertUtil.Byte2Int(to[2]);
		info.day = ByteDataConvertUtil.Byte2Int(to[3]);
		info.hour = ByteDataConvertUtil.Byte2Int(to[4]);
		info.minute = ByteDataConvertUtil.Byte2Int(to[5]);
		info.second = ByteDataConvertUtil.Byte2Int(to[6]);
		info.weekday = ByteDataConvertUtil.Byte2Int(to[7]);

		DebugLog.d("设备时间：" + info.year + info.month + info.day + " " + info.hour + ":" + info.minute + ":" + info.second + "星期:" + (info.weekday + 1));
	}

	/**
	 * @param to
	 */
	private void parseMacInfos(byte[] to) {
		MacAddressInfos info = new MacAddressInfos();
		StringBuilder sb = new StringBuilder();
		sb.append(String.format("%02X", to[5]));
		sb.append(":");
		sb.append(String.format("%02X", to[4]));
		sb.append(":");
		sb.append(String.format("%02X", to[3]));
		sb.append(":");
		sb.append(String.format("%02X", to[2]));
		sb.append(":");
		sb.append(String.format("%02X", to[1]));
		sb.append(":");
		sb.append(String.format("%02X", to[0]));
		info.mac = sb.toString();

		DebugLog.d("设备地址:" + info.mac);
	}

	/**
	 * @param to
	 */
	private void parseBatteryInfos(byte[] to) {
		BatteryInfos info = new BatteryInfos();
		// 121144
		info.type = ByteDataConvertUtil.Byte2Int(to[0]);
		info.voltage = ByteDataConvertUtil.toRevInt(to, 1, 2);
		info.status = ByteDataConvertUtil.Byte2Int(to[3]);
		info.level = ByteDataConvertUtil.Byte2Int(to[4]);
		info.cur_use_time = ByteDataConvertUtil.toRevInt(to, 5, 4);
		info.total_use_time = ByteDataConvertUtil.toRevInt(to, 9, 4);

		DebugLog.d("电池信息：" + ((info.type == BaseInfo.TYPE_BATTERY_LI) ? "锂电池" : "纽扣电池"));
	}

	public static synchronized GetInfoCmd getInstance() {
		if (mInstance == null) {
			mInstance = new GetInfoCmd();
		}
		return mInstance;
	}

	private GetInfoCmd() {

	}

	private static GetInfoCmd mInstance = null;
}
