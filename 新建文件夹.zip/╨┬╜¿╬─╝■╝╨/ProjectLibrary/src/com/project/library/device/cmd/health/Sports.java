package com.project.library.device.cmd.health;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import com.project.library.database.DaoSession;
import com.project.library.database.HealthDataMax;
import com.project.library.database.HealthDataMaxDao;
import com.project.library.database.SportDataDay;
import com.project.library.database.SportDataDayDao;
import com.project.library.database.SportDataItem;
import com.project.library.database.SportDataItemDao;
import com.project.library.util.ByteDataConvertUtil;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;

import de.greenrobot.dao.query.QueryBuilder;

/** 运动数据 */
public class Sports extends HealthDataCmd {
	/** 运动数据头部长度 */
	private static final int HEADER_LEN = 0x10;
	/** 真正的运动数据长度 */
	private static final int SPORT_ITEM_DATA_LEN = 5;
	/** 运动数据的头部个数 */
	private static final int TOTAL_HEADER_COUNT = 2;

	/** 数据存储 <serial,data> */
	private HashMap<Integer, byte[]> mDataHashMap = new HashMap<Integer, byte[]>();

	private long date = -1;// 20150601
	private int year = 2015;
	private int month = 6;
	private int day = 10;
	private int totalStepCount = 0;
	private int totalCalory = 0;
	private int totalDistance = 0;
	private int totalActiveTime = 0;

	/** 设备数据的开始时间[从每天startTime开始],为整点(0,1,2,...) */
	private int startTime = 0;
	/** 时间间隔(每多少分钟产生一项数据) */
	private int timeSpace = 15;
	/** item总个数 */
	private int sportItemCount = 0;
	/** 当前数据总包数，serial总个数 */
	private int totalPacket = 0;

	/** 接收到serial的个数.用于计算百分比 */
	private int receivedPacketCount = 0;

	/** 判断是否头部无数据 */
	private boolean headerWithoutData = false;

	@Override
	public boolean isHeadReceived() {
		// serial == 1 为头部 && serial == 2 为头部
		return mDataHashMap.containsKey(1) && mDataHashMap.containsKey(2);
	}

	/** 获取序列号，第二个字节为序列号 */
	private byte getSerialNumber(byte[] receive) {
		return receive[2];
	}

	/**
	 * @param receive
	 * @return 是否为头部[睡眠可能有两个头部]
	 */
	@Override
	public boolean isHeader(byte[] receive) {
		// serial==1 || serial==2为头部
		return getSerialNumber(receive) == 0x01 || getSerialNumber(receive) == 0x02;
	}

	/**
	 * 解析头部
	 */
	@Override
	public void parseHeader(byte[] receiveData) {
		if (isHeader(receiveData)) {
			// byte0 cmd_id ,byte1 key, byte2 serial, byte3 package_data_len
			// 跳过4个(cmd_id,key, serial,package_data_len)字节,取有效数据
			int index = 4;
			// 从第5字节开始截取数据头部部分
			byte[] header = new byte[HEADER_LEN];
			ByteDataConvertUtil.BinnCat(receiveData, header, index, HEADER_LEN);

			if (getSerialNumber(receiveData) == 0x01) {
				clearData();
				// 第一个运动头部

				// index_start 0 ,1
				year = ByteDataConvertUtil.toRevInt(header, 0, 2);
				// index_start 2
				month = ByteDataConvertUtil.Byte2Int(header[2]);
				// index_start 3
				day = ByteDataConvertUtil.Byte2Int(header[3]);
				// 4 5
				startTime = ByteDataConvertUtil.BinToInt(header, 4, 2);
				// 6
				timeSpace = ByteDataConvertUtil.Byte2Int(header[6]);
				// 7 sport data header后面的item个数
				sportItemCount = ByteDataConvertUtil.Byte2Int(header[7]);
				// 8当前包的总数
				totalPacket = ByteDataConvertUtil.Byte2Int(header[8]);
				// 9 reserved

				date = year * 10000 + month * 100 + day;
				receivedPacketCount = 0;
				headerWithoutData = checkHeaderWithoutData(receiveData);
			} else if (getSerialNumber(receiveData) == 0x02) {
				// 第二个运动头部
				// [0,3]
				totalStepCount = ByteDataConvertUtil.toRevInt(header, 0, 4);
				// [4,7]
				totalCalory = ByteDataConvertUtil.toRevInt(header, 4, 4);
				// [8,11]
				totalDistance = ByteDataConvertUtil.toRevInt(header, 8, 4);
				// 最后一位改为0，保证数据保留2位小数后不会出现近似误差
				totalDistance -= totalDistance % 10 ;
				
				// [12,15]
				totalActiveTime = ByteDataConvertUtil.toRevInt(header, 12, 4);
			}

			save(ByteDataConvertUtil.Byte2Int(getSerialNumber(receiveData)), null);
		}
	}

	@Override
	public int receiveHealthData(byte[] receiveData) {
		// byte0 cmd_id ,byte1 key, byte2 serial, byte3 package_data_len
		int serial = ByteDataConvertUtil.Byte2Int(getSerialNumber(receiveData));
		int package_data_len = receiveData[3];// 包的有效长度
		// 跳过4个(cmd_id,key, serial,package_data_len)字节,取有效数据
		int index = 4;
		if (!isHeader(receiveData)) {
			save(receiveData, serial, index, package_data_len);
		}

		if (receivedPacketCount > totalPacket) {
			receivedPacketCount = totalPacket;
		}

		return (int) ((receivedPacketCount / (float) totalPacket) * 100);
	}

	/**
	 * 保存待解析数据　
	 * 
	 * @param receive
	 *            完整的接收数据
	 * @param serial
	 *            每条数据的序列号
	 * @param start
	 *            取数据偏移，包含start
	 * @param len
	 *            数据长度
	 * 
	 * */
	private void save(byte[] receive, int serial, int start, int len) {
		if (len > 0) {
			byte[] datas = new byte[len];
			ByteDataConvertUtil.BinnCat(receive, datas, start, len);
			// 存储数据,每条数据包含一个或多个真正待解析的数据
			save(serial, datas);
		}
	}

	private void save(int serial, byte[] datas) {
		receivedPacketCount++;
		mDataHashMap.put(serial, datas);
	}

	@Override
	public int checkDataSuccess() {
		if (mDataHashMap != null && !mDataHashMap.isEmpty() && mDataHashMap.size() > TOTAL_HEADER_COUNT) {
			for (int i = 1; i <= totalPacket; i++) {
				if (!mDataHashMap.containsKey(i)) {
					return i;
				}
			}
		}

		return 0;
	}

	@Override
	public void parse() {
		if (date > 0 && totalPacket > TOTAL_HEADER_COUNT && !mDataHashMap.isEmpty()) {
			DebugLog.e("运动数据item总个数: " + sportItemCount);
			DaoSession daoSession = DBTool.getInstance().getDaoSession();
			SportDataItemDao itemDao = daoSession.getSportDataItemDao();

			List<SportDataItem> entities = itemDao.queryBuilder().where(com.project.library.database.SportDataItemDao.Properties.Date.eq(date)).list();
			boolean update = (!entities.isEmpty());
			int dbListLen = update ? entities.size() : 0;
			int sportItemIndex = 0;
			/** 实际数据比数据库多的时候，不能只更新，需要插入[现在是固定96个item还用不上] */
			List<SportDataItem> newEntities = new ArrayList<SportDataItem>();
			boolean addNewItem = false;

			int hour = startTime;
			int minute = 0;
			for (int serial = 1; serial <= totalPacket; serial++) {
				byte[] obj = mDataHashMap.get(Integer.valueOf(serial));
				if (obj != null) {
					int len = obj.length;
					for (int i = 0; i <= len - SPORT_ITEM_DATA_LEN; i += SPORT_ITEM_DATA_LEN) {
						byte[] to = new byte[SPORT_ITEM_DATA_LEN];
						ByteDataConvertUtil.BinnCat(obj, to, i, SPORT_ITEM_DATA_LEN);
						if (minute >= 60) {
							hour += 1;
							minute = 0;
						}
						// 第一个字节前两位
						int mode = to[0] & 0x03;
						// 第一个字节后6位和第二字节前6位
						int stepCount = ((to[0] & 0xFC) >> 2) + ((to[1] & 0x3F) << 6);
						// 第二个字节后两位和第三个字节前两位
						int activeTime = ((to[1] & 0xC0) >> 6) + ((to[2] & 0x03) << 2);
						// 第三个字节后6位和第四个字节前4位
						int calory = ((to[2] & 0xFC) >> 2) + ((to[3] & 0x0F) << 6);
						// 第四个字节后4位和第五个字节
						int distance = ((to[3] & 0xF0) >> 4) + (to[4] & 0xFF << 4);

						SportDataItem entity = null;
						// 数据库存在数据直接更新
						if (sportItemIndex < dbListLen) {
							entity = entities.get(sportItemIndex);
						} else {
							// 数据库存在数据并且数据库里面数据个数小于实际数据个数则需要新添加item
							if (dbListLen > 0) {
								addNewItem = true;
							}
							entity = new SportDataItem();
						}
						entity.setDate(date);
						entity.setHour(hour);
						entity.setMinute(minute);
						entity.setMode(mode);
						entity.setStepCount(stepCount);
						entity.setActiveTime(activeTime);
						entity.setCalory(calory);
						entity.setDistance(distance);

						if (update) {
							if (addNewItem) {
								newEntities.add(entity);
							} else {
								entities.set(sportItemIndex, entity);
							}
						} else {
							entities.add(entity);
						}

						minute += timeSpace;
						sportItemIndex++;
					}
				}
			}

			// =======这里不考虑数据库数据个数大于实际个数的情况，这种情况说明硬件出问题了。后面可能只添加数据，不需要更新=======//
			// 有数据则添加item数据库，更新day数据库
			if (entities != null && !entities.isEmpty()) {
				// 更新或插入每天数据
				if (update) {
					itemDao.updateInTx(entities);
					if (addNewItem) {
						itemDao.insertInTx(newEntities);
					}
				} else {
					itemDao.insertInTx(entities);
				}

				// 更新或插入每天总数据
				SportDataDayDao sportDao = daoSession.getSportDataDayDao();
				QueryBuilder<SportDataDay> sportDaoQb = sportDao.queryBuilder();
				sportDaoQb.where(com.project.library.database.SportDataDayDao.Properties.Date.eq(date));
				List<SportDataDay> list = sportDaoQb.list();
				update = (list != null && (!list.isEmpty()));
				SportDataDay sport = update ? list.get(0) : new SportDataDay();

				// 更新总数据，周月年
				long today = LongDateUtil.Calendar2LongDate(Calendar.getInstance());
				if (date == today) {
					makeUpdateSportStatisticalDatas(update, date, totalDistance - sport.getTotalDistance(), totalStepCount - sport.getTotalstepCount(), totalCalory - sport.getTotalCalory());
				} else {
					makeUpdateSportStatisticalDatas(update, date, totalDistance, totalStepCount, totalCalory);
				}

				sport.setDate(date);
				sport.setTotalstepCount(totalStepCount);
				sport.setTotalCalory(totalCalory);
				sport.setTotalDistance(totalDistance);
				sport.setTotalActiveTime(totalActiveTime);
				if (update) {
					sportDao.update(sport);
				} else {
					sportDao.insert(sport);
				}
				HealthDataDetailsCache.getInstance().updateHealthDataDay(date, sport);

				// 更新或插入每天数据的最大值
				HealthDataMaxDao maxDao = daoSession.getHealthDataMaxDao();
				QueryBuilder<HealthDataMax> maxDaoQb = maxDao.queryBuilder();
				List<HealthDataMax> listMax = maxDaoQb.list();
				update = (listMax != null && (!listMax.isEmpty()));
				HealthDataMax max = update ? listMax.get(0) : new HealthDataMax();
				int maxValue = max.getSportMaxStepCount();
				max.setSportMaxStepCount(maxValue > totalStepCount ? maxValue : totalStepCount);
				maxValue = max.getSportMaxCalory();
				max.setSportMaxCalory(maxValue > totalCalory ? maxValue : totalCalory);
				maxValue = max.getSportMaxDistance();
				max.setSportMaxDistance(maxValue > totalDistance ? maxValue : totalDistance);
				maxValue = max.getSportMaxActiveTime();
				max.setSportMaxActiveTime(maxValue > totalActiveTime ? maxValue : totalActiveTime);
				if (update) {
					maxDao.update(max);
				} else {
					maxDao.insert(max);
				}
			}
		} else {
			headerWithoutData = true;
		}
		DebugLog.e(date + ">>>运动数据解析完成");
		clearData();
	}

	private void clearData() {
		date = -1;
		totalPacket = 0;
		receivedPacketCount = 0;
		mDataHashMap.clear();
	}

	@Override
	public boolean headerWithoutData() {
		return headerWithoutData;
	}

	@Override
	public int getHeaderLen() {
		return HEADER_LEN;
	}

	/** 当天开始指令 */
	public byte[] getSyncDetailsStart() {
		return createCmd(KEY_SYNC_SPORTS_DETAILS_TODAY, SYNC_STATUS_START);
	}

	/** 当天结束指令 */
	public byte[] getSyncDetailsEnd() {
		return createCmd(KEY_SYNC_SPORTS_DETAILS_TODAY, SYNC_STATUS_END);
	}

	/**
	 * 当天数据漏包重发指令
	 * 
	 * @param serial
	 *            漏包序列号
	 * */
	public byte[] getSyncDetailsResend(byte serial) {
		return createCmd(KEY_SYNC_SPORTS_DETAILS_TODAY, new byte[] { SYNC_STATUS_RESEND, serial });
	}

	/** 获取历史数据开始指令 */
	public byte[] getSyncHistoryDetailsStart() {
		return createCmd(KEY_SYNC_SPORTS_DETAILS_HISTORY, SYNC_STATUS_START);
	}

	/** 获取历史数据结束指令 */
	public byte[] getSyncHistoryDetailsEnd() {
		return createCmd(KEY_SYNC_SPORTS_DETAILS_HISTORY, SYNC_STATUS_END);
	}

	/**
	 * 历史数据漏包重发指令
	 * 
	 * @param serial
	 *            漏包序列号
	 * */
	public byte[] getSyncHistoryDetailsResend(byte serial) {
		return createCmd(KEY_SYNC_SPORTS_DETAILS_HISTORY, new byte[] { SYNC_STATUS_RESEND, serial });
	}

	public static synchronized Sports getInstance() {
		if (mInstance == null) {
			mInstance = new Sports();
		}
		return mInstance;
	}

	private Sports() {

	}

	private static Sports mInstance = null;
}
