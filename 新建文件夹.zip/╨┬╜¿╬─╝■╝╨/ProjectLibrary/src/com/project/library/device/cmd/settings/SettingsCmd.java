package com.project.library.device.cmd.settings;

import java.util.Calendar;
import java.util.GregorianCalendar;

import com.project.library.database.AlarmNotify;
import com.project.library.device.cmd.DeviceBaseCommand;
import com.project.library.util.ByteDataConvertUtil;

/** 设置命令 */
public class SettingsCmd extends DeviceBaseCommand {
    private static final byte SETTINGS_SUCCESS = 0x00;

    /** 时间设置 */
    public static final byte KEY_TIME_SETTINGS = 0x01;
    /** 闹钟提醒设置(起床、睡觉、锻炼、吃药等) */
    public static final byte KEY_ALARM_CLOCK_SETTINGS = 0x02;
    /** 运动目标、睡眠目标等设置 */
    public static final byte KEY_MULTI_TARGET_SETTINGS = 0x03;

    /** 用户信息设置 */
    public static final byte KEY_USER_INFOS_SETTINGS = 0x10;
    /** 单位设置 */
    public static final byte KEY_UNIT_SETTINGS = 0x11;

    /** 久坐提醒设置 */
    public static final byte KEY_SEDENTARINESS_SETTINGS = 0x20;
    /** 防丢设置 */
    public static final byte KEY_ANTILOST_SETTINGS = 0x21;
    /** 左右手佩戴设置 */
    public static final byte KEY_HAND_SETTINGS = 0x22;
    /** 手机操作系统设置 */
    public static final byte KEY_OS_SETTINGS = 0x23;

    /** 来电通知开关设置 */
    public static final byte KEY_INCOMING_TELEGRAM_SETTINGS = 0x30;
    /** 信息通知开关设置 */
    public static final byte KEY_MESSAGE_SETTINGS = 0x31;

    public static final byte[] VALUE = new byte[BYTE_LEN_DATA];

    /**
     * 设置时间命令
     * */
    public byte[] getTimeSettingsCmd() {
        byte[] value = new byte[8];
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DATE);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        // 星期日到星期六1-7。实际为星期一到星期日0-6
        int weekday = calendar.get(Calendar.DAY_OF_WEEK) - 2;
        if (weekday < 0) {
            weekday = 6;
        }

        byte[] y = ByteDataConvertUtil.IntToBin(year, 2);
        value[0] = y[1];
        value[1] = y[0];

        value[2] = (byte) month;
        value[3] = (byte) day;
        value[4] = (byte) hour;
        value[5] = (byte) minute;
        value[6] = (byte) second;
        value[7] = (byte) weekday;

        return createCmd(ID_CMD_SETTINGS, KEY_TIME_SETTINGS, value);
    }

    /** 设置闹钟命令 */
    public byte[] getAlarmClockSettingsCmd(AlarmNotify alarm) {
        byte[] value = new byte[7];
        value[0] = ByteDataConvertUtil.Int2Byte((int)alarm.getAlarmId());
        value[1] = ByteDataConvertUtil.Int2Byte(alarm.getAlarmStatus());
        value[2] = ByteDataConvertUtil.Int2Byte(alarm.getAlarmType());
        value[3] = ByteDataConvertUtil.Int2Byte(alarm.getAlarmHour());
        value[4] = ByteDataConvertUtil.Int2Byte(alarm.getAlarmMinute());
        value[5] = ByteDataConvertUtil.Int2Byte(alarm.getAlarmRepetitions());
        value[6] = ByteDataConvertUtil.Int2Byte(alarm.getAlarmSnoozeDuration());

        return createCmd(ID_CMD_SETTINGS, KEY_ALARM_CLOCK_SETTINGS, value);
    }

    /** 运动目标、睡眠目标设置 */
    public byte[] getMultiTargetSettingsCmd(MultiTarget target) {
        byte[] value = new byte[8];
        // 运动目标
        value[0] = target.sportType;
        byte[] bytes = ByteDataConvertUtil.IntToBin(target.sportTarget, 4);
        value[1] = bytes[3];
        value[2] = bytes[2];
        value[3] = bytes[1];
        value[4] = bytes[0];
        // 睡眠目标
        value[5] = target.sleepFlag;
        value[6] = ByteDataConvertUtil.Int2Byte(target.sleepHour);
        value[7] = ByteDataConvertUtil.Int2Byte(target.sleepMinute);

        return createCmd(ID_CMD_SETTINGS, KEY_MULTI_TARGET_SETTINGS, value);
    }

    /** 用户信息设置 */
    public byte[] getUserinfosSettingsCmd(Userinfos info) {
        byte[] value = new byte[8];
        value[0] = ByteDataConvertUtil.Int2Byte(info.height);

        byte[] weights = ByteDataConvertUtil.IntToBin(info.weight * 100, 2);
        value[1] = weights[1];
        value[2] = weights[0];

        value[3] = ByteDataConvertUtil.Int2Byte(info.gender);

        byte[] years = ByteDataConvertUtil.IntToBin(info.year, 2);
        value[4] = years[1];
        value[5] = years[0];

        value[6] = ByteDataConvertUtil.Int2Byte(info.month);
        value[7] = ByteDataConvertUtil.Int2Byte(info.day);

        return createCmd(ID_CMD_SETTINGS, KEY_USER_INFOS_SETTINGS, value);
    }

    /** 单位设置 */
    public byte[] getUnitSettingsCmd(Units units) {
        byte[] value = new byte[4];
        value[0] = ByteDataConvertUtil.Int2Byte(units.dist);
        value[1] = ByteDataConvertUtil.Int2Byte(units.weight);
        value[2] = ByteDataConvertUtil.Int2Byte(units.temp);
        value[3] = ByteDataConvertUtil.Int2Byte(units.stride);

        return createCmd(ID_CMD_SETTINGS, KEY_UNIT_SETTINGS, value);
    }

    /** 久坐提醒命令 */
    public byte[] getSedentarinessSettingsCmd(Sedentariness sedentariness) {
        byte[] value = new byte[7];
        value[0] = ByteDataConvertUtil.Int2Byte(sedentariness.startHour);
        value[1] = ByteDataConvertUtil.Int2Byte(sedentariness.startMinute);
        value[2] = ByteDataConvertUtil.Int2Byte(sedentariness.endHour);
        value[3] = ByteDataConvertUtil.Int2Byte(sedentariness.endMinute);

        byte[] intervals = ByteDataConvertUtil.IntToBin(sedentariness.interval, 2);
        value[4] = intervals[1];
        value[5] = intervals[0];

        value[6] = ByteDataConvertUtil.Int2Byte(sedentariness.repetitions);

        return createCmd(ID_CMD_SETTINGS, KEY_SEDENTARINESS_SETTINGS, value);
    }

    /** 防丢设置 */
    public byte[] getAntilostSettingsCmd() {
        byte[] value = new byte[7];

        return createCmd(ID_CMD_SETTINGS, KEY_ANTILOST_SETTINGS, value);

    }

    /** 左右手佩戴设置 */
    public byte[] getHandSettingsCmd() {
        byte[] value = new byte[7];

        return createCmd(ID_CMD_SETTINGS, KEY_HAND_SETTINGS, value);

    }

    /** 手机操作系统设置 */
    public byte[] getOSSettingsCmd() {
        byte[] value = new byte[7];

        return createCmd(ID_CMD_SETTINGS, KEY_OS_SETTINGS, value);
    }

    /** 来电通知开关设置 */
    public byte[] getIncomingCallSettingsCmd() {
        byte[] value = new byte[7];

        return createCmd(ID_CMD_SETTINGS, KEY_INCOMING_TELEGRAM_SETTINGS, value);
    }

    /** 信息通知开关 */
    public byte[] getMessageSettingsCmd() {
        byte[] value = new byte[7];

        return createCmd(ID_CMD_SETTINGS, KEY_MESSAGE_SETTINGS, value);
    }

    /**
     * 解析设置命令
     * 
     * @return 设置成功失败
     * */
    public boolean parse(byte[] data) {
        byte status_success = data[2];

        return status_success == SETTINGS_SUCCESS;
    }

    public static synchronized SettingsCmd getInstance() {
        if (mInstance == null) {
            mInstance = new SettingsCmd();
        }
        return mInstance;
    }

    private SettingsCmd() {

    }

    private static SettingsCmd mInstance = null;
}
