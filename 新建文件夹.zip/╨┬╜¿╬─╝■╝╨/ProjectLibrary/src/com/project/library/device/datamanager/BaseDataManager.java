package com.project.library.device.datamanager;

import com.project.library.ble.BleGattAttributes;
import com.project.library.device.cmd.DeviceBaseCommand;
import com.project.library.protocol.AppBleNotifyListener;
import com.project.library.util.ByteDataConvertUtil;
import com.project.library.util.DebugLog;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.os.Handler;
import android.os.HandlerThread;

public abstract class BaseDataManager {
    protected AppBleNotifyListener mAppBleNotifyListener;
    /** 5次写数据超时 */
    protected final static int WRITE_ERROR_TOTAL = 5;
    /** 数据未发送成功，1秒重发 */
    protected final static long RESEND_TIMEOUT_PERIOD = 1000L;// 1s

    protected BluetoothGatt gatt;
    protected HandlerThread mWriteHandlerThread;
    protected Handler mWriteHandler;
    protected Runnable mWriteRunnable;
    protected BluetoothGattCharacteristic mWriteBluetoothGattCharacteristic;
    protected int mWriteErrorCounter = 0;
    protected byte[] mLastCommand = new byte[DeviceBaseCommand.BYTE_LEN_TOTAL];
    protected boolean canWriteNext = true;
    protected boolean isDeviceConnectedWritten = false;

    protected HandlerThread mReceiveHandlerThread = null;
    protected Handler mReceiveHandler = new Handler();
    /** 最后接收到的指令 */
    protected byte[] mLastReceive = new byte[DeviceBaseCommand.BYTE_LEN_TOTAL];

    public void init(AppBleNotifyListener listener) {
        mAppBleNotifyListener = listener;

        if (mWriteHandlerThread == null) {
            mWriteHandlerThread = new HandlerThread("mWriteHandlerThread" + getClass().getSimpleName());
            mWriteHandlerThread.start();
            mWriteHandler = new Handler(mWriteHandlerThread.getLooper());
        }

        if (mReceiveHandlerThread == null) {
            mReceiveHandlerThread = new HandlerThread("mReceiveHandlerThread" + getClass().getSimpleName());
            mReceiveHandlerThread.start();
            mReceiveHandler = new Handler(mReceiveHandlerThread.getLooper());
        }
    }

    /** 清除数据 */
    public void clear() {
    }

    public void close() {
        mAppBleNotifyListener = null;
        canWriteNext = false;
        gatt = null;

        if (mWriteHandlerThread != null) {
            mWriteHandlerThread.quit();
            mWriteHandlerThread = null;
        }
        if (mReceiveHandlerThread != null) {
            mReceiveHandlerThread.quit();
            mReceiveHandlerThread = null;
        }
    }

    public BluetoothGatt getGatt() {
        return this.gatt;
    }

    public void setGatt(BluetoothGatt gatt) {
        this.gatt = gatt;
    }

    public boolean isCanWriteNext() {
        return this.canWriteNext;
    }

    public void setCanWriteNext(boolean canWriteNext) {
        this.canWriteNext = canWriteNext;
    }

    public boolean isDeviceConnectedWritten() {
        return this.isDeviceConnectedWritten;
    }

    public void setDeviceConnectedWritten(boolean isDeviceConnectedWritten) {
        this.isDeviceConnectedWritten = isDeviceConnectedWritten;
    }

    public void writeForce(final byte[] value) {
        if (isDeviceConnectedWritten) {
            canWriteNext = true;
            write(value);
        }
    }

    /** 向设备发送指令 */
    public void write(final byte[] value) {
        if (!isDeviceConnectedWritten) {
            return;
        }

        if (!canWriteNext) {
            return;
        }

        mWriteErrorCounter = 0;
        mWriteHandler.removeCallbacksAndMessages(null);
        mWriteRunnable = new Runnable() {

            @Override
            public void run() {
                if (!isDeviceConnectedWritten) {
                    DebugLog.e("device cann't write !");
                    return;
                }

                if (mWriteErrorCounter >= WRITE_ERROR_TOTAL) {
                    canWriteNext = true;
                    if (mAppBleNotifyListener != null) {
                        mAppBleNotifyListener.onDataSendTimeOut(value);
                    }
                    return;
                }
                mWriteErrorCounter++;
                if (mWriteBluetoothGattCharacteristic == null) {
                    if (DeviceBaseCommand.isHealthCmd(value)) {
                        mWriteBluetoothGattCharacteristic = BleGattAttributes.getHealthWriteCharacteristic(gatt);
                    } else {
                        mWriteBluetoothGattCharacteristic = BleGattAttributes.getNormalWriteCharacteristic(gatt);
                    }
                }
                write(gatt, mWriteBluetoothGattCharacteristic, value);
                canWriteNext = false;
                if (isNeedReply(value)) {
                    mWriteHandler.postDelayed(mWriteRunnable, RESEND_TIMEOUT_PERIOD);
                }
            }
        };
        mWriteHandler.postDelayed(mWriteRunnable, 150);
    }

    private void write(BluetoothGatt gatt, BluetoothGattCharacteristic c, byte[] value) {
        if ((c != null) && ((BluetoothGattCharacteristic.PROPERTY_WRITE | c.getProperties()) > 0)) {
            DebugLog.e("write[" + ByteDataConvertUtil.bytesToHexString(value) + "]");
            DeviceBaseCommand.copy(value, mLastCommand);
            c.setValue(value);
            gatt.writeCharacteristic(c);
        }
    }

    /** 一条指令写入设备成功，并在回调出错时加以简单判断[回调为空则默认最后一条指令] */
    public void onCommandWriteSuccess(byte[] data) {
        if (data == null) {
            data = new byte[DeviceBaseCommand.BYTE_LEN_TOTAL];
            DeviceBaseCommand.copy(mLastCommand, data);
        }
    }

    /** 当前指令是否需要回复 */
    public abstract boolean isNeedReply(byte[] cmd);

    /** 收到数据 */
    public abstract void receive(byte[] data, String address);
}
