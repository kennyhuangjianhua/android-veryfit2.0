package com.project.library.device.cmd.settings;

/** 用户信息 */
public class Userinfos {

    public static final int MALE = 0x00;
    public static final int FEMALE = 0x01;

    /** 身高 */
    public int height;
    /** 体重 */
    public int weight;
    /** 性别 */
    public int gender;
    public int year;
    public int month;
    public int day;
}
