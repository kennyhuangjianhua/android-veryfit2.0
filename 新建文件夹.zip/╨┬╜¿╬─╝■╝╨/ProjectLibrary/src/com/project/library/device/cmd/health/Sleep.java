package com.project.library.device.cmd.health;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import com.project.library.database.DaoSession;
import com.project.library.database.SleepDataDay;
import com.project.library.database.SleepDataDayDao;
import com.project.library.database.SleepDataItem;
import com.project.library.database.SleepDataItemDao;
import com.project.library.util.ByteDataConvertUtil;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;

import de.greenrobot.dao.query.QueryBuilder;

/** 睡眠数据 */
public class Sleep extends HealthDataCmd {
	/** 睡眠数据头部长度 */
	private static final int HEADER_LEN = 0x10;
	/** 真正的睡眠数据长度 */
	private static final int SLEEP_ITEM_DATA_LEN = 2;

	/** 睡眠数据的头部个数 */
	private static final int TOTAL_HEADER_COUNT = 2;

	/** 数据存储 <serial,data> */
	private HashMap<Integer, byte[]> mDataHashMap = new HashMap<Integer, byte[]>();

	private long date = -1;// 20150601
	private int year = 2015;
	private int month = 6;
	private int day = 10;

	/** 睡眠结束时间 [小时，分钟] */
	private int sleepEndedTimeH = 0, sleepEndedTimeM = 0;
	/** 睡眠时长 */
	private int totalSleepMinutes = 0;
	/** item总个数 */
	private int sleepItemCount = 0;
	/** 当前数据总包数，serial总个数 */
	private int totalPacket = 0;
	/** 浅睡眠次数 */
	private int lightSleepCount = 0;
	/** 深睡眠次数 */
	private int deepSleepCount = 0;
	/** 醒来次数 */
	private int awakeCount = 0;
	/** 浅睡眠持续时长 */
	private int lightSleepMinutes = 0;
	/** 深睡眠持续时长 */
	private int deepSleepMinutes = 0;

	/** 接收到serial的个数.用于计算百分比 */
	private int receivedPacketCount = 0;

	/** 判断是否头部无数据 */
	private boolean headerWithoutData = false;

	@Override
	public boolean isHeadReceived() {
		// serial == 1 为头部 && serial == 2 为头部
		return mDataHashMap.containsKey(1) && mDataHashMap.containsKey(2);
	}

	/** 获取序列号，第二个字节为序列号 */
	private byte getSerialNumber(byte[] receive) {
		return receive[2];
	}

	/**
	 * @param receive
	 * @return 是否为头部[睡眠可能有两个头部]
	 */
	@Override
	public boolean isHeader(byte[] receive) {
		// serial==1 || serial==2为头部
		return getSerialNumber(receive) == 0x01 || getSerialNumber(receive) == 0x02;
	}

	/**
	 * 解析头部
	 */
	@Override
	public void parseHeader(byte[] receiveData) {
		if (isHeader(receiveData)) {
			// byte0 cmd_id ,byte1 key, byte2 serial, byte3 package_data_len
			// 跳过4个(cmd_id,key, serial,package_data_len)字节,取有效数据
			int index = 4;
			// 从第5字节开始截取数据头部部分
			byte[] header = new byte[HEADER_LEN];
			ByteDataConvertUtil.BinnCat(receiveData, header, index, HEADER_LEN);

			if (getSerialNumber(receiveData) == 0x01) {
				clearData();
				// 第一个睡眠头部
				// index_start 0 ,1
				year = ByteDataConvertUtil.toRevInt(header, 0, 2);
				// index_start 2
				month = ByteDataConvertUtil.Byte2Int(header[2]);
				// index_start 3
				day = ByteDataConvertUtil.Byte2Int(header[3]);
				// 4 5
				sleepEndedTimeH = ByteDataConvertUtil.Byte2Int(header[4]);
				sleepEndedTimeM = ByteDataConvertUtil.Byte2Int(header[5]);
				// 6 7
				totalSleepMinutes = ByteDataConvertUtil.toRevInt(header, 6, 2);
				// 8 sleep data header后面的item个数
				sleepItemCount = ByteDataConvertUtil.Byte2Int(header[8]);
				// 9当前包的总数
				totalPacket = ByteDataConvertUtil.Byte2Int(header[9]);

				date = year * 10000 + month * 100 + day;
				receivedPacketCount = 0;
				headerWithoutData = checkHeaderWithoutData(receiveData);
			} else if (getSerialNumber(receiveData) == 0x02) {
				// 第二个睡眠头部
				// 0
				lightSleepCount = ByteDataConvertUtil.Byte2Int(header[0]);
				// 1
				deepSleepCount = ByteDataConvertUtil.Byte2Int(header[1]);
				// 2
				awakeCount = ByteDataConvertUtil.Byte2Int(header[2]);
				// 3 4
				lightSleepMinutes = ByteDataConvertUtil.toRevInt(header, 3, 2);
				// 5 6
				deepSleepMinutes = ByteDataConvertUtil.toRevInt(header, 5, 2);
			}

			save(ByteDataConvertUtil.Byte2Int(getSerialNumber(receiveData)), null);
		}
	}

	@Override
	public int receiveHealthData(byte[] receiveData) {
		// byte0 cmd_id ,byte1 key, byte2 serial, byte3 package_data_len
		int serial = ByteDataConvertUtil.Byte2Int(getSerialNumber(receiveData));
		int package_data_len = receiveData[3];// 包的有效长度
		// 跳过4个(cmd_id,key, serial,package_data_len)字节,取有效数据
		int index = 4;
		if (!isHeader(receiveData)) {
			save(receiveData, serial, index, package_data_len);
		}

		if (receivedPacketCount > totalPacket) {
			receivedPacketCount = totalPacket;
		}

		return (int) ((receivedPacketCount / (float) totalPacket) * 100);
	}

	/**
	 * 保存待解析数据　
	 * 
	 * @param receive
	 *            完整的接收数据
	 * @param serial
	 *            每条数据的序列号
	 * @param start
	 *            取数据偏移，包含start
	 * @param len
	 *            数据长度
	 * 
	 * */
	private void save(byte[] receive, int serial, int start, int len) {
		if (len > 0) {
			byte[] datas = new byte[len];
			ByteDataConvertUtil.BinnCat(receive, datas, start, len);
			// 存储数据,每条数据包含一个或多个真正待解析的数据
			save(serial, datas);
		}
	}

	private void save(int serial, byte[] datas) {
		receivedPacketCount++;
		mDataHashMap.put(serial, datas);
	}

	@Override
	public int checkDataSuccess() {
		if (mDataHashMap != null && !mDataHashMap.isEmpty() && mDataHashMap.size() > TOTAL_HEADER_COUNT) {
			for (int i = 1; i <= totalPacket; i++) {
				if (!mDataHashMap.containsKey(i)) {
					return i;
				}
			}
		}

		return 0;
	}

	@Override
	public void parse() {
		if (date > 0 && totalPacket > TOTAL_HEADER_COUNT && !mDataHashMap.isEmpty()) {
			DebugLog.e("睡眠数据item总个数: " + sleepItemCount);
			DaoSession daoSession = DBTool.getInstance().getDaoSession();
			SleepDataItemDao itemDao = daoSession.getSleepDataItemDao();

			List<SleepDataItem> entities = itemDao.queryBuilder().where(com.project.library.database.SleepDataItemDao.Properties.Date.eq(date)).list();
			boolean update = (!entities.isEmpty());
			int dbListLen = update ? entities.size() : 0;
			int sleepItemIndex = 0;
			/** 实际数据比数据库多的时候，不能只更新，需要插入 */
			List<SleepDataItem> newEntities = new ArrayList<SleepDataItem>();
			boolean addNewItem = false;

			for (int serial = 1; serial <= totalPacket; serial++) {
				byte[] obj = mDataHashMap.get(Integer.valueOf(serial));
				if (obj != null) {
					int len = obj.length;
					for (int i = 0; i <= len - SLEEP_ITEM_DATA_LEN; i += SLEEP_ITEM_DATA_LEN) {
						byte[] to = new byte[SLEEP_ITEM_DATA_LEN];
						ByteDataConvertUtil.BinnCat(obj, to, i, SLEEP_ITEM_DATA_LEN);

						int sleepStatus = ByteDataConvertUtil.Byte2Int(to[0]);
						int sleepMinutes = ByteDataConvertUtil.Byte2Int(to[1]);

						SleepDataItem entity = null;
						// 数据库存在数据直接更新
						if (sleepItemIndex < dbListLen) {
							entity = entities.get(sleepItemIndex);
						} else {
							// 数据库存在数据并且数据库里面数据个数小于实际数据个数则需要新添加item
							if (dbListLen > 0) {
								addNewItem = true;
							}
							entity = new SleepDataItem();
						}
						entity.setDate(date);
						entity.setSleepStatus(sleepStatus);
						entity.setSleepMinutes(sleepMinutes);

						if (update) {
							if (addNewItem) {
								newEntities.add(entity);
							} else {
								entities.set(sleepItemIndex, entity);
							}
						} else {
							entities.add(entity);
						}
						sleepItemIndex++;
					}
				}
			}
			// =======这里不考虑数据库数据个数大于实际个数的情况，这种情况说明硬件出问题了。=======//
			// 有数据则添加item数据库，更新day数据库
			if (entities != null && !entities.isEmpty()) {
				// 更新或插入每天数据
				if (update) {
					itemDao.updateInTx(entities);
					if (addNewItem) {
						itemDao.insertInTx(newEntities);
					}
				} else {
					itemDao.insertInTx(entities);
				}

				// 更新或插入每天总数据
				SleepDataDayDao sleepDao = daoSession.getSleepDataDayDao();
				QueryBuilder<SleepDataDay> sleepDaoQb = sleepDao.queryBuilder();
				sleepDaoQb.where(com.project.library.database.SleepDataDayDao.Properties.Date.eq(date));
				List<SleepDataDay> list = sleepDaoQb.list();
				update = (list != null && (!list.isEmpty()));
				SleepDataDay sleep = update ? list.get(0) : new SleepDataDay();

				// 更新总数据，周月年[差后面3个参数]
				long today = LongDateUtil.Calendar2LongDate(Calendar.getInstance());
				if (date == today) {
					makeUpdateSleepStatisticalDatas(update, date, totalSleepMinutes - sleep.getTotalSleepMinutes(), deepSleepMinutes - sleep.getDeepSleepMinutes(), lightSleepMinutes - sleep.getLightSleepMinutes(), 0, 0, 0);
				} else {
					makeUpdateSleepStatisticalDatas(update, date, totalSleepMinutes, deepSleepMinutes, lightSleepMinutes, 0, 0, 0);
				}

				sleep.setDate(date);
				sleep.setEndTimeHour(sleepEndedTimeH);
				sleep.setEndTimeMinute(sleepEndedTimeM);
				sleep.setTotalSleepMinutes(totalSleepMinutes);
				sleep.setLightSleepCount(lightSleepCount);
				sleep.setDeepSleepCount(deepSleepCount);
				sleep.setAwakeCount(awakeCount);
				sleep.setLightSleepMinutes(lightSleepMinutes);
				sleep.setDeepSleepMinutes(deepSleepMinutes);
				if (update) {
					sleepDao.update(sleep);
				} else {
					sleepDao.insert(sleep);
				}
				HealthDataDetailsCache.getInstance().updateHealthDataDay(date, sleep);
			}
		} else {
			headerWithoutData = true;
		}
		DebugLog.e(date + ">>>睡眠数据解析完成");
		clearData();
	}

	private void clearData() {
		date = -1;
		totalPacket = 0;
		receivedPacketCount = 0;
		mDataHashMap.clear();
	}

	@Override
	public boolean headerWithoutData() {
		return headerWithoutData;
	}

	@Override
	public int getHeaderLen() {
		return HEADER_LEN;
	}

	/** 当天开始指令 */
	public byte[] getSyncDetailsStart() {
		return createCmd(KEY_SYNC_SLEEP_DETAILS_TODAY, SYNC_STATUS_START);
	}

	/** 当天结束指令 */
	public byte[] getSyncDetailsEnd() {
		return createCmd(KEY_SYNC_SLEEP_DETAILS_TODAY, SYNC_STATUS_END);
	}

	/**
	 * 当天数据漏包重发指令
	 * 
	 * @param serial
	 *            漏包序列号
	 * */
	public byte[] getSyncDetailsResend(byte serial) {
		return createCmd(KEY_SYNC_SLEEP_DETAILS_TODAY, new byte[] { SYNC_STATUS_RESEND, serial });
	}

	/** 获取历史数据开始指令 */
	public byte[] getSyncHistoryDetailsStart() {
		return createCmd(KEY_SYNC_SLEEP_DETAILS_HISTORY, SYNC_STATUS_START);
	}

	/** 获取历史数据结束指令 */
	public byte[] getSyncHistoryDetailsEnd() {
		return createCmd(KEY_SYNC_SLEEP_DETAILS_HISTORY, SYNC_STATUS_END);
	}

	/**
	 * 历史数据漏包重发指令
	 * 
	 * @param serial
	 *            漏包序列号
	 * */
	public byte[] getSyncHistoryDetailsResend(byte serial) {
		return createCmd(KEY_SYNC_SLEEP_DETAILS_HISTORY, new byte[] { SYNC_STATUS_RESEND, serial });
	}

	public static synchronized Sleep getInstance() {
		if (mInstance == null) {
			mInstance = new Sleep();
		}
		return mInstance;
	}

	private Sleep() {

	}

	private static Sleep mInstance = null;
}
