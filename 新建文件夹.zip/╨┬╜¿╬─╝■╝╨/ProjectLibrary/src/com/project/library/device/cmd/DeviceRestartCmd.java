package com.project.library.device.cmd;

/** 设备重启 */
public class DeviceRestartCmd extends DeviceBaseCommand {

    public static final byte KEY = 0x01;
    public static final byte[] VALUE = new byte[] { 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA };

    public static final byte STATUS_SUCCESS = 0x00;
    public static final byte STATUS_FAIL = 0x02;
    public static final byte STATUS_NOT_SUPPORT = 0x03;

    /** 升级状态码在数据中的位置 */
    private static final int STATUS_INDEX = 2;

    private static final byte[] BYTES_CMD = new byte[] { ID_CMD_DEVICE_RESTART, KEY, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0x55, 0x55, (byte) 0xAA, (byte) 0xAA, 0, 0, 0, 0, 0, 0 };

    public byte[] getDeviceRestartCmd() {

        return BYTES_CMD;
    }

    /**
     * 设备重启状态码,one of {@link #STATUS_SUCCESS} , {@link#STATUS_FAIL} ,
     * {@link #STATUS_NOT_SUPPORT}
     * 
     * */
    public byte parse(byte[] data) {
        return data[STATUS_INDEX];
    }

    public static synchronized DeviceRestartCmd getInstance() {
        if (mInstance == null) {
            mInstance = new DeviceRestartCmd();
        }
        return mInstance;
    }

    private DeviceRestartCmd() {

    }

    private static DeviceRestartCmd mInstance = null;
}
