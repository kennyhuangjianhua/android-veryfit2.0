package com.project.library.device.cmd.notify;

/** 来电 */
public class IncomingCall {
    /** 来电已接 */
    public static final byte INCOMING_CALL_STATUS_ACCEPT = 0x01;
    /** 来电已拒 */
    public static final byte INCOMING_CALL_STATUS_REFUSE = 0x02;

    public String phoneNumber;
    public String contactName;
}
