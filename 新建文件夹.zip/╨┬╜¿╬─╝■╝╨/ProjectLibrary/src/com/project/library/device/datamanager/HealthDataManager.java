package com.project.library.device.datamanager;

import com.project.library.device.cmd.DeviceBaseCommand;
import com.project.library.device.cmd.health.HealthDataCmd;
import com.project.library.device.cmd.health.HealthDataParser;
import com.project.library.device.cmd.health.HealthSyncSuccess;
import com.project.library.device.cmd.health.Sleep;
import com.project.library.device.cmd.health.Sports;
import com.project.library.share.LibSharedPreferences;
import com.project.library.util.ByteDataConvertUtil;
import com.project.library.util.DebugLog;

public class HealthDataManager extends BaseDataManager {

    /** 运动数据以及睡眠数据同步解析等 */
    private HealthDataParser mHealthDataParser = new HealthDataParser();
    private int mKey = HealthDataCmd.KEY_ERROR;
    /** 数据完整 */
    private boolean isDataFinished = false;

    @Override
    public boolean isNeedReply(byte[] cmd) {
        // 结束指令不需再次回复
        if (DeviceBaseCommand.getCmdKey(cmd) == HealthDataCmd.KEY_DATA_SEND_FINISHED) {
            return false;
        }
        return true;
    }

    @Override
    public void onCommandWriteSuccess(byte[] data) {
        super.onCommandWriteSuccess(data);
        byte cmdId = DeviceBaseCommand.getCmdId(data);
        byte key = DeviceBaseCommand.getCmdKey(data);
        // 当次同步数据，回复设备成功之后，检查数据完整性
        if (cmdId == DeviceBaseCommand.ID_CMD_HEALTH_DATA) {
            if (key == HealthDataCmd.KEY_DATA_SEND_FINISHED) {
                checkAndNext();
            }
        }
    }

    @Override
    public void receive(final byte[] data, String address) {
        dealHealth(data, address);
    }

    /** 只接收健康数据 */
    private synchronized void dealHealth(final byte[] value, final String address) {
        mReceiveHandler.post(new Runnable() {
            @Override
            public void run() {
                String str = ByteDataConvertUtil.bytesToHexString(value);
                DebugLog.e("收到健康数据\n" + str);

                // 返回数据正确，取消数据重发机制
                byte cmdId = DeviceBaseCommand.getCmdId(value);
                byte key = DeviceBaseCommand.getCmdKey(value);
                if (DeviceBaseCommand.getCmdId(mLastCommand) == cmdId) {
                    mWriteHandler.removeCallbacks(mWriteRunnable);
                }
                mHealthDataParser.changeParser(key);
                receivedHealthData(key, value);
            }
        });
    }

	/** 收到运动数据或者睡眠数据等 */
	private void receivedHealthData(byte key, byte[] value) {
		switch (key) {
		case HealthDataCmd.KEY_SYNC_REQUEST: {
			mWriteHandler.removeCallbacksAndMessages(null);
			mHealthDataParser.clear();
			// 请求同步指令的返回,解析数据
			mHealthDataParser.parseStartData(value);

                if (LibSharedPreferences.getInstance().isSyncData()) {
                    // 发送命令同步运动数据
                    writeForce(Sports.getInstance().getSyncDetailsStart());
                }
            }
                break;
            case HealthDataCmd.KEY_SYNC_SUCCESS: {
                mWriteHandler.removeCallbacksAndMessages(null);
                canWriteNext = true;
                DebugLog.e("数据全部同步完成了。这里要通知app。");
                // 通知app同步完成
                if (mAppBleNotifyListener != null) {
                    mAppBleNotifyListener.onSyncData(100);
                }
            }
                break;
            case HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_TODAY:
            case HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_HISTORY:
            case HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_TODAY:
            case HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_HISTORY: {
                mKey = key;
                mWriteHandler.removeCallbacksAndMessages(null);
                if (isDataFinished) {
                    isDataFinished = false;
                    // 收到结束指令的返回，同步下一批数据
                    if (mKey == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_TODAY) {
                        // 当天运动同步完成，之后同步睡眠
                        writeForce(Sleep.getInstance().getSyncDetailsStart());
                    } else if (mKey == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_TODAY) {
                        // 当天睡眠同步完成之后，同步历史运动数据
                        writeForce(Sports.getInstance().getSyncHistoryDetailsStart());
                    } else if (mKey == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_HISTORY) {
                        if (mHealthDataParser.headerWithoutData()) {
                            // 检查头部全部为0，不为0无任何操作，为0则发送同步历史睡眠指令
                            writeForce(Sleep.getInstance().getSyncHistoryDetailsStart());
                        } else {
                            // 一直发同步运动历史。在header里面判断是否全部完成
                            writeForce(Sports.getInstance().getSyncHistoryDetailsStart());
                        }
                    } else if (mKey == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_HISTORY) {
                        if (mHealthDataParser.headerWithoutData()) {
                            // 检查头部全部为0，不为0无任何操作，为0则发送全部同步结束指令
                            writeForce(HealthSyncSuccess.getInstance().getHealthSyncSuccessCmd(HealthSyncSuccess.FLAG_FOREGROUND, HealthSyncSuccess.MODE_SAFE));
                        } else {
                            // 一直发同步睡眠历史。在header里面判断是否全部完成
                            writeForce(Sleep.getInstance().getSyncHistoryDetailsStart());
                        }
                    }
                } else {
                    if (mHealthDataParser.isPrepared()) {
                        healthDataParser(key, value);
                    }
                }
            }
                break;
            case HealthDataCmd.KEY_DATA_SEND_FINISHED: {
                // 数据准备好并且收到头部。此时说明数据接收正常。
                if (mHealthDataParser.isPrepared() && mHealthDataParser.isHeadReceived()) {
                    // 回复设备
                    writeForce(value);
                    // 之后调用流程
                    // onCharacteristicWrite->onCommandWriteSuccess->checkAndNext()
                } else {
                    // 在数据中断之后，设备再接着发的数据不处理。并且清除已接收到的无效数据
                    clear();
                    DebugLog.e("以上接收的数据无效。");
                }
            }
                break;
            default:
                break;
        }
    }

    /** 08 EE指令发送成功则开始检查数据完整性。以及进行下一步操作[包括漏包，解析，继续获取数据] */
    private void checkAndNext() {
        int serial = mHealthDataParser.checkDataSuccess();
        if (serial > 0) {
            DebugLog.d("漏包：" + serial);
            // 数据漏包之后，需要发送重发获取漏包指令
            if (mKey == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_TODAY) {
                writeForce(Sports.getInstance().getSyncDetailsResend((byte) serial));
            } else if (mKey == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_HISTORY) {
                writeForce(Sports.getInstance().getSyncHistoryDetailsResend((byte) serial));
            } else if (mKey == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_TODAY) {
                writeForce(Sleep.getInstance().getSyncDetailsResend((byte) serial));
            } else if (mKey == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_HISTORY) {
                writeForce(Sleep.getInstance().getSyncHistoryDetailsResend((byte) serial));
            }
        } else {
            isDataFinished = true;
            DebugLog.d("数据完整");
            mHealthDataParser.parse();
            // 某天某数据解析完成之后，需要发送当次结束指令
            if (mKey == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_TODAY) {
                writeForce(Sports.getInstance().getSyncDetailsEnd());
            } else if (mKey == HealthDataCmd.KEY_SYNC_SPORTS_DETAILS_HISTORY) {
                writeForce(Sports.getInstance().getSyncHistoryDetailsEnd());
            } else if (mKey == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_TODAY) {
                writeForce(Sleep.getInstance().getSyncDetailsEnd());
            } else if (mKey == HealthDataCmd.KEY_SYNC_SLEEP_DETAILS_HISTORY) {
                writeForce(Sleep.getInstance().getSyncHistoryDetailsEnd());
            }
        }
    }

    /**
     * 同步流程为： 1、先同步当天运动、睡眠 2、一直同步运动历史，直到运动历史头部全为0 3、一直同步睡眠历史，直到睡眠历史头部全为0
     * 4、全部同步结束
     * 
     * 真正的健康数据解析
     */
    private void healthDataParser(byte key, byte[] receive) {
        if (mHealthDataParser.isHeader(receive)) {
            isDataFinished = false;
            mHealthDataParser.parseHeader(receive);
        } else {
            if (mHealthDataParser.isHeadReceived()) {
                int percent = mHealthDataParser.receiveHealthData(receive);
				// 通知app百分比
				if (mAppBleNotifyListener != null) {
					mAppBleNotifyListener.onSyncData(percent);
				}
            } else {
                writeForce(mLastCommand);
            }
        }
    }

    @Override
    public void clear() {
        super.clear();
        isDataFinished = false;
        if (mHealthDataParser != null) {
            mHealthDataParser.clear();
        }
    }
}
