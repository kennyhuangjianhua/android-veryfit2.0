package com.project.library.device.cmd.settings;

/** 单位信息 */
public class Units {
    /** 无效单位 */
    public static final int UNIT_ERROR = 0x00;

    public static final int UNIT_DIST_KM = 0x01;
    public static final int UNIT_DIST_MI = 0x02;

    public static final int UNIT_WEIGHT_KG = 0x01;
    public static final int UNIT_WEIGHT_LB = 0x02;

    public static final int UNIT_TEMP_C = 0x01;
    public static final int UNIT_TEMP_F = 0x02;

    /** 步长单位厘米 */
    public static final int UNIT_STRIDE_CM = 0x01;
    /** 步长目前无效单位 */
    public static final int UNIT_STRIDE_CMXX = 0x02;

    /** 距离单位 */
    public int dist;
    /** 体重单位 */
    public int weight;
    /** 温度单位 */
    public int temp;
    /** 步长单位 */
    public int stride;
}
