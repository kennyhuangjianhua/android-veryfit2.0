package com.project.library.database;

import java.util.Calendar;
import java.util.List;
import com.project.library.util.DBTool;
import com.project.library.util.DebugLog;
import com.project.library.util.LongDateUtil;
import de.greenrobot.dao.query.QueryBuilder;

public class StatisticalDataFactory {

	// private static StatisticalDataFactory instances;
	//
	// private StatisticalDataFactory(){
	//
	// }
	//
	// public static StatisticalDataFactory getInstances(){
	// if(instances == null){
	// instances = new StatisticalDataFactory();
	// }
	// return instances;
	// }

	/**
	 * 只在更新数据的时候调用 会在数据库中查询出包含这个时间点的统计数据，顺序，周月年，如果数据库中没有，会在数据库中插入一条数据，并初始化它的起止时间
	 * 
	 * @param updateDb
	 *            更新数据或者插入数据
	 * 
	 * @param healthType
	 *            运动睡眠{@link StatisticalData#HEALTH_TYPE_SPORT},
	 *            {@link StatisticalData#HEALTH_TYPE_SLEEP}
	 * @param date
	 *            20150101
	 */
	public static void update(boolean updateDb, long date, int healthType, List<StatisticalData> newData) {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		StatisticalDataDao dao = daoSession.getStatisticalDataDao();
		QueryBuilder<StatisticalData> qb = dao.queryBuilder();
		qb.where(com.project.library.database.StatisticalDataDao.Properties.HealthType.eq(healthType));
		qb.where(com.project.library.database.StatisticalDataDao.Properties.StopTime.ge(date));
		qb.where(com.project.library.database.StatisticalDataDao.Properties.StartTime.le(date));
		qb.orderAsc(com.project.library.database.StatisticalDataDao.Properties.Type);
		List<StatisticalData> datas = qb.list();

		if (datas.isEmpty()) {
			for (StatisticalData statisticalData : newData) {
				statisticalData.setDayCount(1);
			}
			dao.insertInTx(newData);
		} else {
			int[] update = new int[] { 0, 0, 0 };
			for (int i = 0; i < datas.size(); i++) {
				StatisticalData sData = datas.get(i);
				int type = sData.getType();
				sData.update(updateDb, newData.get(type));
				dao.update(sData);
				update[type] = 1;
			}

			for (int j = 0; j < update.length; j++) {
				if (update[j] == 0) {
					dao.insert(newData.get(j));
				}
			}
		}
	}

	public static List<StatisticalData> getDatas() {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		StatisticalDataDao dao = daoSession.getStatisticalDataDao();
		QueryBuilder<StatisticalData> qb = dao.queryBuilder();
		return qb.list();
	}

	/**
	 * @param type
	 * @param healthType
	 *            运动睡眠
	 * @param date
	 *            20150101
	 * @return
	 */
	public static StatisticalData getData(int type, int healthType, long date) {
		DaoSession daoSession = DBTool.getInstance().getDaoSession();
		StatisticalDataDao dao = daoSession.getStatisticalDataDao();
		QueryBuilder<StatisticalData> qb = dao.queryBuilder();
		qb.where(com.project.library.database.StatisticalDataDao.Properties.HealthType.eq(healthType));
		qb.where(com.project.library.database.StatisticalDataDao.Properties.Type.eq(type));
		qb.where(com.project.library.database.StatisticalDataDao.Properties.StopTime.ge(date));
		qb.where(com.project.library.database.StatisticalDataDao.Properties.StartTime.le(date));
		List<StatisticalData> datas = qb.list();
		if (datas.isEmpty()) {
			return createData(date, type);
		}
		return datas.get(0);
	}

	/**
	 * @param date
	 *            20150101
	 * 
	 * @param type
	 *            周月年{@link StatisticalData#TYPE_WEEK},
	 *            {@link StatisticalData#TYPE_MONTH},
	 *            {@link StatisticalData#TYPE_YEAR}
	 * */
	public static StatisticalData createData(long date, int type) {
		long startTime = 0, stoptime = 0;
		switch (type) {
		case StatisticalData.TYPE_WEEK:
			startTime = LongDateUtil.getFirstDayOfWeek(date);// 周一
			stoptime = LongDateUtil.add(startTime, 7 - 1);// 周日
			break;
		case StatisticalData.TYPE_MONTH:
			startTime = LongDateUtil.getFirstDayOfMonth(date);// 20150601
			int monthDay = LongDateUtil.getMonthDay(LongDateUtil.getYear(date), LongDateUtil.getMonth(date));
			stoptime = LongDateUtil.add(startTime, monthDay - 1);// 20150630
			break;
		case StatisticalData.TYPE_YEAR:
			startTime = LongDateUtil.getFirstDayOfYear(date);// 20150101
			stoptime = LongDateUtil.getLongDate(LongDateUtil.getYear(date), 12, 31);// 20151231
			break;
		default:
			break;
		}
		return new StatisticalData(startTime, stoptime, type);
	}

}
