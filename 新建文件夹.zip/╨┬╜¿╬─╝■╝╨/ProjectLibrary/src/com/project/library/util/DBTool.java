package com.project.library.util;

import com.project.library.database.DaoMaster;
import com.project.library.database.DaoSession;
import com.project.library.database.DaoMaster.OpenHelper;
import android.content.Context;

public class DBTool {
    private DaoMaster daoMaster;
    private DaoSession daoSession;
    private Context mCtx;
    private static DBTool instance;

    /** must init in application */
    public void init(Context context) {
        mCtx = context;
    }

    /**
     * 取得DaoMaster
     * 
     * @param context
     * @return
     */
    public DaoMaster getDaoMaster() {
        if (daoMaster == null) {
            if (mCtx == null) {
                DebugLog.e("DBTool must init in application");
            }
            OpenHelper helper = new DaoMaster.DevOpenHelper(mCtx, Contant.DATABASE_NAME, null);
            daoMaster = new DaoMaster(helper.getWritableDatabase());
        }
        return daoMaster;
    }

    /**
     * 取得DaoSession
     * 
     * @param context
     * @return
     */
    public DaoSession getDaoSession() {
        if (daoSession == null) {
            if (daoMaster == null) {
                daoMaster = getDaoMaster();
            }
            daoSession = daoMaster.newSession();
        }
        return daoSession;
    }

    public static synchronized DBTool getInstance() {
        if (instance == null) {
            instance = new DBTool();
        }
        return instance;
    }

    private DBTool() {
    }
}
