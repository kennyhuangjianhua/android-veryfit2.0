package com.project.library.util;

/**
 * 蓝牙状态以及设备连接状态
 * 
 * */
public class BleStatus {
    public static final int NOT_SUPPORT = -99;
    public static final int NOT_OPEN = -88;
    /** 重启蓝牙时，蓝牙开启关闭错误.通知用户手动操作 */
    public static final int BLUETOOTH_ERROR = -77;
    public static final int STATE_ON = -66;
    public static final int STATE_OFF = -55;

    public static final int DEVICE_CONNECTED = 0;
    public static final int DEVICE_CONNECTING = 1;
    public static final int DEVICE_DISCONNECTED = 2;

    public static final int SERIOUS_ERROR = -999;
}