package com.project.library.util;

public class Contant {

    public static final String DATABASE_NAME = "db_veryfit2.db";

}
