package com.project.library.util;

import java.util.Calendar;

/**
 * 长整型日期转换类
 * */
public class LongDateUtil {

	public static long DATE_MILLS = 24 * 60 * 60 * 1000;

	/**
	 * Calendar -> 20150601
	 * 
	 * */
	public static long Calendar2LongDate(Calendar calendar) {
		int y = calendar.get(Calendar.YEAR);
		int m = calendar.get(Calendar.MONTH) + 1;
		int d = calendar.get(Calendar.DATE);

		return getLongDate(y, m, d);
	}

	/**
	 * 20150601 -> Calendar
	 * */
	public static Calendar LongDate2Calendar(long date) {
		Calendar c = Calendar.getInstance();
		c.set(Calendar.YEAR, getYear(date));
		c.set(Calendar.MONTH, getMonth(date) - 1);
		c.set(Calendar.DATE, getDay(date));
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		
		return c;
	}

	public static int getWeeksBetweenDates(long date1, long date2) {
		if (date1 > date2) {
			return getWeeksBetweenDates(date2, date1);
		}
		Calendar c1 = LongDate2Calendar(date1);
		Calendar c2 = LongDate2Calendar(date2);
		
		return (int) ((c2.getTimeInMillis() - c1.getTimeInMillis()) / DATE_MILLS) / 7 + 1;
	}

	public static int getMonthsBetweenDates(long date1, long date2) {
		if (date1 > date2) {
			return getMonthsBetweenDates(date2, date1);
		}
		int year1 = getYear(date1);
		int year2 = getYear(date2);
		int month1 = getMonth(date1);
		int month2 = getMonth(date2);
		if (month2 < month1) {
			month2 += 12;
			year2 -= 1;
		}
		
		return (year2 - year1) * 12 + (month2 - month1) + 1;
	}

	public static int getYearsBetweenDates(long date1, long date2) {
		if (date1 > date2) {
			return getYearsBetweenDates(date2, date1);
		}
		int year1 = getYear(date1);
		int year2 = getYear(date2);
		
		return year2 - year1 + 1;
	}

	/**
	 * @param year
	 *            2015
	 * @param month
	 *            6
	 * @param day
	 *            1
	 * 
	 * @return 20150601
	 * */
	public static long getLongDate(int year, int month, int day) {
		long date = year * 10000 + month * 100 + day;
		
		return date;
	}

	/**
	 * date日期减day天 20150605 - 2 = 2015603;20150601 - 2 = 20150530
	 * 
	 * @param date
	 *            20150601
	 * @param day
	 *            2
	 * */
	public static long sub(long date, int day) {
		if (day < 0) {
			return add(date, -day);
		}

		int y = getYear(date);
		int m = getMonth(date);
		int d = getDay(date) - day;

		while (d <= 0) {
			m--;
			if (m <= 0) {
				y--;
				m = 12;
			}
			d += getMonthDay(y, m);
		}
		
		return getLongDate(y, m, d);
	}

	/**
	 * date日期加day天
	 * 
	 * @param date
	 *            20150601
	 * 
	 * @param day
	 *            2
	 * @see #sub(long, int)
	 * */
	public static long add(long date, int day) {
		if (day < 0) {
			return sub(date, -day);
		}

		int y = getYear(date);
		int m = getMonth(date);
		int d = getDay(date) + day;

		int monthDay = getMonthDay(y, m);
		while (d > monthDay) {
			m++;
			d -= monthDay;
			if (m > 12) {
				y++;
				m = 1;
			}
			monthDay = getMonthDay(y, m);
		}
		
		return getLongDate(y, m, d);
	}

	public static int getYear(long date) {
		
		return (int) (date / 10000);
	}

	public static int getMonth(long date) {
		
		return (int) (date / 100 % 100);
	}

	public static int getDay(long date) {
		
		return (int) (date % 100);
	}

	/** 获取某年某月有多少天 */
	public static int getMonthDay(int year, int month) {
		int result = 0;
		switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			result = 31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			result = 30;
			break;
		case 2:
			result = 28;
			if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
				result = 29;
			}
			break;
		}
		
		return result;
	}

	/**
	 * 获取偏移周的第一天，中国为周一[其他暂时不考虑]
	 * 
	 * @return 比如 20150615
	 */
	public static long getFirstDayOfWeek(int pageOffset) {
		Calendar calendar = Calendar.getInstance();
		int weekday = calendar.get(Calendar.DAY_OF_WEEK) - 1;
		if (weekday < 1) {
			weekday = 7;
		}
		long currentDate = Calendar2LongDate(calendar);
		long monday = sub(currentDate, weekday - 1);
		
		return sub(monday, pageOffset * 7);
	}

	/**
	 * 获取当前日期所在周的第一天，中国为周一[其他暂时不考虑]
	 * 
	 * @return 比如 20150615
	 */
	public static long getFirstDayOfWeek(long date) {
		Calendar calendar = LongDate2Calendar(date);
		int weekday = calendar.get(Calendar.DAY_OF_WEEK) - 1;
		if (weekday < 1) {
			weekday = 7;
		}
		
		return sub(date, weekday - 1);
	}

	/**
	 * 获取当前日期所在周的第一天，中国为周一[其他暂时不考虑]
	 * 
	 * @return Calendar
	 */
	public static Calendar getFirstDayOfWeek(Calendar calendar) {
		long currentDate = Calendar2LongDate(calendar);

		return LongDate2Calendar(getFirstDayOfWeek(currentDate));
	}

	/**
	 * 获取偏移月的第一天
	 * 
	 * @return 比如20150601
	 * */
	public static long getFirstDayOfMonth(int pageOffset) {
		Calendar calendar = Calendar.getInstance();
		long currentDate = Calendar2LongDate(calendar);
		int y = getYear(currentDate);
		int m = getMonth(currentDate);

		m -= pageOffset;
		if (m <= 0) {
			m = 12;
			y--;
		}

		return getLongDate(y, m, 1);
	}

	/**
	 * 获取当前月的第一天
	 * 
	 * @return 比如20150601
	 * */
	public static long getFirstDayOfMonth(long date) {

		return getLongDate(getYear(date), getMonth(date), 1);
	}

	/**
	 * 获取当前月的第一天
	 * 
	 * @return Calendar
	 * */
	public static Calendar getFirstDayOfMonth(Calendar calendar) {
		long currentDate = Calendar2LongDate(calendar);

		return LongDate2Calendar(getFirstDayOfMonth(currentDate));
	}

	/**
	 * 获取偏移年的第一天
	 * 
	 * @return 比如20150101
	 * */
	public static long getFirstDayOfYear(int pageOffset) {
		Calendar calendar = Calendar.getInstance();
		long currentDate = Calendar2LongDate(calendar);
		int y = getYear(currentDate);
		y -= pageOffset;

		return getLongDate(y, 1, 1);
	}

	/**
	 * 获取当前日期年的第一天
	 * 
	 * @return 比如20150101
	 * */
	public static long getFirstDayOfYear(long date) {

		return getLongDate(getYear(date), 1, 1);
	}

	/**
	 * 获取偏移年的第一天
	 * */
	public static Calendar getFirstDayOfYear(Calendar calendar) {
		long currentDate = Calendar2LongDate(calendar);

		return LongDate2Calendar(getFirstDayOfYear(currentDate));
	}
}
