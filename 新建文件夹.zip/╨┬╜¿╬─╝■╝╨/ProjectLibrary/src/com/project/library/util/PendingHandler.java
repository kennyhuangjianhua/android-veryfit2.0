package com.project.library.util;

import android.os.Looper;

public class PendingHandler extends android.os.Handler {

    private boolean mPending = false;

    public PendingHandler(Looper looper) {
        super(looper);
    }

    /** 同步等待发送命令 */
    synchronized public boolean postT(final Runnable r) {
        boolean success = false;

        if (!mPending) {
            success = post(new Runnable() {

                @Override
                public void run() {
                    r.run();

                    pending(false);
                }
            });

            if (success) {
                mPending = true;
            }
        }

        return success;
    }

    /**
     * 清除消息并强制发送命令
     * */
    synchronized public boolean postF(final Runnable r) {
        removeCallbacksAndMessages(null);
        boolean success = post(new Runnable() {

            @Override
            public void run() {
                r.run();

                pending(false);
            }
        });

        if (success) {
            mPending = true;
        }

        return success;
    }

    synchronized public boolean pending() {
        return mPending;
    }

    synchronized private void pending(boolean value) {
        mPending = value;
    }

}
