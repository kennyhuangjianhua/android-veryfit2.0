package com.project.library.util;

public final class ArrayUtils {

    public static boolean contains(int[] array, int value) {
        boolean result = false;

        for (int i = 0; i < array.length; i++) {
            if (array[i] == value) {
                result = true;
                break;
            }
        }

        return result;
    }

    public static boolean contains(byte[] array, byte value) {
        boolean result = false;

        for (int i = 0; i < array.length; i++) {
            if (array[i] == value) {
                result = true;
                break;
            }
        }

        return result;
    }
}