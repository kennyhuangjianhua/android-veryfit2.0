package com.project.library.util;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import com.project.library.entity.BleDevice;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.text.TextUtils;

/**
 * 蓝牙扫描类，在application里初始化
 * */
public class BleScanTool {
    private static final int SHORTENED_LOCAL_NAME = 0x08;
    private static final int COMPLETE_LOCAL_NAME = 0x09;
    private static final long SCAN_PERIOD = 5000L;

    private static BleScanTool instance = null;
    private Context mCtx;
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private Handler mHandler;
    /** 临时存储设备信息，用来排除搜索时搜到重复设备 {key(address), value(BleDevice)} */
    private ConcurrentHashMap<String, BleDevice> mBleDeviceMap = new ConcurrentHashMap<String, BleDevice>();
    private boolean isScaning = false;
    private CopyOnWriteArrayList<ScanDeviceListener> mScanDeviceListenerList = new CopyOnWriteArrayList<BleScanTool.ScanDeviceListener>();
    private CopyOnWriteArrayList<String> mFilterNameList = new CopyOnWriteArrayList<String>();

    /**
     * must init in application
     * 
     * */
    public void init(Context context) {
        DebugLog.e("BleScanUtil init !");
        mCtx = context;
        mBluetoothManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
        if (mBluetoothManager != null && mBluetoothAdapter == null) {
            mBluetoothAdapter = mBluetoothManager.getAdapter();
        }
    }

    public boolean isSupportBLE() {
        if (!mCtx.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            return false;
        }

        return true;
    }

    public boolean isBluetoothOpen() {
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            return true;
        }
        return false;
    }

    public BluetoothAdapter getBluetoothAdapter() {
        return mBluetoothAdapter;
    }

    public boolean isScanning() {
        return isScaning;
    }

    public void addFilterName(String filterName) {
        if (filterName != null) {
            if (!mFilterNameList.contains(filterName)) {
                mFilterNameList.add(filterName);
            }
        }
    }

    public void removeFilterName(String filterName) {
        if (filterName != null && (!mFilterNameList.isEmpty())) {
            mFilterNameList.remove(filterName);
        }
    }

    public void clearFilterName() {
        for (String filterName : mFilterNameList) {
            mFilterNameList.remove(filterName);
        }
    }

    public void addScanDeviceListener(ScanDeviceListener listener) {
        if (listener != null) {
            if (!mScanDeviceListenerList.contains(listener)) {
                mScanDeviceListenerList.add(listener);
            }
        }
    }

    public void removeScanDeviceListener(ScanDeviceListener listener) {
        if (listener != null && (!mScanDeviceListenerList.isEmpty())) {
            mScanDeviceListenerList.remove(listener);
        }
    }

    public void clearScanDeviceListener() {
        for (ScanDeviceListener listener : mScanDeviceListenerList) {
            mScanDeviceListenerList.remove(listener);
        }
    }

    /** 连接之前需要扫描的手机型号 */
    public boolean isNeedScanDevice() {
        String manufacturer = android.os.Build.MANUFACTURER;
        boolean needScanBeforeConnect = false;
        // 目前小米和华为
        if (manufacturer.equalsIgnoreCase("xiaomi") || manufacturer.equalsIgnoreCase("huawei")) {
            needScanBeforeConnect = true;
        }
        return needScanBeforeConnect;
    }

    public void scanLeDevice(boolean isScan) {
        if (mBluetoothAdapter == null || (!mBluetoothAdapter.isEnabled())) {
            return;
        }
        if (isScan) {
            if (isScaning) {
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            }
            mHandler.postDelayed(new Runnable() {
                public void run() {
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    isScaning = false;
                    for (ScanDeviceListener listener : mScanDeviceListenerList) {
                        listener.onFinish();
                    }
                }
            }, SCAN_PERIOD);
            isScaning = true;
            mBleDeviceMap.clear();
            mBluetoothAdapter.startLeScan(mLeScanCallback);
            // 这种方式在某些手机上不行。
            // mBluetoothAdapter.startLeScan(BleGattAttributes.SERVICE_UUIDS,
            // mLeScanCallback);
        } else {
            if (isScaning) {
                mHandler.removeCallbacksAndMessages(null);
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
                isScaning = false;
            }
        }
    }

    private LeScanCallback mLeScanCallback = new LeScanCallback() {
        @Override
        public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {

            String name = device.getName();
            if (TextUtils.isEmpty(name)) {
                name = decodeDeviceName(scanRecord);
                if (TextUtils.isEmpty(name)) {
                    return;
                }
            }

            // 设置名字过滤
            boolean isFilterDevice = mFilterNameList.isEmpty() ? true : mFilterNameList.contains(name);

            if (isFilterDevice) {
                String address = device.getAddress();
                if (!mBleDeviceMap.containsKey(address)) {
                    BleDevice d = new BleDevice();
                    d.mDeviceName = name;
                    d.mDeviceAddress = address;
                    d.mRssi = rssi;
                    mBleDeviceMap.put(address, d);
                    for (ScanDeviceListener listener : mScanDeviceListenerList) {
                        listener.onFind(d);
                    }

                    DebugLog.d("新设备-----" + name + "[" + address + "]");
                }
            }
        }
    };

    private String decodeDeviceName(byte[] data) {
        String name = null;
        int fieldLength, fieldName;
        int packetLength = data.length;
        for (int index = 0; index < packetLength; index++) {
            fieldLength = data[index];
            if (fieldLength == 0)
                break;
            fieldName = data[++index];

            if (fieldName == COMPLETE_LOCAL_NAME || fieldName == SHORTENED_LOCAL_NAME) {
                name = decodeLocalName(data, index + 1, fieldLength - 1);
                break;
            }
            index += fieldLength - 1;
        }
        return name;
    }

    private String decodeLocalName(final byte[] data, final int start, final int length) {
        try {
            return new String(data, start, length, "UTF-8");
        } catch (final UnsupportedEncodingException e) {
            DebugLog.e("Unable to convert the complete local name to UTF-8");
            return null;
        } catch (final IndexOutOfBoundsException e) {
            DebugLog.e("Error when reading complete local name");
            return null;
        }
    }

    public static synchronized BleScanTool getInstance() {
        if (instance == null) {
            instance = new BleScanTool();
        }
        return instance;
    }

    private BleScanTool() {
        mHandler = new Handler();
    }

    public interface ScanDeviceListener {
        public void onFind(BleDevice device);

        public void onFinish();
    }
}
