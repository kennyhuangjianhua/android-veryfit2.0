package com.project.library.core;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import com.project.library.ble.BleConnectService;
import com.project.library.database.SportDataDay;
import com.project.library.util.DebugLog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;

public class CoreServiceProxy {
    private static CoreServiceProxy sInstance = null;
    private final Context mContext;
    private final Handler mHandler;
    private ICoreService mCoreService;
    private CopyOnWriteArrayList<CoreServiceListener> mListeners = new CopyOnWriteArrayList<CoreServiceListener>();

    private CoreServiceProxy(Context context) {
        DebugLog.e("construction.");

        mContext = context;
        mHandler = new Handler();
        mCoreService = null;

        Intent service = new Intent(mContext, BleConnectService.class);
        service.setAction("com.project.library.ble.ConnectService");
        if (mContext.bindService(service, mConnection, Context.BIND_AUTO_CREATE)) {
            DebugLog.e("bind core service success.");
        } else {
            DebugLog.e("bind core service failed.");
        }
    }

    public static void init(Context context) {
        sInstance = new CoreServiceProxy(context);
    }

    public boolean isAvailable() {
        return mCoreService != null;
    }

    public static void fini() {
        if (sInstance != null) {
            sInstance.close();
            sInstance = null;
        }
    }

    private void close() {
        DebugLog.e("proxy closed.");
        clearListener();
        mContext.unbindService(mConnection);
    }

    public static CoreServiceProxy getInstance() {
        return sInstance;
    }

    public void addListener(CoreServiceListener listener) {
        if (listener != null) {
            if (!mListeners.contains(listener)) {
                mListeners.add(listener);
            }
        }
    }

    public void removeListener(CoreServiceListener listener) {
        if (listener != null && (!mListeners.isEmpty())) {
            mListeners.remove(listener);
        }
    }

    private void clearListener() {
        for (CoreServiceListener listener : mListeners) {
            mListeners.remove(listener);
        }
    }

    // ======================ble操作部分=========================//

    public boolean initBLE(byte devicesId) {
        if (!isAvailable()) {
            DebugLog.e("Service is unAvailable");
            return false;
        }
        boolean success = false;
        try {
            success = mCoreService.initBLE(devicesId);
        } catch (RemoteException e) {
            DebugLog.e("remote call failed. (initBLE)");
        }

        return success;
    }

    public boolean connect(String address) {
        if (!isAvailable()) {
            DebugLog.e("Service is unAvailable");
            return false;
        }
        boolean success = false;
        try {
            success = mCoreService.connect(address);
        } catch (RemoteException e) {
            DebugLog.e("remote call failed. (connect)");
        }

        return success;
    }

    public boolean disconnect() {
        if (!isAvailable()) {
            DebugLog.e("Service is unAvailable");
            return false;
        }
        boolean success = false;
        try {
            success = mCoreService.disconnect();
        } catch (RemoteException e) {
            DebugLog.e("remote call failed. (disconnect)");
        }

        return success;
    }

    public boolean write(byte[] cmd) {
        if (!isAvailable()) {
            DebugLog.e("Service is unAvailable");
            return false;
        }
        boolean success = false;
        try {
            success = mCoreService.write(cmd);
        } catch (RemoteException e) {
            DebugLog.e("remote call failed. (write)");
        }

        return success;
    }

    public boolean writeForce(byte[] cmd) {
        if (!isAvailable()) {
            DebugLog.e("Service is unAvailable");
            return false;
        }
        boolean success = false;
        try {
            success = mCoreService.writeForce(cmd);
        } catch (RemoteException e) {
            DebugLog.e("remote call failed. (writeForce)");
        }

        return success;
    }

    public boolean isDeviceConnected() {
        if (!isAvailable()) {
            DebugLog.e("Service is unAvailable");
            return false;
        }
        boolean success = false;
        try {
            success = mCoreService.isDeviceConnected();
        } catch (RemoteException e) {
            DebugLog.e("remote call failed. (isDeviceConnected)");
        }

        return success;
    }

    private final ICoreServiceCallback.Stub mCallback = new ICoreServiceCallback.Stub() {

        @Override
        public void onBlueToothError(final int error) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onBlueToothError.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onBlueToothError(error);
                    }
                }
            });
        }

        @Override
        public void onBLEConnecting() throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onBLEConnecting.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onBLEConnecting();
                    }
                }
            });
        }

        @Override
        public void onBLEConnected() throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onBLEConnected.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onBLEConnected();
                    }
                }
            });
        }

        @Override
        public void onBLEDisConnected(final String address) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onBLEDisConnected.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onBLEDisConnected(address);
                    }
                }
            });
        }

        @Override
        public void onBLEConnectTimeOut() throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onBLEConnectTimeOut.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onBLEConnectTimeOut();
                    }
                }
            });
        }

        @Override
        public void onDataSendTimeOut(final byte[] data) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onDataSendTimeOut.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onDataSendTimeOut(data);
                    }
                }
            });
        }

        @Override
        public void onDataReceived(final byte[] data) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onDataReceived.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onDataReceived(data);
                    }
                }
            });
        }

        @Override
        public void onDataChanged(final List<SportDataDay> list) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onDataChanged.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onDataChanged(list);
                    }
                }
            });
        }

        @Override
        public void onWareUpdate(final byte status) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onWareUpdate.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onWareUpdate(status);
                    }
                }
            });
        }

        @Override
        public void onBindUnbind(final byte status) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onBindUnbind.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onBindUnbind(status);
                    }
                }
            });
        }

        @Override
        public void onSettingsSuccess(final byte cmdKey, final boolean success) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onSettingsSuccess.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onSettingsSuccess(cmdKey, success);
                    }
                }
            });
        }

		@Override
		public void onGetInfo(final byte cmdKey) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onGetInfo.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onGetInfo(cmdKey);
                    }
                }
            });
		}

        @Override
        public void onSyncData(final int process) throws RemoteException {
            mHandler.post(new Runnable() {

                @Override
                public void run() {
                    DebugLog.e("onSyncData.");

                    for (CoreServiceListener listener : mListeners) {
                        listener.onSyncData(process);
                    }
                }
            });
        }
    };

    private final ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            DebugLog.e("service disconnected.");
            for (CoreServiceListener listener : mListeners) {
                listener.onCoreServiceDisconnected();
            }
            mCoreService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            DebugLog.e("service connected.");
            mCoreService = ICoreService.Stub.asInterface(service);
            try {
                mCoreService.registerCallback(mCallback);
            } catch (RemoteException e) {
                DebugLog.e("remote call failed. (registerCallback)");
            }
            for (CoreServiceListener listener : mListeners) {
                listener.onCoreServiceConnected();
            }
        }
    };
}
