package com.project.library.core;

import java.util.List;

import com.project.library.database.SportDataDay;

public class APPCoreServiceListener implements CoreServiceListener {

    @Override
    public void onCoreServiceConnected() {

    }

    @Override
    public void onCoreServiceDisconnected() {

    }

    @Override
    public void onBlueToothError(int error) {

    }

    @Override
    public void onBLEConnecting() {

    }

    @Override
    public void onBLEConnected() {

    }

    @Override
    public void onBLEDisConnected(String address) {

    }

    @Override
    public void onBLEConnectTimeOut() {

    }

    @Override
    public void onDataSendTimeOut(byte[] data) {

    }

    @Override
    public void onDataReceived(byte[] data) {

    }

    @Override
    public void onDataChanged(List<SportDataDay> list) {
    }

    @Override
    public void onWareUpdate(byte status) {
    }

    @Override
    public void onBindUnbind(byte status) {
    }

    @Override
    public void onSettingsSuccess(byte cmdKey, boolean success) {
    }

	@Override
	public void onGetInfo(byte cmdKey) {

	}

	@Override
    public void onSyncData(int process) {
    }

}
