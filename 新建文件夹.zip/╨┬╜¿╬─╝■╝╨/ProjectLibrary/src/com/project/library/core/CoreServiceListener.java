package com.project.library.core;

import java.util.List;
import com.project.library.database.SportDataDay;

public interface CoreServiceListener {
    public abstract void onCoreServiceConnected();

    public abstract void onCoreServiceDisconnected();

    /**
     * errorCode in {@link com.project.library.util.BleStatus#NOT_SUPPORT},
     * {@link com.project.library.util.BleStatus#NOT_OPEN},
     * {@link com.project.library.util.BleStatus#BLUETOOTH_ERROR},
     * {@link com.project.library.util.BleStatus#STATE_ON},
     * {@link com.project.library.util.BleStatus#STATE_OFF}
     * 
     * */
    public abstract void onBlueToothError(int errorCode);

    public abstract void onBLEConnecting();

    public abstract void onBLEConnected();

    public abstract void onBLEDisConnected(String address);

    public abstract void onBLEConnectTimeOut();

    public abstract void onDataSendTimeOut(byte[] data);

    public abstract void onDataReceived(byte[] data);

    public abstract void onDataChanged(List<SportDataDay> list);

    public abstract void onWareUpdate(byte status);

    public abstract void onBindUnbind(byte status);

    /**
     * @param cmdKey
     *            设置命令里面对应的key
     * @param success
     *            设置成功失败标志
     */
    public abstract void onSettingsSuccess(byte cmdKey, boolean success);
    /**
     * @param cmdKey
     *            获取命令里面对应的key
     */
    public abstract void onGetInfo(byte cmdKey);

    /** 同步数据进度 */
    public abstract void onSyncData(int process);
}