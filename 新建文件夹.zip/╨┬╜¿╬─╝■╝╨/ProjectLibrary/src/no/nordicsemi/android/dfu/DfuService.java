package no.nordicsemi.android.dfu;

import android.app.Activity;

/** 固件升级服务 */
public class DfuService extends DfuBaseService {

    @Override
    protected Class<? extends Activity> getNotificationTarget() {
        // 没用。代码被注释了
        return null;
    }

}
